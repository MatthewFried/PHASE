"""
WSB Framework - RL Module
==========================
Complete RL training with WSB analysis, baselines, lead-time analysis.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from collections import deque
from dataclasses import dataclass, asdict
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Categorical, Normal

from .config import OptionAConfig
from .core import compute_basin_entropy, StatisticalTests, analyze_distribution_inversion, aggregate_seed_results
from .classifiers import BinarySuccessClassifier, ReturnQuantileClassifier, SurvivalTimeClassifier

# Environment state utilities
# Envs with an IMPLEMENTED set_env_state/get_obs_from_env pair. LunarLander was
# previously listed but never implemented (silent fallback); capability is now
# additionally verified at runtime by RLTrainer._probe_state_setting().
STATE_SETTABLE_ENVS = {"CartPole-v1", "CartPole-v0", "Acrobot-v1",
                       "MountainCar-v0", "MountainCarContinuous-v0", "Pendulum-v1"}

def can_set_state(env_name: str) -> bool:
    return env_name in STATE_SETTABLE_ENVS

def set_env_state(env, state: np.ndarray, env_name: str) -> bool:
    try:
        if env_name in ["CartPole-v1", "CartPole-v0"]:
            env.unwrapped.state = state.copy()
            return True
        elif env_name == "Acrobot-v1":
            env.unwrapped.state = state.copy()
            return True
        elif env_name in ["MountainCar-v0", "MountainCarContinuous-v0"]:
            env.unwrapped.state = state.copy()
            return True
        elif env_name == "Pendulum-v1":
            if len(state) == 3:
                theta = np.arctan2(state[1], state[0])
                env.unwrapped.state = np.array([theta, state[2]])
            else:
                env.unwrapped.state = state.copy()
            return True
        return False
    except Exception:
        return False

def get_env_state(env, env_name: str) -> Optional[np.ndarray]:
    try:
        if hasattr(env.unwrapped, 'state'):
            return np.array(env.unwrapped.state).copy()
        return None
    except Exception:
        return None

def get_obs_from_env(env, env_name: str) -> np.ndarray:
    """Get observation from environment's current state."""
    try:
        if env_name in ["CartPole-v1", "CartPole-v0"]:
            # CartPole: state IS the observation
            return np.array(env.unwrapped.state, dtype=np.float32)
        elif env_name == "Acrobot-v1":
            # Acrobot: state is [theta1, theta2, dtheta1, dtheta2]
            # observation is [cos(t1), sin(t1), cos(t2), sin(t2), dt1, dt2]
            s = env.unwrapped.state
            return np.array([
                np.cos(s[0]), np.sin(s[0]),
                np.cos(s[1]), np.sin(s[1]),
                s[2], s[3]
            ], dtype=np.float32)
        elif env_name in ["MountainCar-v0", "MountainCarContinuous-v0"]:
            # MountainCar: state IS the observation
            return np.array(env.unwrapped.state, dtype=np.float32)
        elif env_name == "Pendulum-v1":
            # Pendulum: state is [theta, theta_dot]
            # observation is [cos(theta), sin(theta), theta_dot]
            s = env.unwrapped.state
            return np.array([np.cos(s[0]), np.sin(s[0]), s[1]], dtype=np.float32)
        elif env_name in ["LunarLander-v3", "LunarLanderContinuous-v3"]:
            # LunarLander: need to call step to get obs (complex)
            # Fall back to state if available
            if hasattr(env.unwrapped, 'state'):
                return np.array(env.unwrapped.state, dtype=np.float32)
        # Default fallback
        return np.array(env.unwrapped.state, dtype=np.float32)
    except Exception:
        # Ultimate fallback: reset and return that observation
        obs, _ = env.reset()
        return np.array(obs, dtype=np.float32)

# Neural Networks
class PPOActorCritic(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, hidden_dims: List[int], continuous: bool = False):
        super().__init__()
        self.continuous = continuous
        layers, prev = [], obs_dim
        for h in hidden_dims:
            layers += [nn.Linear(prev, h), nn.Tanh()]
            prev = h
        self.shared = nn.Sequential(*layers)
        if continuous:
            self.actor_mean = nn.Linear(hidden_dims[-1], act_dim)
            self.actor_logstd = nn.Parameter(torch.zeros(act_dim))
        else:
            self.actor = nn.Linear(hidden_dims[-1], act_dim)
        self.critic = nn.Linear(hidden_dims[-1], 1)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.constant_(m.bias, 0)
    
    def forward(self, obs):
        features = self.shared(obs)
        value = self.critic(features)
        if self.continuous:
            return self.actor_mean(features), torch.exp(self.actor_logstd), value
        return self.actor(features), value
    
    def get_action(self, obs, deterministic=False):
        with torch.no_grad():
            if self.continuous:
                mean, std, value = self.forward(obs)
                action = mean if deterministic else Normal(mean, std).sample()
                log_prob = Normal(mean, std).log_prob(action).sum(-1)
            else:
                logits, value = self.forward(obs)
                if deterministic:
                    action, log_prob = torch.argmax(logits, -1), None
                else:
                    dist = Categorical(logits=logits)
                    action = dist.sample()
                    log_prob = dist.log_prob(action)
        return action, log_prob, value
    
    def evaluate_actions(self, obs, actions):
        if self.continuous:
            mean, std, value = self.forward(obs)
            dist = Normal(mean, std)
            return dist.log_prob(actions).sum(-1), dist.entropy().sum(-1), value.squeeze(-1)
        logits, value = self.forward(obs)
        dist = Categorical(logits=logits)
        return dist.log_prob(actions), dist.entropy(), value.squeeze(-1)
    
    def get_policy_entropy(self, obs):
        with torch.no_grad():
            if self.continuous:
                mean, std, _ = self.forward(obs)
                return Normal(mean, std).entropy().sum(-1).mean().item()
            logits, _ = self.forward(obs)
            return Categorical(logits=logits).entropy().mean().item()

class DQNNetwork(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, hidden_dims: List[int], dueling: bool = False):
        super().__init__()
        self.dueling = dueling
        layers, prev = [], obs_dim
        for h in hidden_dims:
            layers += [nn.Linear(prev, h), nn.ReLU()]
            prev = h
        self.features = nn.Sequential(*layers)
        if dueling:
            self.value_head = nn.Linear(hidden_dims[-1], 1)
            self.advantage_head = nn.Linear(hidden_dims[-1], act_dim)
        else:
            self.q_head = nn.Linear(hidden_dims[-1], act_dim)
    
    def forward(self, obs):
        features = self.features(obs)
        if self.dueling:
            value = self.value_head(features)
            advantage = self.advantage_head(features)
            return value + advantage - advantage.mean(-1, keepdim=True)
        return self.q_head(features)
    
    def get_action(self, obs, epsilon=0.0):
        with torch.no_grad():
            q = self.forward(obs)
            if np.random.random() < epsilon:
                return np.random.randint(q.shape[-1]), q
            return torch.argmax(q, -1).item(), q

# Buffers
class RolloutBuffer:
    def __init__(self):
        self.clear()
    def push(self, obs, action, reward, value, log_prob, done):
        self.obs.append(obs); self.actions.append(action); self.rewards.append(reward)
        self.values.append(value); self.log_probs.append(log_prob); self.dones.append(done)
    def compute_returns_and_advantages(self, last_value, gamma, gae_lambda):
        """
        GAE with the termination mask at the CORRECT timestep: dones[t] marks
        whether the transition taken at t ended the episode, so both the
        bootstrap term gamma*V(s_{t+1}) and the lambda-recursion are masked by
        (1 - dones[t]). (v30/v31.0 masked with dones[t+1], which bootstraps
        across episode boundaries and cuts the wrong step.)
        Truncation (time limit) is handled upstream: the rollout loop folds
        gamma*V(s_{t+1}) into the reward of a truncated-but-not-terminated
        step and stores done=True, so masking here is correct for both cases.
        """
        rewards = np.array(self.rewards)
        values = np.array(self.values + [last_value])
        dones = np.array(self.dones, dtype=np.float64)
        advantages = np.zeros_like(rewards)
        last_gae = 0.0
        for t in reversed(range(len(rewards))):
            nonterminal = 1.0 - dones[t]
            delta = rewards[t] + gamma * values[t + 1] * nonterminal - values[t]
            advantages[t] = last_gae = delta + gamma * gae_lambda * nonterminal * last_gae
        return advantages + values[:-1], advantages
    def get_tensors(self, device):
        return (torch.tensor(np.array(self.obs), dtype=torch.float32, device=device),
                torch.tensor(np.array(self.actions), device=device),
                torch.tensor(np.array(self.log_probs), dtype=torch.float32, device=device),
                torch.tensor(np.array(self.values), dtype=torch.float32, device=device))
    def clear(self):
        self.obs, self.actions, self.rewards, self.values, self.log_probs, self.dones = [], [], [], [], [], []
    def __len__(self):
        return len(self.obs)

class ReplayBuffer:
    def __init__(self, capacity: int, obs_dim: int):
        self.capacity, self.ptr, self.size = capacity, 0, 0
        self.obs = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.actions = np.zeros(capacity, dtype=np.int64)
        self.rewards = np.zeros(capacity, dtype=np.float32)
        self.next_obs = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.dones = np.zeros(capacity, dtype=np.float32)
    def push(self, obs, action, reward, next_obs, done):
        self.obs[self.ptr], self.actions[self.ptr], self.rewards[self.ptr] = obs, action, reward
        self.next_obs[self.ptr], self.dones[self.ptr] = next_obs, done
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)
    def sample(self, batch_size, device):
        idx = np.random.choice(self.size, batch_size, replace=False)
        return (torch.tensor(self.obs[idx], dtype=torch.float32, device=device),
                torch.tensor(self.actions[idx], device=device),
                torch.tensor(self.rewards[idx], dtype=torch.float32, device=device),
                torch.tensor(self.next_obs[idx], dtype=torch.float32, device=device),
                torch.tensor(self.dones[idx], dtype=torch.float32, device=device))
    def __len__(self):
        return self.size

@dataclass
class CheckpointData:
    step: int
    h_basin: float               # MEAN of per-probe-point local entropies (H_mean)
    phase_counts: List[float]    # pooled counts (diagnostic only; entropy of this
                                 # is basin-fraction entropy, NOT H_mean)
    wsb_mode: str
    recent_reward_mean: float
    recent_reward_std: float
    h_local_max: float = 0.0     # max local entropy across probe points (H_max)
    h_local_std: float = 0.0
    h_noise_control: float = 0.0 # entropy of repeated rollouts from ONE
                                 # unperturbed state (policy/env noise floor)
    n_probe_points_used: int = 0
    policy_entropy: float = 0.0
    value_variance: float = 0.0
    reward_variance: float = 0.0
    td_error_mean: float = 0.0
    def to_dict(self):
        return asdict(self)

class RLTrainer:
    def __init__(self, config: OptionAConfig, logger=None):
        self.config, self.logger = config, logger
        self.device = torch.device(config.device if torch.cuda.is_available() else "cpu")
        # Env defaults are applied only via config.resolve_option_a_config at
        # construction time; the trainer never rewrites explicit settings.
        self._setup_env()
        self._setup_policy()
        self.use_state_setting = self._probe_state_setting()
        self.checkpoints: List[CheckpointData] = []
        self.episode_rewards, self.episode_lengths = [], []
        self.collapse_events = []
        self.state_buffer = deque(maxlen=1000)
        self.internal_state_buffer = deque(maxlen=1000)
        self.td_errors, self.value_predictions = [], []
        if logger:
            logger.info(f"WSB Mode: {'local_state' if self.use_state_setting else 'initial_condition'}")
    
    def _setup_env(self):
        try:
            import gymnasium as gym
        except ImportError:
            import gym
        self.env = gym.make(self.config.env_name)
        self.obs_dim = self.env.observation_space.shape[0]
        if hasattr(self.env.action_space, 'n'):
            self.act_dim, self.continuous = self.env.action_space.n, False
        else:
            self.act_dim, self.continuous = self.env.action_space.shape[0], True
        # Fail loudly on unsupported combinations instead of silently running
        # an algorithm whose likelihood/targets are wrong for the space.
        if self.continuous:
            raise NotImplementedError(
                f"{self.config.env_name} has a continuous action space; the "
                "PPO head here is an unsquashed Normal and DQN is discrete-"
                "only. Add tanh-squashed PPO before running continuous envs.")

    def _probe_state_setting(self) -> bool:
        """
        Capability is determined by an actual set/get round-trip, not an
        allowlist: reset, read internal state, set a perturbed copy, and check
        the resulting observation is finite with the right shape.
        """
        if not can_set_state(self.config.env_name):
            return False
        try:
            import gymnasium as gym
        except ImportError:
            import gym
        try:
            env = gym.make(self.config.env_name)
            env.reset(seed=0)
            s = get_env_state(env, self.config.env_name)
            if s is None:
                env.close(); return False
            ok = set_env_state(env, s + 1e-3, self.config.env_name)
            obs = get_obs_from_env(env, self.config.env_name)
            env.close()
            return bool(ok and obs is not None
                        and obs.shape == (self.obs_dim,)
                        and np.all(np.isfinite(obs)))
        except Exception:
            return False
        if self.logger:
            self.logger.info(f"Env: {self.config.env_name}, obs={self.obs_dim}, act={self.act_dim}")
    
    def _setup_policy(self):
        hidden = [self.config.hidden_dim] * self.config.n_hidden_layers
        if self.config.algo == "ppo":
            self.policy = PPOActorCritic(self.obs_dim, self.act_dim, hidden, self.continuous).to(self.device)
            self.optimizer = optim.Adam(self.policy.parameters(), lr=self.config.learning_rate)
            self.buffer = RolloutBuffer()
        else:
            self.policy = DQNNetwork(self.obs_dim, self.act_dim, hidden, self.config.dqn_dueling).to(self.device)
            self.target = DQNNetwork(self.obs_dim, self.act_dim, hidden, self.config.dqn_dueling).to(self.device)
            self.target.load_state_dict(self.policy.state_dict())
            self.optimizer = optim.Adam(self.policy.parameters(), lr=self.config.learning_rate)
            self.buffer = ReplayBuffer(self.config.dqn_buffer_size, self.obs_dim)
            self.epsilon = self.config.dqn_epsilon_start
    
    def _get_classifier(self):
        if self.config.rl_phase_classifier == "binary_success":
            return BinarySuccessClassifier(self.config.reward_threshold)
        elif self.config.rl_phase_classifier == "return_quantile":
            # Freeze quantile thresholds the FIRST time enough returns exist:
            # phase semantics must be constant along the H trajectory
            # (recomputing thresholds per checkpoint makes "phase 0" mean
            # different things at different times).
            if getattr(self, "_frozen_quantile_clf", None) is not None:
                return self._frozen_quantile_clf
            if len(self.episode_rewards) >= 20:
                self._frozen_quantile_clf = ReturnQuantileClassifier(
                    self.config.n_return_quantiles,
                    np.array(self.episode_rewards[:100]))
                return self._frozen_quantile_clf
            return BinarySuccessClassifier(self.config.reward_threshold)
        elif self.config.rl_phase_classifier == "survival_time":
            return SurvivalTimeClassifier([50, 100, 200, 400])
        return BinarySuccessClassifier(self.config.reward_threshold)
    
    def compute_h_basin(self, n_perturbations: Optional[int] = None) -> Tuple[float, np.ndarray, str]:
        try:
            import gymnasium as gym
        except ImportError:
            import gym
        n_pert = n_perturbations or self.config.n_perturbations
        clf = self._get_classifier()
        if self.use_state_setting and len(self.internal_state_buffer) >= 10:
            return self._compute_local(gym, clf, n_pert)
        return self._compute_initial(gym, clf, n_pert)
    
    def _compute_local(self, gym, clf, n_pert) -> Tuple[float, np.ndarray, str]:
        """
        CORRECTED (v31): per-probe-point LOCAL basin entropy.

        v30 pooled all outcome counts across probe points into one vector and
        took a single entropy. That measures global basin FRACTIONS, not local
        boundary structure; a policy with two stable basins of fractions
        (0.5, 0.5) and NO boundary points in the buffer would have scored
        H = log 2. The paper's H_mean/H_max are statistics of per-point
        entropies, so each probe point gets its own perturbation cloud and its
        own entropy, then we aggregate.

        Also: v30 created a fresh gym env for EVERY perturbation
        (n_probes * n_pert env constructions per checkpoint). One env is
        created per checkpoint and reused via reset() + set_env_state().
        """
        internal_states = list(self.internal_state_buffer)
        n_probes = min(self.config.n_probe_points, len(internal_states))
        probe_idx = np.random.choice(len(internal_states), n_probes, replace=False)
        env = gym.make(self.config.env_name)
        per_point_h, per_point_counts = [], []
        for idx in probe_idx:
            state = internal_states[idx]
            counts = np.zeros(clf.n_phases)
            for _ in range(n_pert):
                env.reset()
                pert = np.random.uniform(-self.config.epsilon, self.config.epsilon,
                                         state.shape)
                if set_env_state(env, state + pert, self.config.env_name):
                    obs = get_obs_from_env(env, self.config.env_name)
                else:
                    obs, _ = env.reset()
                reward, ep_len = self._rollout(env, obs)
                phase = self._classify_outcome(clf, reward, ep_len)
                if 0 <= phase < len(counts):
                    counts[phase] += 1
            per_point_h.append(compute_basin_entropy(counts))
            per_point_counts.append(counts)
        # NOISE CONTROL: repeat rollouts from ONE unperturbed probe state.
        # With a deterministic policy and deterministic env this is exactly 0;
        # anything above 0 quantifies non-geometric entropy sources (policy
        # sampling if rollout_deterministic=False, or env stochasticity).
        # If h_noise_control ~ h_mean, the measured entropy is NOT state-
        # boundary sensitivity.
        h_noise = 0.0
        if getattr(self.config, "compute_noise_control", True) and len(probe_idx) > 0:
            state0 = internal_states[probe_idx[0]]
            counts0 = np.zeros(clf.n_phases)
            for _ in range(n_pert):
                env.reset()
                if set_env_state(env, state0, self.config.env_name):
                    obs = get_obs_from_env(env, self.config.env_name)
                else:
                    obs, _ = env.reset()
                reward, ep_len = self._rollout(env, obs)
                p = self._classify_outcome(clf, reward, ep_len)
                if 0 <= p < len(counts0):
                    counts0[p] += 1
            h_noise = compute_basin_entropy(counts0)
        env.close()
        h_arr = np.array(per_point_h) if per_point_h else np.zeros(1)
        pooled = (np.sum(per_point_counts, axis=0) if per_point_counts
                  else np.zeros(clf.n_phases))
        self.last_local_stats = {
            "h_mean": float(h_arr.mean()), "h_max": float(h_arr.max()),
            "h_std": float(h_arr.std()), "n_probes": int(n_probes),
            "h_noise_control": float(h_noise),
            "per_point_h": h_arr.tolist(),
        }
        return float(h_arr.mean()), pooled, "local_state"

    def _compute_initial(self, gym, clf, n_pert) -> Tuple[float, np.ndarray, str]:
        """
        Fallback when the env state is NOT settable. Nearby integer reset
        seeds are NOT geometrically nearby initial conditions, so this is a
        GLOBAL initial-condition outcome distribution, not the local
        H_basin object. It is labeled "initial_condition_global" and the
        analysis marks is_local=False; do not present it as local basin
        entropy. The headline RL claim is restricted to state-settable envs.
        """
        n_probes = max(1, self.config.n_probe_points // 10)
        env = gym.make(self.config.env_name)
        per_point_h, per_point_counts = [], []
        for _ in range(n_probes):
            seed = int(np.random.randint(0, 2**31))
            counts = np.zeros(clf.n_phases)
            for k in range(n_pert):
                obs, _ = env.reset(seed=seed + k)
                reward, ep_len = self._rollout(env, obs)
                phase = self._classify_outcome(clf, reward, ep_len)
                if 0 <= phase < len(counts):
                    counts[phase] += 1
            per_point_h.append(compute_basin_entropy(counts))
            per_point_counts.append(counts)
        env.close()
        h_arr = np.array(per_point_h)
        pooled = np.sum(per_point_counts, axis=0)
        self.last_local_stats = {
            "h_mean": float(h_arr.mean()), "h_max": float(h_arr.max()),
            "h_std": float(h_arr.std()), "n_probes": int(n_probes),
            "per_point_h": h_arr.tolist(),
        }
        return float(h_arr.mean()), pooled, "initial_condition_global"
    
    def _rollout(self, env, obs, max_steps=None) -> Tuple[float, int]:
        """Returns (total_reward, episode_length). Headline WSB rollouts are
        deterministic-policy by default (config.rollout_deterministic) so the
        measured entropy reflects state-perturbation sensitivity, not policy
        sampling noise (see the per-checkpoint noise control)."""
        max_steps = max_steps or self.config.rollout_max_steps
        total, steps = 0.0, 0
        for _ in range(max_steps):
            obs_t = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
            if self.config.algo == "ppo":
                action, _, _ = self.policy.get_action(
                    obs_t, deterministic=getattr(self.config, "rollout_deterministic", True))
                action = int(action.cpu().numpy().squeeze()) if not self.continuous else action.cpu().numpy().squeeze()
            else:
                action, _ = self.policy.get_action(obs_t, epsilon=0.0)
            obs, r, term, trunc, _ = env.step(action)
            total += r
            steps += 1
            if term or trunc:
                break
        return total, steps

    def _classify_outcome(self, clf, total_reward: float, length: int) -> int:
        """Route the correct outcome field to the classifier: survival_time
        classifiers consume episode LENGTH (v30/v31.0 passed total reward to
        SurvivalTimeClassifier, which was semantically wrong)."""
        if isinstance(clf, SurvivalTimeClassifier):
            return clf.classify(length)
        return clf.classify(total_reward)
    
    def _compute_baselines(self) -> Dict[str, float]:
        baselines = {}
        if self.config.compute_policy_entropy and len(self.state_buffer) > 0:
            obs = torch.tensor(np.array(list(self.state_buffer)[-100:]), dtype=torch.float32).to(self.device)
            baselines["policy_entropy"] = self.policy.get_policy_entropy(obs)
        if self.config.compute_value_variance and len(self.value_predictions) > 0:
            baselines["value_variance"] = float(np.var(self.value_predictions[-100:]))
        if self.config.compute_reward_variance and len(self.episode_rewards) > 10:
            baselines["reward_variance"] = float(np.var(self.episode_rewards[-20:]))
        if self.config.compute_td_error and len(self.td_errors) > 0:
            baselines["td_error_mean"] = float(np.mean(np.abs(self.td_errors[-100:])))
        return baselines
    
    def _train_ppo_step(self, returns, advantages):
        states, actions, old_lp, _ = self.buffer.get_tensors(self.device)
        returns_t = torch.tensor(returns, dtype=torch.float32, device=self.device)
        advs = torch.tensor(advantages, dtype=torch.float32, device=self.device)
        if self.config.normalize_advantage:
            advs = (advs - advs.mean()) / (advs.std() + 1e-8)
        n, idx = len(states), np.arange(len(states))
        for _ in range(self.config.ppo_epochs):
            np.random.shuffle(idx)
            for start in range(0, n, self.config.batch_size):
                bi = idx[start:start + self.config.batch_size]
                lp, ent, vals = self.policy.evaluate_actions(states[bi], actions[bi])
                ratio = torch.exp(lp - old_lp[bi])
                s1, s2 = ratio * advs[bi], torch.clamp(ratio, 1 - self.config.clip_epsilon, 1 + self.config.clip_epsilon) * advs[bi]
                loss = -torch.min(s1, s2).mean() + self.config.value_coef * F.mse_loss(vals, returns_t[bi]) - self.config.entropy_coef * ent.mean()
                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.policy.parameters(), self.config.max_grad_norm)
                self.optimizer.step()
                self.td_errors.append((returns_t[bi] - vals).abs().mean().item())
    
    def _train_dqn_step(self):
        if len(self.buffer) < self.config.dqn_batch_size:
            return
        s, a, r, ns, d = self.buffer.sample(self.config.dqn_batch_size, self.device)
        q = self.policy(s).gather(1, a.unsqueeze(1)).squeeze(1)
        with torch.no_grad():
            if self.config.dqn_double:
                next_a = self.policy(ns).argmax(1)
                next_q = self.target(ns).gather(1, next_a.unsqueeze(1)).squeeze(1)
            else:
                next_q = self.target(ns).max(1)[0]
            target_q = r + self.config.gamma * next_q * (1 - d)
        loss = F.mse_loss(q, target_q)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.td_errors.append((q - target_q).abs().mean().item())
    
    def _detect_collapse(self, step):
        if len(self.episode_rewards) < self.config.min_episodes_for_collapse:
            return
        w = self.config.collapse_window
        if len(self.episode_rewards) < 2 * w:
            return
        recent, prev = np.mean(self.episode_rewards[-w:]), np.mean(self.episode_rewards[-2*w:-w])
        if recent < self.config.collapse_threshold * prev and prev > 0.3 * np.max(self.episode_rewards):
            if len(self.collapse_events) == 0 or step - self.collapse_events[-1][0] > w * 50:
                self.collapse_events.append((step, prev, recent))
                if self.logger:
                    self.logger.warning(f"Collapse at step {step}: {prev:.1f} -> {recent:.1f}")
    
    def train(self, tracker=None) -> Dict:
        if self.logger:
            self.logger.info(f"Training {self.config.algo.upper()} for {self.config.total_timesteps} steps")
        obs, _ = self.env.reset()
        ep_reward, ep_len, total_steps, ep_count = 0.0, 0, 0, 0
        last_checkpoint_step = 0  # Track last checkpoint
        
        while total_steps < self.config.total_timesteps:
            if self.config.algo == "ppo":
                self.buffer.clear()
                for _ in range(self.config.buffer_size):
                    obs_t = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
                    action, lp, val = self.policy.get_action(obs_t)
                    self.value_predictions.append(val.cpu().numpy().squeeze())
                    a_np = int(action.cpu().numpy().squeeze()) if not self.continuous else action.cpu().numpy().squeeze()
                    next_obs, reward, term, trunc, _ = self.env.step(a_np)
                    done = term or trunc
                    if trunc and not term:
                        # Time-limit truncation is not an absorbing terminal:
                        # bootstrap V(s_{t+1}) into the reward (SB3-style),
                        # then mark done so GAE cuts the recursion here.
                        with torch.no_grad():
                            no_t = torch.tensor(next_obs, dtype=torch.float32
                                                ).unsqueeze(0).to(self.device)
                            out = self.policy(no_t)
                            v_next = (out[2] if self.continuous else out[1]
                                      ).cpu().numpy().squeeze()
                        reward = reward + self.config.gamma * float(v_next)
                    self.buffer.push(obs, a_np, reward, val.cpu().numpy().squeeze(), lp.cpu().numpy().squeeze() if lp is not None else 0, done)
                    self.state_buffer.append(obs.copy())
                    if self.use_state_setting:
                        internal = get_env_state(self.env, self.config.env_name)
                        if internal is not None:
                            self.internal_state_buffer.append(internal)
                    ep_reward += reward
                    ep_len += 1
                    total_steps += 1
                    if done:
                        self.episode_rewards.append(ep_reward)
                        self.episode_lengths.append(ep_len)
                        if tracker:
                            tracker.log("episode_reward", ep_reward, total_steps)
                        ep_count += 1
                        ep_reward, ep_len = 0.0, 0
                        obs, _ = self.env.reset()
                    else:
                        obs = next_obs
                    if total_steps >= self.config.total_timesteps:
                        break
                with torch.no_grad():
                    last_obs = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
                    _, last_val = self.policy(last_obs) if not self.continuous else (None, self.policy(last_obs)[2])
                    if self.continuous:
                        _, _, last_val = self.policy(last_obs)
                    last_val = last_val.cpu().numpy().squeeze()
                returns, advs = self.buffer.compute_returns_and_advantages(last_val, self.config.gamma, self.config.gae_lambda)
                self._train_ppo_step(returns, advs)
            else:
                for _ in range(self.config.buffer_size):
                    obs_t = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
                    frac = min(1.0, total_steps / self.config.dqn_epsilon_decay)
                    self.epsilon = (self.config.dqn_epsilon_end
                                    + (self.config.dqn_epsilon_start
                                       - self.config.dqn_epsilon_end) * (1 - frac))
                    action, q_vals = self.policy.get_action(obs_t, self.epsilon)
                    self.value_predictions.append(q_vals.max().item())
                    next_obs, reward, term, trunc, _ = self.env.step(action)
                    done = term or trunc
                    # DQN target: bootstrap through truncation (next_obs is the
                    # true successor), mask only on genuine termination.
                    self.buffer.push(obs, action, reward, next_obs, term)
                    self.state_buffer.append(obs.copy())
                    if self.use_state_setting:
                        internal = get_env_state(self.env, self.config.env_name)
                        if internal is not None:
                            self.internal_state_buffer.append(internal)
                    self._train_dqn_step()
                    if total_steps % self.config.dqn_target_update == 0:
                        self.target.load_state_dict(self.policy.state_dict())
                    ep_reward += reward
                    ep_len += 1
                    total_steps += 1
                    if done:
                        self.episode_rewards.append(ep_reward)
                        self.episode_lengths.append(ep_len)
                        if tracker:
                            tracker.log("episode_reward", ep_reward, total_steps)
                        ep_count += 1
                        ep_reward, ep_len = 0.0, 0
                        obs, _ = self.env.reset()
                    else:
                        obs = next_obs
                    if total_steps >= self.config.total_timesteps:
                        break
            
            # Checkpoint if we've passed the next checkpoint threshold
            should_checkpoint = (total_steps - last_checkpoint_step >= self.config.checkpoint_interval) or (total_steps >= self.config.total_timesteps)
            if should_checkpoint:
                h, counts, mode = self.compute_h_basin()
                baselines = self._compute_baselines()
                ls = getattr(self, "last_local_stats", {})
                recent = self.episode_rewards[-20:] if len(self.episode_rewards) >= 20 else self.episode_rewards
                cp = CheckpointData(step=total_steps, h_basin=h, phase_counts=counts.tolist(), wsb_mode=mode,
                                   h_local_max=ls.get("h_max", h),
                                   h_local_std=ls.get("h_std", 0.0),
                                   h_noise_control=ls.get("h_noise_control", 0.0),
                                   n_probe_points_used=ls.get("n_probes", 0),
                                   recent_reward_mean=float(np.mean(recent)) if recent else 0,
                                   recent_reward_std=float(np.std(recent)) if recent else 0,
                                   policy_entropy=baselines.get("policy_entropy", 0),
                                   value_variance=baselines.get("value_variance", 0),
                                   reward_variance=baselines.get("reward_variance", 0),
                                   td_error_mean=baselines.get("td_error_mean", 0))
                self.checkpoints.append(cp)
                last_checkpoint_step = total_steps  # Update checkpoint tracker
                if tracker:
                    tracker.log("h_basin", h, total_steps)
                    for k, v in baselines.items():
                        tracker.log(k, v, total_steps)
                if self.logger:
                    self.logger.info(f"Step {total_steps:6d} | Ep: {ep_count:4d} | Reward: {cp.recent_reward_mean:7.1f} | H: {h:.4f} ({mode})")
                self._detect_collapse(total_steps)
        
        self.env.close()
        return self._analyze_results(tracker)
    
    def _analyze_results(self, tracker=None) -> Dict:
        results = {
            "n_episodes": len(self.episode_rewards),
            "n_collapses": len(self.collapse_events),
            "collapse_events": [(int(s), float(p), float(r)) for s, p, r in self.collapse_events],
            "final_reward": float(np.mean(self.episode_rewards[-10:])) if self.episode_rewards else 0,
            "max_reward": float(np.max(self.episode_rewards)) if self.episode_rewards else 0,
            "wsb_mode": self.checkpoints[0].wsb_mode if self.checkpoints else "unknown",
            "checkpoints": [cp.to_dict() for cp in self.checkpoints],
        }
        if len(self.checkpoints) > 0:
            h_vals = np.array([cp.h_basin for cp in self.checkpoints])
            results["h_basin_mean"] = float(np.mean(h_vals))
            results["h_basin_std"] = float(np.std(h_vals))
            results["h_basin_max"] = float(np.max(h_vals))
            results["h_basin_min"] = float(np.min(h_vals))
            results["h_basin_final"] = float(h_vals[-1])
            # H_max of the paper = max over checkpoints of per-checkpoint local max
            hlm = np.array([cp.h_local_max for cp in self.checkpoints])
            results["h_local_max_overall"] = float(np.max(hlm))
            results["h_local_max_mean"] = float(np.mean(hlm))
            # Locality contract: only local_state runs measure the local
            # H_basin object; the seed fallback is a global initial-condition
            # distribution and must not be pooled with local results.
            results["is_local"] = bool(results["wsb_mode"] == "local_state")
            # Noise floor: entropy of repeated rollouts from ONE unperturbed
            # state. If this approaches h_basin_mean, the measured entropy is
            # policy/env noise, not state-boundary sensitivity.
            hnc = np.array([cp.h_noise_control for cp in self.checkpoints])
            results["h_noise_control_mean"] = float(np.mean(hnc))
            results["h_noise_control_max"] = float(np.max(hnc))
            # Distribution inversion
            phase_counts = [np.array(cp.phase_counts) for cp in self.checkpoints]
            if len(phase_counts) > 5:
                try:
                    inversion = analyze_distribution_inversion(h_vals, phase_counts)
                    results["distribution_inversion"] = inversion.to_dict()
                except Exception:
                    pass
            # Lead time analysis
            if len(self.collapse_events) > 0:
                collapse_steps = np.array([c[0] for c in self.collapse_events])
                cp_steps = np.array([cp.step for cp in self.checkpoints])
                lead = StatisticalTests.lead_time_analysis(
                    h_vals, collapse_steps,
                    checkpoint_steps=cp_steps,
                    threshold_percentile=self.config.warning_threshold_percentile,
                    lookback_steps=10 * self.config.checkpoint_interval)
                results["lead_time_analysis"] = lead
            # PROSPECTIVE collapse prediction: does the predictor measured at
            # checkpoint t predict a collapse event strictly AFTER t (within a
            # horizon)? The v30/v31.0 target (bottom-30% of CURRENT rewards)
            # was partially circular because the phase classifier itself uses
            # reward; a future event as target removes the circularity.
            if len(self.checkpoints) > 10:
                steps_arr = np.array([cp.step for cp in self.checkpoints])
                horizon = 10 * self.config.checkpoint_interval
                collapse_steps = np.array([c[0] for c in self.collapse_events])
                future_collapse = np.array([
                    bool(np.any((collapse_steps > s) & (collapse_steps <= s + horizon)))
                    for s in steps_arr
                ]) if len(collapse_steps) else np.zeros(len(steps_arr), dtype=bool)
                results["prospective_horizon_steps"] = int(horizon)
                results["n_positive_prospective_targets"] = int(future_collapse.sum())
                baselines = {
                    "h_basin": h_vals,
                    "h_local_max": np.array([cp.h_local_max for cp in self.checkpoints]),
                    "policy_entropy": np.array([cp.policy_entropy for cp in self.checkpoints]),
                    "value_variance": np.array([cp.value_variance for cp in self.checkpoints]),
                    "reward_variance": np.array([cp.reward_variance for cp in self.checkpoints]),
                    "td_error": np.array([cp.td_error_mean for cp in self.checkpoints]),
                }
                if 0 < future_collapse.sum() < len(future_collapse):
                    baseline_aucs = {}
                    for name, vals in baselines.items():
                        try:
                            roc = StatisticalTests.roc_auc_analysis(
                                future_collapse.astype(int), vals)
                            baseline_aucs[name] = {
                                "roc_auc": roc["roc_auc"],
                                "ci": (roc["roc_auc_ci_lower"], roc["roc_auc_ci_upper"])}
                        except Exception:
                            pass
                    results["prospective_collapse_prediction"] = baseline_aucs
                else:
                    results["prospective_collapse_prediction"] = {
                        "degenerate": True,
                        "reason": "no (or all) checkpoints precede a collapse "
                                  "within the horizon"}
        if tracker:
            tracker.set_metadata("analysis", results)
        if self.logger:
            self.logger.info(f"\n--- Analysis Results ---")
            self.logger.info(f"  Checkpoints collected: {len(self.checkpoints)}")
            self.logger.info(f"  H_basin: mean={results['h_basin_mean']:.4f}, std={results['h_basin_std']:.4f}, max={results['h_basin_max']:.4f}")
            if len(self.checkpoints) > 1:
                h_trajectory = [cp.h_basin for cp in self.checkpoints]
                self.logger.info(f"  H_basin trajectory: {[f'{h:.3f}' for h in h_trajectory[:10]]}{'...' if len(h_trajectory) > 10 else ''}")
            self.logger.info(f"  Final reward: {results.get('final_reward', 0):.1f}")
            self.logger.info(f"  Collapses detected: {results.get('n_collapses', 0)}")
            
            if "distribution_inversion" in results:
                di = results["distribution_inversion"]
                self.logger.info(f"  Distribution Inversion:")
                self.logger.info(f"    KL(uniform) low-H:  {di.get('low_h_kl_from_uniform', 0):.4f}")
                self.logger.info(f"    KL(uniform) high-H: {di.get('high_h_kl_from_uniform', 0):.4f}")
                self.logger.info(f"    Rare phase increase: {di.get('rare_phase_increase_factor', 0):.2f}x")
            
            if "lead_time_analysis" in results:
                lt = results["lead_time_analysis"]
                self.logger.info(f"  Lead Time Analysis:")
                self.logger.info(f"    Mean lead time: {lt.get('mean_lead_time', 0):.1f} steps")
                self.logger.info(f"    Threshold used: {lt.get('threshold', 0):.4f}")
                self.logger.info(f"    Detection rate: {lt.get('detection_rate', 0):.2%}")
            
            if "prospective_collapse_prediction" in results and \
                    not results["prospective_collapse_prediction"].get("degenerate"):
                bc = results["prospective_collapse_prediction"]
                self.logger.info(f"  Prospective collapse prediction (ROC-AUC, "
                                 f"horizon={results['prospective_horizon_steps']}):")
                self.logger.info(f"    H_basin: {bc.get('h_basin', {}).get('roc_auc', 0):.4f}")
                for name in ["policy_entropy", "value_variance", "reward_variance", "td_error"]:
                    if name in bc and isinstance(bc[name], (int, float)):
                        self.logger.info(f"    {name}: {bc[name]:.4f}")
                    elif name in bc and isinstance(bc[name], dict):
                        auc_val = bc[name].get('roc_auc', bc[name].get('auc', 0))
                        self.logger.info(f"    {name}: {auc_val:.4f}")
        
        return results

def run_option_a(config: OptionAConfig, logger=None, tracker=None) -> Dict:
    if logger:
        logger.info("=" * 60 + "\nOPTION A: RL Early Warning\n" + "=" * 60)
        logger.info(f"Env: {config.env_name}, Seeds: {config.n_seeds}")
    all_results = []
    for seed in range(config.n_seeds):
        if logger:
            logger.info(f"\n--- Seed {seed + 1}/{config.n_seeds} ---")
        np.random.seed(seed)
        torch.manual_seed(seed)
        trainer = RLTrainer(config, logger)
        results = trainer.train(tracker)
        results["seed"] = seed
        all_results.append(results)
    agg_keys = ["h_basin_mean", "h_basin_max", "h_basin_final", "h_local_max_overall",
                "h_noise_control_mean", "final_reward", "max_reward", "n_collapses"]
    aggregate = aggregate_seed_results(all_results, agg_keys, config.n_seeds * 100)
    aggregate["env"] = config.env_name
    aggregate["algo"] = config.algo
    aggregate["wsb_mode"] = all_results[0].get("wsb_mode", "unknown") if all_results else "unknown"
    aggregate["all_checkpoints"] = [r["checkpoints"] for r in all_results]
    aggregate["per_seed"] = [{k: r.get(k) for k in
                              ("seed", "wsb_mode", "is_local", "h_basin_mean",
                               "h_local_max_overall", "h_noise_control_mean",
                               "n_collapses", "final_reward")}
                             for r in all_results]
    aggregate["all_seeds_local"] = all(r.get("is_local", False) for r in all_results)
    if tracker:
        tracker.set_metadata("aggregate", aggregate)
    if logger:
        logger.info(f"\nOption A Complete. H_basin: {aggregate.get('h_basin_mean_mean', 0):.4f} +/- {aggregate.get('h_basin_mean_std', 0):.4f}")
    return aggregate
