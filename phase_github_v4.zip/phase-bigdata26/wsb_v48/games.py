"""
WSB Framework - Game Theory Module
===================================
Game definitions, learning dynamics, and analytical WSB validation.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from abc import ABC, abstractmethod

from .config import OptionCConfig
from .core import compute_basin_entropy, StatisticalTests, analyze_distribution_inversion

# Games
class MatrixGame:
    def __init__(self, name: str, pm1: np.ndarray, pm2: np.ndarray):
        self.name, self.pm1, self.pm2 = name, np.array(pm1), np.array(pm2)
    
    @property
    def n_actions(self) -> Tuple[int, int]:
        return self.pm1.shape
    
    def payoff(self, a1: int, a2: int) -> Tuple[float, float]:
        return float(self.pm1[a1, a2]), float(self.pm2[a1, a2])
    
    def expected_payoff(self, s1: np.ndarray, s2: np.ndarray) -> Tuple[float, float]:
        return float(s1 @ self.pm1 @ s2), float(s1 @ self.pm2 @ s2)
    
    def best_response(self, player: int, opp_strategy: np.ndarray) -> np.ndarray:
        if player == 0:
            payoffs = self.pm1 @ opp_strategy
        else:
            payoffs = self.pm2.T @ opp_strategy
        br = np.zeros(len(payoffs))
        br[np.argmax(payoffs)] = 1.0
        return br
    
    def get_nash_equilibria(self) -> List[Tuple[np.ndarray, np.ndarray]]:
        equilibria = []
        n1, n2 = self.n_actions
        # Pure Nash
        for a1 in range(n1):
            for a2 in range(n2):
                if self.pm1[a1, a2] >= np.max(self.pm1[:, a2]) and self.pm2[a1, a2] >= np.max(self.pm2[a1, :]):
                    s1, s2 = np.zeros(n1), np.zeros(n2)
                    s1[a1], s2[a2] = 1.0, 1.0
                    equilibria.append((s1, s2))
        # Mixed Nash for 2x2
        if self.n_actions == (2, 2):
            mixed = self._compute_2x2_mixed()
            if mixed is not None:
                equilibria.append(mixed)
        return equilibria
    
    def _compute_2x2_mixed(self) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        try:
            denom1 = self.pm2[0, 0] - self.pm2[0, 1] - self.pm2[1, 0] + self.pm2[1, 1]
            denom2 = self.pm1[0, 0] - self.pm1[1, 0] - self.pm1[0, 1] + self.pm1[1, 1]
            if abs(denom1) < 1e-10 or abs(denom2) < 1e-10:
                return None
            p1 = (self.pm2[1, 1] - self.pm2[1, 0]) / denom1
            p2 = (self.pm1[1, 1] - self.pm1[0, 1]) / denom2
            if 0 < p1 < 1 and 0 < p2 < 1:
                return (np.array([p1, 1 - p1]), np.array([p2, 1 - p2]))
        except Exception:
            pass
        return None
    
    def get_analytical_wsb(self) -> Optional[Dict]:
        """Get analytically known WSB location for this game."""
        if self.name == "Stag Hunt":
            # WSB at p where expected payoffs are equal
            # E[Stag] = p*stag + (1-p)*0 = p*stag
            # E[Hare] = p*temptation + (1-p)*hare
            # Equal when: p*stag = p*temptation + (1-p)*hare
            # p*(stag - temptation + hare) = hare
            # p = hare / (stag - temptation + hare)
            stag, hare, tempt = self.pm1[0, 0], self.pm1[1, 1], self.pm1[1, 0]
            denom = stag - tempt + hare
            if abs(denom) > 1e-10:
                p_wsb = hare / denom
                if 0 < p_wsb < 1:
                    return {"type": "stag_hunt", "p_wsb": p_wsb, "formula": "hare / (stag - temptation + hare)"}
        return None

def create_stag_hunt(stag=4.0, hare=3.0, temptation=3.0) -> MatrixGame:
    pm = np.array([[stag, 0], [temptation, hare]])
    return MatrixGame("Stag Hunt", pm, pm.T)

def create_battle_of_sexes(high=3.0, low=1.0) -> MatrixGame:
    return MatrixGame("Battle of Sexes", np.array([[high, 0], [0, low]]), np.array([[low, 0], [0, high]]))

def create_prisoners_dilemma(R=3.0, T=5.0, S=0.0, P=1.0) -> MatrixGame:
    pm = np.array([[R, S], [T, P]])
    return MatrixGame("Prisoner's Dilemma", pm, pm.T)

def create_coordination(payoff=1.0) -> MatrixGame:
    pm = np.array([[payoff, 0], [0, payoff]])
    return MatrixGame("Coordination", pm, pm)

def create_matching_pennies() -> MatrixGame:
    pm1 = np.array([[1, -1], [-1, 1]])
    return MatrixGame("Matching Pennies", pm1, -pm1)

# Learning Dynamics
class LearningDynamics(ABC):
    @abstractmethod
    def step(self, game: MatrixGame, strategies: List[np.ndarray]) -> List[np.ndarray]:
        pass

    def reset(self):
        """Reset ALL mutable state. Called before every perturbation rollout
        so trajectories are independent (v31.0 reset only FictitiousPlay;
        LogitResponse leaked step_count across cloud points, making the
        temperature schedule depend on evaluation order)."""
        pass

    # Verification phase after a small-step trigger: an attracting fixed
    # point keeps the trajectory inside a ~tol/(1-contraction) ball, while a
    # slowly moving state (edge crawl, tiny-radius orbit around a center)
    # keeps drifting and accumulates ~VERIFY_STEPS*tol of displacement. A
    # single-step velocity threshold alone cannot tell these apart: on
    # Matching Pennies, Euler replicator spirals to the simplex boundary and
    # crawls along it with per-step change below tol, which a naive test
    # declares "converged" and maps to the nearest Nash point.
    VERIFY_STEPS = 200
    VERIFY_BALL = 50.0  # in units of tol

    def run(self, game: MatrixGame, initial: List[np.ndarray], n_steps: int,
            tol: float = 1e-6) -> Tuple[List[np.ndarray], List[List[np.ndarray]], bool]:
        """Returns (final_strategies, history, converged).

        converged=True iff (a) the per-step change fell below tol AND (b) a
        verification phase of VERIFY_STEPS further steps stays within
        VERIFY_BALL*tol of the candidate point. Cycles, orbits, and slow
        boundary crawls report False; the regime classifier maps them to the
        nonconvergent phase instead of a nearest-Nash label.

        NOTE: fictitious play's step size decays like 1/t, so with small
        budgets it never trips the tol criterion; regime classification under
        fictitious play needs a larger n_steps or a scaled tol.
        """
        strategies = [s.copy() for s in initial]
        history = [strategies]
        converged = False
        for _ in range(n_steps):
            new_strategies = self.step(game, strategies)
            history.append(new_strategies)
            diff = max(np.max(np.abs(new_strategies[i] - strategies[i])) for i in range(len(strategies)))
            strategies = new_strategies
            if diff < tol:
                # candidate fixed point: verify it is actually attracting
                anchor = [s.copy() for s in strategies]
                max_dev = 0.0
                for _ in range(self.VERIFY_STEPS):
                    strategies = self.step(game, strategies)
                    dev = max(np.max(np.abs(strategies[i] - anchor[i]))
                              for i in range(len(strategies)))
                    max_dev = max(max_dev, dev)
                    if max_dev >= self.VERIFY_BALL * tol:
                        break
                converged = max_dev < self.VERIFY_BALL * tol
                history.append(strategies)
                break
        return strategies, history, converged

class ReplicatorDynamics(LearningDynamics):
    def __init__(self, dt=0.1, mutation=0.0):
        self.dt, self.mutation = dt, mutation
    
    def step(self, game: MatrixGame, strategies: List[np.ndarray]) -> List[np.ndarray]:
        s1, s2 = strategies
        p1, p2 = game.pm1 @ s2, game.pm2.T @ s1
        ds1 = s1 * (p1 - s1 @ p1) * self.dt
        ds2 = s2 * (p2 - s2 @ p2) * self.dt
        if self.mutation > 0:
            u1, u2 = np.ones_like(s1) / len(s1), np.ones_like(s2) / len(s2)
            ds1 += self.mutation * (u1 - s1) * self.dt
            ds2 += self.mutation * (u2 - s2) * self.dt
        new_s1 = np.clip(s1 + ds1, 1e-10, 1)
        new_s2 = np.clip(s2 + ds2, 1e-10, 1)
        return [new_s1 / new_s1.sum(), new_s2 / new_s2.sum()]

    def step_batch(self, game: MatrixGame, S1: np.ndarray, S2: np.ndarray):
        """Vectorized step over N trajectories (S1[N,a1], S2[N,a2]). Same
        arithmetic as step(): row i of the batch equals step() on row i."""
        P1 = S2 @ game.pm1.T                                  # [N, a1]
        P2 = S1 @ game.pm2                                    # [N, a2]
        avg1 = np.sum(S1 * P1, axis=1, keepdims=True)
        avg2 = np.sum(S2 * P2, axis=1, keepdims=True)
        dS1 = S1 * (P1 - avg1) * self.dt
        dS2 = S2 * (P2 - avg2) * self.dt
        if self.mutation > 0:
            dS1 += self.mutation * (1.0 / S1.shape[1] - S1) * self.dt
            dS2 += self.mutation * (1.0 / S2.shape[1] - S2) * self.dt
        N1 = np.clip(S1 + dS1, 1e-10, 1)
        N2 = np.clip(S2 + dS2, 1e-10, 1)
        return N1 / N1.sum(axis=1, keepdims=True), N2 / N2.sum(axis=1, keepdims=True)

class FictitiousPlay(LearningDynamics):
    def __init__(self, initial_weight=10.0):
        self.initial_weight = initial_weight
        self.counts = None
    
    def step(self, game: MatrixGame, strategies: List[np.ndarray]) -> List[np.ndarray]:
        if self.counts is None:
            self.counts = [s.copy() * self.initial_weight for s in strategies]
        s1, s2 = strategies
        br1, br2 = game.best_response(0, s2), game.best_response(1, s1)
        self.counts[0] += br1
        self.counts[1] += br2
        return [self.counts[0] / self.counts[0].sum(), self.counts[1] / self.counts[1].sum()]
    
    def reset(self):
        self.counts = None

class LogitResponse(LearningDynamics):
    def __init__(self, temperature=1.0, decay=0.0):
        self.temperature, self.decay = temperature, decay
        self.step_count = 0

    def reset(self):
        self.step_count = 0
    
    def step(self, game: MatrixGame, strategies: List[np.ndarray]) -> List[np.ndarray]:
        s1, s2 = strategies
        temp = max(self.temperature / (1 + self.decay * self.step_count), 1e-8)
        u1 = (game.pm1 @ s2) / temp
        u2 = (game.pm2.T @ s1) / temp
        p1 = np.exp(u1 - u1.max())   # shift-invariant softmax: no overflow
        p2 = np.exp(u2 - u2.max())
        self.step_count += 1
        return [p1 / p1.sum(), p2 / p2.sum()]

    def step_batch(self, game: MatrixGame, S1: np.ndarray, S2: np.ndarray):
        """Vectorized step: all trajectories share the step counter (each is
        reset to 0 and advances in lockstep, so per-row temperature equals
        the scalar path's)."""
        temp = max(self.temperature / (1 + self.decay * self.step_count), 1e-8)
        U1 = (S2 @ game.pm1.T) / temp
        U2 = (S1 @ game.pm2) / temp
        P1 = np.exp(U1 - U1.max(axis=1, keepdims=True))
        P2 = np.exp(U2 - U2.max(axis=1, keepdims=True))
        self.step_count += 1
        return P1 / P1.sum(axis=1, keepdims=True), P2 / P2.sum(axis=1, keepdims=True)

class GradientPlay(LearningDynamics):
    def __init__(self, lr=0.1):
        self.lr = lr
    
    def _project_simplex(self, x):
        u = np.sort(x)[::-1]
        cssv = np.cumsum(u)
        rho = np.nonzero(u * np.arange(1, len(u) + 1) > (cssv - 1))[0]
        if len(rho) == 0:
            return np.ones_like(x) / len(x)
        theta = (cssv[rho[-1]] - 1) / (rho[-1] + 1)
        return np.maximum(x - theta, 0)
    
    def step(self, game: MatrixGame, strategies: List[np.ndarray]) -> List[np.ndarray]:
        s1, s2 = strategies
        g1, g2 = game.pm1 @ s2, game.pm2.T @ s1
        return [self._project_simplex(s1 + self.lr * g1), self._project_simplex(s2 + self.lr * g2)]

# Phase Classifiers
class DynamicalRegimeClassifier:
    """
    Classifies by ASYMPTOTIC DYNAMICAL REGIME, not by nearest Nash point.

    Rationale (mandatory reviewer fix): a Nash equilibrium is not necessarily
    an attractor of the learning dynamics. In Stag Hunt / Battle of the Sexes
    the interior mixed equilibrium is an unstable saddle on the separatrix;
    counting it as a basin phase changes the measured object from "entropy
    over nearby dynamical basins" to "entropy over nearest Nash points after
    finite integration". Under this classifier:

      phases 0..len(NE)-1 : CONVERGED trajectories, labeled by the nearest
          equilibrium point. Unstable equilibria are measure-zero limits of
          generic trajectories, so they do not pollute the phase counts; if a
          dynamic genuinely converges near the mixed point (e.g. logit
          response / QRE), that IS its attractor and is counted faithfully.
      phase len(NE)        : NONCONVERGENT regime (cycles / orbiting / no
          fixed point within the step budget). This also fixes the
          one-equilibrium null (H=0 is now demonstrated, not structural) and
          makes Matching Pennies under replicator a valid null: all
          trajectories land in the cycle phase.
    """
    def __init__(self, equilibria: List[Tuple[np.ndarray, np.ndarray]]):
        self.eq = equilibria

    @property
    def n_phases(self) -> int:
        return len(self.eq) + 1  # +1: nonconvergent/cycle phase

    @property
    def nonconvergent_phase(self) -> int:
        return len(self.eq)

    def classify(self, strategy_vector: np.ndarray, converged: bool) -> int:
        if not converged:
            return self.nonconvergent_phase
        if len(self.eq) == 0:
            return self.nonconvergent_phase
        dists = [np.linalg.norm(strategy_vector - np.concatenate(e))
                 for e in self.eq]
        return int(np.argmin(dists))


class NearestNashClassifier:
    def __init__(self, equilibria: List[Tuple[np.ndarray, np.ndarray]]):
        self.equilibria = equilibria
        self._n_phases = max(len(equilibria), 2)
    
    @property
    def n_phases(self) -> int:
        return self._n_phases
    
    def classify(self, strategy_vector: np.ndarray) -> int:
        if len(self.equilibria) == 0:
            return 0
        min_dist, nearest = float('inf'), 0
        for i, (eq1, eq2) in enumerate(self.equilibria):
            dist = np.linalg.norm(strategy_vector - np.concatenate([eq1, eq2]))
            if dist < min_dist:
                min_dist, nearest = dist, i
        return nearest

# Game Analyzer
class GameAnalyzer:
    def __init__(self, config: OptionCConfig, logger=None):
        self.config, self.logger = config, logger
        self.game = self._create_game()
        self.dynamics = self._create_dynamics()
        self.nash = self.game.get_nash_equilibria()
        self.analytical_wsb = self.game.get_analytical_wsb()
        if logger:
            logger.info(f"Game: {config.game_type}, Dynamics: {config.dynamics}, Nash: {len(self.nash)}")
            if self.analytical_wsb:
                logger.info(f"  Analytical WSB: p = {self.analytical_wsb.get('p_wsb', 'N/A'):.4f}")
    
    def _create_game(self) -> MatrixGame:
        if self.config.game_type == "stag_hunt":
            return create_stag_hunt(self.config.stag_payoff, self.config.hare_payoff, self.config.temptation)
        elif self.config.game_type == "battle_of_sexes":
            return create_battle_of_sexes(self.config.bos_high, self.config.bos_low)
        elif self.config.game_type == "prisoners_dilemma":
            return create_prisoners_dilemma(self.config.pd_reward, self.config.pd_temptation, self.config.pd_sucker, self.config.pd_punishment)
        elif self.config.game_type == "matching_pennies":
            return create_matching_pennies()
        elif self.config.game_type == "coordination":
            return create_coordination()
        return create_stag_hunt()
    
    def _create_dynamics(self) -> LearningDynamics:
        if self.config.dynamics == "replicator":
            return ReplicatorDynamics(self.config.replicator_dt, self.config.replicator_mutation)
        elif self.config.dynamics == "fictitious_play":
            return FictitiousPlay(self.config.fp_initial_weight)
        elif self.config.dynamics == "logit_response":
            return LogitResponse(self.config.logit_temperature, self.config.logit_temperature_decay)
        elif self.config.dynamics == "gradient_play":
            return GradientPlay(self.config.dynamics_lr)
        return ReplicatorDynamics()
    
    def _perturb_simplex(self, s: np.ndarray,
                         offset: Optional[np.ndarray] = None) -> np.ndarray:
        if offset is None:
            offset = np.random.uniform(-self.config.epsilon,
                                       self.config.epsilon, len(s))
        p = np.clip(s + offset, 0.01, 1.0)
        return p / p.sum()

    def _make_phase_classifier(self, regime_clf):
        """Honor config.game_phase_classifier (the v31.0 ablation silently ran
        NearestNash for every requested classifier). "nearest_nash" maps to
        the dynamical-regime classifier; the strategy-space alternatives
        classify the final point and route nonconvergent runs to their own
        extra phase so no classifier hides cycling."""
        from .classifiers import ActionProfileClassifier, EquilibriumTypeClassifier
        kind = getattr(self.config, "game_phase_classifier", "nearest_nash")
        if kind in ("nearest_nash", "dynamical_regime"):
            return ("regime", regime_clf, regime_clf.n_phases)
        if kind == "action_profile":
            c = ActionProfileClassifier(self.game.n_actions)
            return ("strategy", c, c.n_phases + 1)
        if kind == "equilibrium_type":
            c = EquilibriumTypeClassifier()
            return ("strategy", c, c.n_phases + 1)
        raise ValueError(f"Unsupported game_phase_classifier: {kind}")

    def _run_batch(self, S1: np.ndarray, S2: np.ndarray):
        """
        Vectorized equivalent of LearningDynamics.run over N trajectories.
        Semantics identical to the scalar path per row:
          - main phase up to n_steps; a row whose per-step change drops below
            tol enters VERIFICATION with its current state as anchor;
          - verification: VERIFY_STEPS further steps must stay within
            VERIFY_BALL*tol of the anchor -> converged, else nonconverged
            (a row that fails verification is finished, it does not resume);
          - a row that never trips tol within n_steps is nonconverged.
        Returns (final_S1, final_S2, converged[N]). Deterministic: identical
        results to running each row through the scalar path.
        """
        n_steps = self.config.dynamics_steps
        tol = self.config.convergence_threshold
        dyn = self.dynamics
        VS, VB = dyn.VERIFY_STEPS, dyn.VERIFY_BALL * tol
        N = S1.shape[0]
        S1, S2 = S1.copy(), S2.copy()
        RUNNING, VERIFYING, DONE = 0, 1, 2
        state = np.full(N, RUNNING, dtype=np.int8)
        converged = np.zeros(N, dtype=bool)
        A1, A2 = np.zeros_like(S1), np.zeros_like(S2)   # verification anchors
        vleft = np.zeros(N, dtype=np.int64)
        maxdev = np.zeros(N)

        for t in range(n_steps + VS + 1):
            # Main budget: a RUNNING row that has taken n_steps steps without
            # a tol trip is nonconverged - marked BEFORE stepping so it takes
            # exactly n_steps steps, matching the scalar path.
            if t >= n_steps:
                state[state == RUNNING] = DONE
            live = state != DONE
            if not live.any():
                break
            N1, N2 = dyn.step_batch(self.game, S1, S2)
            diff = np.maximum(np.max(np.abs(N1 - S1), axis=1),
                              np.max(np.abs(N2 - S2), axis=1))
            # freeze finished rows
            N1[~live], N2[~live] = S1[~live], S2[~live]
            S1, S2 = N1, N2

            # tol trip -> enter verification, anchored at the post-trip state
            trip = (state == RUNNING) & (diff < tol)
            if trip.any():
                state[trip] = VERIFYING
                A1[trip], A2[trip] = S1[trip], S2[trip]
                vleft[trip] = VS
                maxdev[trip] = 0.0
            # verification: deviation accrues from the step AFTER anchoring
            ver = (state == VERIFYING) & ~trip
            if ver.any():
                dev = np.maximum(np.max(np.abs(S1 - A1), axis=1),
                                 np.max(np.abs(S2 - A2), axis=1))
                maxdev[ver] = np.maximum(maxdev[ver], dev[ver])
                escaped = ver & (maxdev >= VB)
                state[escaped] = DONE            # nonconverged
                vleft[ver] -= 1
                finished = ver & ~escaped & (vleft <= 0)
                converged[finished] = True
                state[finished] = DONE
        return S1, S2, converged

    def _classify_finals(self, mode, clf, K, S1, S2, converged) -> np.ndarray:
        finals = np.concatenate([S1, S2], axis=1)
        out = np.empty(len(S1), dtype=np.int64)
        for i in range(len(S1)):
            if mode == "regime":
                out[i] = clf.classify(finals[i], bool(converged[i]))
            elif not converged[i]:
                out[i] = K - 1
            else:
                out[i] = clf.classify(finals[i])
        return out

    def _run_to_phase(self, mode, clf, K, s1: np.ndarray, s2: np.ndarray) -> int:
        self.dynamics.reset()  # ALL dynamics reset before every rollout
        final, _, converged = self.dynamics.run(
            self.game, [s1, s2], self.config.dynamics_steps,
            self.config.convergence_threshold)
        if mode == "regime":
            return clf.classify(np.concatenate(final), converged)
        # strategy-space classifier: nonconvergent runs get the extra phase
        if not converged:
            return K - 1
        return clf.classify(np.concatenate(final))

    def compute_h_basin_current(self, base_points=None, pert_offsets=None
                                ) -> Tuple[float, np.ndarray]:
        """
        Per-base-point LOCAL basin entropy over DYNAMICAL REGIMES.

        Each base point gets a cloud of epsilon-perturbations run to their
        asymptotic regime; per-point entropies aggregate to H_mean/H_max.
        Phases are dynamical regimes (converged-to-attractor or cycle/
        nonconvergent), NOT nearest Nash points - see
        DynamicalRegimeClassifier for why this distinction is load-bearing.

        base_points/pert_offsets enable COMMON RANDOM NUMBERS across a
        parameter sweep: the same base points and the same cloud offsets are
        reused at every parameter value, so sweep-to-sweep differences in H
        reflect the parameter, not Monte Carlo resampling (which previously
        generated spurious local maxima flagged as WSB candidates).
          base_points: list of (s1, s2) tuples.
          pert_offsets: array [n_base, n_pert, 2, n_actions] of raw offsets.
        Backwards-compatible return: (h_mean, pooled_counts); full statistics
        in self.last_local_stats.
        """
        self.nash = self.game.get_nash_equilibria()
        regime_clf = DynamicalRegimeClassifier(self.nash)
        mode, clf, K = self._make_phase_classifier(regime_clf)
        n1, n2 = self.game.n_actions

        n_base = max(4, getattr(self.config, "n_probe_points", 100) // 4)
        n_pert = self.config.n_perturbations
        if base_points is None:
            base_points = [(np.random.dirichlet(np.ones(n1) * 2),
                            np.random.dirichlet(np.ones(n2) * 2))
                           for _ in range(n_base)]
        n_base = len(base_points)

        # Build every cloud point first (same values and the same np.random
        # draw order as the per-trajectory path, so results are identical),
        # then run all n_base*n_pert trajectories in ONE vectorized batch
        # when the dynamics implements step_batch (replicator, logit).
        # Fictitious play / gradient play fall back to the scalar path.
        cloud1 = np.empty((n_base * n_pert, n1))
        cloud2 = np.empty((n_base * n_pert, n2))
        for bi, (base_s1, base_s2) in enumerate(base_points):
            for pi in range(n_pert):
                if pert_offsets is not None:
                    o1, o2 = pert_offsets[bi, pi, 0, :n1], pert_offsets[bi, pi, 1, :n2]
                else:
                    o1 = o2 = None
                r = bi * n_pert + pi
                cloud1[r] = self._perturb_simplex(base_s1, o1)
                cloud2[r] = self._perturb_simplex(base_s2, o2)

        if hasattr(self.dynamics, "step_batch"):
            self.dynamics.reset()
            F1, F2, conv = self._run_batch(cloud1, cloud2)
            phases = self._classify_finals(mode, clf, K, F1, F2, conv)
        else:
            phases = np.array([self._run_to_phase(mode, clf, K,
                                                  cloud1[r], cloud2[r])
                               for r in range(n_base * n_pert)])

        per_point_h, per_point_counts = [], []
        for bi in range(n_base):
            counts = np.zeros(K)
            for pi in range(n_pert):
                p = phases[bi * n_pert + pi]
                if 0 <= p < K:
                    counts[p] += 1
            per_point_h.append(compute_basin_entropy(counts))
            per_point_counts.append(counts)

        h_arr = np.array(per_point_h)
        pooled = np.sum(per_point_counts, axis=0)
        n_attractors = max(1, int((pooled > 0).sum()))
        log_na = np.log(n_attractors) if n_attractors > 1 else 1.0
        self.last_local_stats = {
            "h_mean": float(h_arr.mean()), "h_max": float(h_arr.max()),
            "h_std": float(h_arr.std()),
            "h_mean_normalized": float(h_arr.mean() / log_na) if n_attractors > 1 else 0.0,
            "h_max_normalized": float(h_arr.max() / log_na) if n_attractors > 1 else 0.0,
            "n_attractors": n_attractors,
            "n_phases_available": K,
            "nonconvergent_fraction": float(pooled[-1] / max(pooled.sum(), 1))
                if mode == "regime" else None,
            "n_base_points": n_base,
            "per_point_h": h_arr.tolist(),
            "pooled_counts": pooled.tolist(),
        }
        return float(h_arr.mean()), pooled

    _SWEEPABLE = {
        "stag_hunt": {"stag_payoff", "hare_payoff", "temptation"},
        "battle_of_sexes": {"bos_high", "bos_low"},
        "prisoners_dilemma": {"pd_reward", "pd_temptation"},
    }

    def compute_h_basin(self, param_value: float, base_points=None,
                        pert_offsets=None) -> Tuple[float, np.ndarray]:
        """Update the game with the swept parameter, then compute H.
        UNSUPPORTED (game, parameter) combinations RAISE instead of silently
        sweeping nothing (v31.0's full-experiment ran a Prisoner's Dilemma
        "sweep" over stag_payoff, which never touched the game)."""
        gt, var = self.config.game_type, self.config.param_sweep_var
        if gt not in self._SWEEPABLE or var not in self._SWEEPABLE[gt]:
            raise ValueError(
                f"param_sweep_var='{var}' does not affect game_type='{gt}'. "
                f"Supported: {self._SWEEPABLE.get(gt, set())}")
        if gt == "stag_hunt":
            args = {"stag": self.config.stag_payoff,
                    "hare": self.config.hare_payoff,
                    "temptation": self.config.temptation}
            args[{"stag_payoff": "stag", "hare_payoff": "hare",
                  "temptation": "temptation"}[var]] = param_value
            self.game = create_stag_hunt(**args)
        elif gt == "battle_of_sexes":
            args = {"high": self.config.bos_high, "low": self.config.bos_low}
            args[{"bos_high": "high", "bos_low": "low"}[var]] = param_value
            self.game = create_battle_of_sexes(**args)
        elif gt == "prisoners_dilemma":
            args = {"R": self.config.pd_reward, "T": self.config.pd_temptation,
                    "S": self.config.pd_sucker, "P": self.config.pd_punishment}
            args[{"pd_reward": "R", "pd_temptation": "T"}[var]] = param_value
            self.game = create_prisoners_dilemma(**args)
        return self.compute_h_basin_current(base_points=base_points,
                                            pert_offsets=pert_offsets)
    
    def run_1d_sweep(self, tracker=None) -> Dict:
        if self.logger:
            self.logger.info(f"1D Sweep: {self.config.param_sweep_var}, Range: {self.config.param_sweep_range}")
        
        params = np.linspace(self.config.param_sweep_range[0], self.config.param_sweep_range[1], self.config.param_sweep_steps)
        results = []

        # COMMON RANDOM NUMBERS: draw base points and cloud offsets ONCE and
        # reuse them at every parameter value, so H differences along the
        # sweep reflect the parameter, not Monte Carlo resampling. The CRN
        # seed derives from the CALLER'S seeded global state: within-sweep
        # variance is eliminated while different experiment seeds still get
        # independent base-point/offset sets. (A fixed rng(0) here made all
        # n_seeds sweeps byte-identical, i.e. effectively n=1.)
        rng = np.random.default_rng(np.random.randint(0, 2**31))
        n1, n2 = self.game.n_actions
        n_base = max(4, getattr(self.config, "n_probe_points", 100) // 4)
        n_pert = self.config.n_perturbations
        base_points = [(rng.dirichlet(np.ones(n1) * 2),
                        rng.dirichlet(np.ones(n2) * 2)) for _ in range(n_base)]
        max_a = max(n1, n2)
        pert_offsets = rng.uniform(-self.config.epsilon, self.config.epsilon,
                                   size=(n_base, n_pert, 2, max_a))

        for i, param in enumerate(params):
            h, counts = self.compute_h_basin(param, base_points=base_points,
                                             pert_offsets=pert_offsets)
            analytical = self.game.get_analytical_wsb()
            ls = getattr(self, "last_local_stats", {})
            results.append({"param": float(param), "h_basin": h,
                            "h_max": ls.get("h_max", h),
                            "h_mean_normalized": ls.get("h_mean_normalized", 0.0),
                            "h_max_normalized": ls.get("h_max_normalized", 0.0),
                            "n_attractors": ls.get("n_attractors", len(self.nash)),
                            "analytical_p_mixed": (analytical.get("p_wsb")
                                                   if analytical else None),
                            "counts": counts.tolist(), "n_nash": len(self.nash)})
            if tracker:
                tracker.log("param", param, i)
                tracker.log("h_basin", h, i)
            if self.logger and (i + 1) % max(1, len(params) // 5) == 0:
                self.logger.info(f"  Param {param:.3f} ({i+1}/{len(params)}) | H: {h:.4f}")
        
        return self._analyze_sweep(results, tracker)
    
    def run_2d_sweep(self, tracker=None) -> Dict:
        if not self.config.param_sweep_2d:
            return self.run_1d_sweep(tracker)
        
        if self.logger:
            self.logger.info(f"2D Sweep: {self.config.param_sweep_var} x {self.config.param_sweep_var_2}")
        
        params1 = np.linspace(self.config.param_sweep_range[0], self.config.param_sweep_range[1], self.config.param_sweep_steps)
        params2 = np.linspace(self.config.param_sweep_range_2[0], self.config.param_sweep_range_2[1], self.config.param_sweep_steps_2)
        
        heatmap = np.zeros((len(params1), len(params2)))
        
        for i, p1 in enumerate(params1):
            for j, p2 in enumerate(params2):
                # Set both parameters correctly based on config
                if self.config.game_type == "stag_hunt":
                    stag = p1 if self.config.param_sweep_var == "stag_payoff" else (p2 if self.config.param_sweep_var_2 == "stag_payoff" else self.config.stag_payoff)
                    hare = p1 if self.config.param_sweep_var == "hare_payoff" else (p2 if self.config.param_sweep_var_2 == "hare_payoff" else self.config.hare_payoff)
                    tempt = p1 if self.config.param_sweep_var == "temptation" else (p2 if self.config.param_sweep_var_2 == "temptation" else self.config.temptation)
                    self.game = create_stag_hunt(stag, hare, tempt)
                elif self.config.game_type == "battle_of_sexes":
                    high = p1 if self.config.param_sweep_var == "bos_high" else (p2 if self.config.param_sweep_var_2 == "bos_high" else self.config.bos_high)
                    low = p1 if self.config.param_sweep_var == "bos_low" else (p2 if self.config.param_sweep_var_2 == "bos_low" else self.config.bos_low)
                    self.game = create_battle_of_sexes(high, low)
                elif self.config.game_type == "prisoners_dilemma":
                    # For PD, sweep R and T typically
                    R = p1 if self.config.param_sweep_var == "pd_reward" else (p2 if self.config.param_sweep_var_2 == "pd_reward" else self.config.pd_reward)
                    T = p1 if self.config.param_sweep_var == "pd_temptation" else (p2 if self.config.param_sweep_var_2 == "pd_temptation" else self.config.pd_temptation)
                    self.game = create_prisoners_dilemma(R, T, self.config.pd_sucker, self.config.pd_punishment)
                
                # Compute H_basin on current game (don't modify game again).
                # Reuse one CRN set across the whole heatmap (see run_1d_sweep).
                if i == 0 and j == 0:
                    rng2 = np.random.default_rng(np.random.randint(0, 2**31))
                    _n1, _n2 = self.game.n_actions
                    _nb = max(4, getattr(self.config, "n_probe_points", 100) // 4)
                    _np_ = self.config.n_perturbations
                    _bp = [(rng2.dirichlet(np.ones(_n1) * 2),
                            rng2.dirichlet(np.ones(_n2) * 2)) for _ in range(_nb)]
                    _po = rng2.uniform(-self.config.epsilon, self.config.epsilon,
                                       size=(_nb, _np_, 2, max(_n1, _n2)))
                h, _ = self.compute_h_basin_current(base_points=_bp, pert_offsets=_po)
                heatmap[i, j] = h
            
            if self.logger:
                self.logger.info(f"  Row {i+1}/{len(params1)}")
        
        return {
            "params1": params1.tolist(),
            "params2": params2.tolist(),
            "heatmap": heatmap.tolist(),
            "param1_name": self.config.param_sweep_var,
            "param2_name": self.config.param_sweep_var_2,
        }
    
    def _analyze_sweep(self, results: List[Dict], tracker=None) -> Dict:
        params = np.array([r["param"] for r in results])
        h_basin = np.array([r["h_basin"] for r in results])
        
        # WSB candidates: local maxima with PROMINENCE above a threshold.
        # With common random numbers the sweep noise is already suppressed,
        # but a one-pixel strict maximum (v30) still flags any residual
        # fluctuation; require the peak to rise at least min_prominence above
        # the higher of the two flanking valleys.
        min_prominence = 0.05  # nats
        wsb_indices = []
        for i in range(1, len(h_basin) - 1):
            if not (h_basin[i] > h_basin[i-1] and h_basin[i] > h_basin[i+1]):
                continue
            j = i - 1
            while j > 0 and h_basin[j-1] < h_basin[j]:
                j -= 1
            k = i + 1
            while k < len(h_basin) - 1 and h_basin[k+1] < h_basin[k]:
                k += 1
            prominence = h_basin[i] - max(h_basin[j], h_basin[k])
            if prominence >= min_prominence:
                wsb_indices.append(i)
        
        analysis = {
            "params": params.tolist(),
            "h_basin": h_basin.tolist(),
            "wsb_params": [float(params[i]) for i in wsb_indices],
            "n_wsb_candidates": len(wsb_indices),
            "max_h_basin": float(np.max(h_basin)),
            "max_h_param": float(params[np.argmax(h_basin)]),
            "mean_h_basin": float(np.mean(h_basin)),
        }
        
        # Analytical validation: bistability-region agreement.
        # NOTE: p_wsb is a strategy-space coordinate; the sweep axis is a
        # payoff parameter. The two are NOT comparable, so we do not report a
        # location error between them (v30 did, which was ill-defined).
        # The exact, checkable statement: an interior mixed equilibrium
        # exists iff the game is bistable, and per-point basin entropy can
        # be positive only in the bistable region. We report the agreement
        # between {param : H_mean > tau} and {param : p_mixed exists}.
        if self.config.compute_analytical_wsb:
            bistable_pred = np.array([r.get("analytical_p_mixed") is not None
                                      for r in results])
            if bistable_pred.any():
                tau = 0.05 * float(np.log(2))
                h_active = h_basin > tau
                agree = float(np.mean(h_active == bistable_pred))
                fp = int(np.sum(h_active & ~bistable_pred))
                analysis["bistable_region_agreement"] = agree
                analysis["h_active_outside_bistable_region"] = fp
                analysis["bistable_params"] = params[bistable_pred].tolist()
        
        # Uniformity tests at WSB candidates. NOTE: these use POOLED counts
        # (sum over base points), i.e. basin-fraction statistics -- a
        # different object from the per-point local entropies that define
        # H_mean/H_max. Keys are suffixed _pooled to keep the distinction.
        for i, idx in enumerate(wsb_indices[:3]):
            counts = np.array(results[idx]["counts"])
            uniformity = StatisticalTests.chi_squared_uniformity(counts)
            analysis[f"wsb_{i}_uniformity_p_pooled"] = uniformity["p_value"]
            analysis[f"wsb_{i}_is_uniform_pooled"] = uniformity["is_uniform"]
            analysis[f"wsb_{i}_chi2_valid"] = uniformity.get("chi2_valid", False)
        
        # Distribution inversion
        phase_counts = [np.array(r["counts"]) for r in results]
        if len(phase_counts) > 5:
            try:
                inversion = analyze_distribution_inversion(h_basin, phase_counts)
                analysis["distribution_inversion_pooled"] = inversion.to_dict()
            except Exception:
                pass
        
        if tracker:
            tracker.set_metadata("analysis", analysis)
        
        # Verbose logging
        if self.logger:
            self.logger.info(f"\n--- Sweep Analysis ---")
            self.logger.info(f"  H_basin: max={analysis['max_h_basin']:.4f}, mean={analysis['mean_h_basin']:.4f}")
            self.logger.info(f"  WSB Candidates: {analysis['n_wsb_candidates']} at params {analysis['wsb_params']}")
            self.logger.info(f"  Max H at param: {analysis['max_h_param']:.4f}")
            
            if "bistable_region_agreement" in analysis:
                self.logger.info(f"  Bistable-region agreement: "
                                 f"{analysis['bistable_region_agreement']:.3f} "
                                 f"(H-active outside bistable region: "
                                 f"{analysis['h_active_outside_bistable_region']})")
            
            for i in range(min(3, len(wsb_indices))):
                p_val = analysis.get(f"wsb_{i}_uniformity_p_pooled")
                if p_val is None:
                    continue
                is_uniform = analysis.get(f"wsb_{i}_is_uniform_pooled", False)
                valid = analysis.get(f"wsb_{i}_chi2_valid", False)
                self.logger.info(f"  Uniformity (POOLED counts) WSB_{i}: "
                                 f"p={p_val:.4f}, uniform={is_uniform}, "
                                 f"chi2_valid={valid}")
            
            if "distribution_inversion_pooled" in analysis:
                di = analysis["distribution_inversion_pooled"]
                self.logger.info(f"  Distribution Inversion:")
                self.logger.info(f"    Low-H entropy:  {di.get('low_h_entropy', 0):.4f}")
                self.logger.info(f"    High-H entropy: {di.get('high_h_entropy', 0):.4f}")
                self.logger.info(f"    Rare phase increase: {di.get('rare_phase_increase_factor', 0):.2f}x")
        
        return analysis

def run_option_c(config: OptionCConfig, logger=None, tracker=None) -> Dict:
    if logger:
        logger.info("=" * 60 + "\nOPTION C: Game Learning Dynamics\n" + "=" * 60)
    
    all_results = []
    for seed in range(config.n_seeds):
        if logger:
            logger.info(f"\n--- Seed {seed + 1}/{config.n_seeds} ---")
        np.random.seed(seed)
        analyzer = GameAnalyzer(config, logger)
        if config.param_sweep_2d:
            results = analyzer.run_2d_sweep(tracker)
        else:
            results = analyzer.run_1d_sweep(tracker)
        results["seed"] = seed
        all_results.append(results)
    
    aggregate = {
        "n_seeds": config.n_seeds,
        "game": config.game_type,
        "dynamics": config.dynamics,
    }
    
    # Aggregate WSB params
    all_wsb = []
    for r in all_results:
        all_wsb.extend(r.get("wsb_params", []))
    if all_wsb:
        aggregate["wsb_params_mean"] = float(np.mean(all_wsb))
        aggregate["wsb_params_std"] = float(np.std(all_wsb))
    
    # Aggregate other metrics
    for key in ["max_h_basin", "mean_h_basin", "wsb_error"]:
        values = [r.get(key) for r in all_results if r.get(key) is not None]
        if values:
            aggregate[f"{key}_mean"] = float(np.mean(values))
            aggregate[f"{key}_std"] = float(np.std(values))
    
    if tracker:
        tracker.set_metadata("aggregate", aggregate)
    
    if logger:
        logger.info(f"\nOption C Complete.")
        if "wsb_error_mean" in aggregate:
            logger.info(f"  WSB Error (vs analytical): {aggregate['wsb_error_mean']:.4f}")
    
    return aggregate
