"""
aa_reeval: AutoAttack re-evaluation of the confirmatory causal arms.

Reviewer request: AutoAttack numbers on at least baseline, high-LFR,
and random arms of the ten-seed replication, because PGD-20 can be
inflated by gradient masking. This module runs the identical arm-construction
protocol (same seeding discipline, same scoring statistic, same removal
rule, same retraining procedure as run_causal_intervention) and
evaluates each arm with the OFFICIAL AutoAttack package (standard
version) on a fixed test subset. It is a fresh battery under a stronger
attack, not a byte-level replay of historical arms. Requires: pip
install autoattack. No file in the existing pipeline is modified.

Per seed: baseline train + score + high-LFR retrain + random retrain +
three AutoAttack evaluations. The retrain seeding mirrors _retrain in
reviewer_proof (torch.manual_seed(seed) before each model build).
"""
import time
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from .adversarial import get_model, load_dataset, train_standard
from .reviewer_proof import _score_training_set
from .utils import save_results


def _clean_acc(model, ds, idx, device, batch_size=256):
    model.eval(); correct = 0
    with torch.no_grad():
        for a in range(0, len(idx), batch_size):
            chunk = idx[a:a + batch_size]
            xs, ys = zip(*[ds[int(i)] for i in chunk])
            xb = torch.stack(xs).to(device)
            yb = torch.tensor(ys).to(device)
            correct += int((model(xb).argmax(1) == yb).sum())
    return correct / len(idx)


def _aa_robust_acc(model, ds, idx, device, epsilon, batch_size=250,
                   logger=None, aa_version='apgd'):
    from autoattack import AutoAttack
    xs, ys = zip(*[ds[int(i)] for i in idx])
    x = torch.stack(xs).to(device)
    y = torch.tensor(ys).to(device)
    model.eval()
    if aa_version == 'standard':
        adversary = AutoAttack(model, norm='Linf', eps=epsilon,
                               version='standard', verbose=False)
    else:  # 'apgd': the deterministic gradient-masking check
        adversary = AutoAttack(model, norm='Linf', eps=epsilon,
                               version='custom',
                               attacks_to_run=['apgd-ce', 'apgd-dlr'],
                               verbose=False)
    adv = adversary.run_standard_evaluation(x, y, bs=batch_size)
    with torch.no_grad():
        robust = 0
        for a in range(0, len(idx), batch_size):
            robust += int((model(adv[a:a + batch_size]).argmax(1)
                           == y[a:a + batch_size]).sum())
    return robust / len(idx)


def run_aa_reeval(dataset='cifar10', model_name='cifar_cnn',
                  train_epochs=50, data_dir='./data',
                  output_dir='./wsb_results', device='cuda', logger=None,
                  seed_list=None, n_seeds=5, attack_epsilon=0.00784,
                  n_eval=1000, n_perturbations=64, wsb_epsilon=0.10,
                  removal_percentile=80, aa_version='apgd'):
    seeds = list(seed_list) if seed_list else list(range(n_seeds))
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    score_ds, _, _ = load_dataset(dataset, data_dir, train=True,
                                  augment=False)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    eval_idx = np.arange(min(n_eval, len(test_ds)))
    n_total = len(score_ds)
    n_rm = int(n_total * (100 - removal_percentile) / 100)
    all_indices = set(range(n_total))
    results = {'config': {'dataset': dataset, 'seeds': seeds,
                          'attack': f'AutoAttack-{aa_version}',
                          'attack_epsilon': attack_epsilon,
                          'n_eval': int(len(eval_idx)),
                          'n_removed': n_rm},
               'clean_acc': {a: [] for a in
                             ('baseline', 'remove_high_lfr',
                              'remove_random')},
               'aa_robust_acc': {a: [] for a in
                                 ('baseline', 'remove_high_lfr',
                                  'remove_random')}}

    def _train(keep_indices, seed):
        torch.manual_seed(seed)
        m = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
        loader = DataLoader(Subset(train_ds, sorted(keep_indices)),
                            batch_size=128, shuffle=True,
                            num_workers=2, pin_memory=True)
        train_standard(m, loader, train_epochs, device, logger=None)
        return m

    for seed in seeds:
        t0 = time.time()
        if logger:
            logger.info(f"  Seed {seed + 1} ({len(seeds)} seed(s) this run)")
        rng = np.random.default_rng(seed)
        base = _train(range(n_total), seed)
        score_indices = rng.choice(n_total, n_total, replace=False)
        scores = _score_training_set(base, score_ds, score_indices,
                                     wsb_epsilon, n_perturbations,
                                     n_classes, device, None)
        valid = ~np.isnan(scores['lfr'])
        valid_idx = score_indices[valid]
        order = np.argsort(scores['lfr'][valid])
        rm_lfr = valid_idx[order[-n_rm:]]
        rm_rand = rng.choice(valid_idx, n_rm, replace=False)
        m_lfr = _train(all_indices - set(int(i) for i in rm_lfr), seed)
        m_rand = _train(all_indices - set(int(i) for i in rm_rand), seed)
        for tag, m in (('baseline', base), ('remove_high_lfr', m_lfr),
                       ('remove_random', m_rand)):
            ca = _clean_acc(m, test_ds, eval_idx, device)
            ra = _aa_robust_acc(m, test_ds, eval_idx, device,
                                attack_epsilon, logger=logger,
                                aa_version=aa_version)
            results['clean_acc'][tag].append(round(ca, 4))
            results['aa_robust_acc'][tag].append(round(ra, 4))
            if logger:
                logger.info(f"    {tag}: clean={ca:.1%} AA-robust={ra:.1%}")
        if logger:
            logger.info(f"    seed wall clock {time.time()-t0:.0f}s")
    # aggregate + paired one-sided sign-flip (LFR vs random)
    agg = {}
    for tag in results['aa_robust_acc']:
        arr = np.array(results['aa_robust_acc'][tag])
        agg[tag] = {'aa_robust_mean': round(float(arr.mean()), 4),
                    'aa_robust_sd': round(float(arr.std(ddof=1)), 4)
                    if len(arr) > 1 else None,
                    'clean_mean': round(float(np.mean(
                        results['clean_acc'][tag])), 4)}
    results['aggregate'] = agg
    b = np.array(results['aa_robust_acc']['baseline'])
    l = np.array(results['aa_robust_acc']['remove_high_lfr'])
    r = np.array(results['aa_robust_acc']['remove_random'])
    cb = np.array(results['clean_acc']['baseline'])
    coll = ((cb - np.array(results['clean_acc']['remove_high_lfr'])) > 0.20) | \
           ((cb - np.array(results['clean_acc']['remove_random'])) > 0.20)
    results['collapsed_pairs_excluded'] = int(coll.sum())
    if (~coll).sum() >= 2:
        b, l, r = b[~coll], l[~coll], r[~coll]
    if len(b) >= 2:
        from itertools import product
        diff = (l - b) - (r - b)
        obs = diff.mean()
        stats = [float(np.mean(diff * np.array(s)))
                 for s in product([1, -1], repeat=len(diff))]
        results['lfr_vs_random_paired'] = {
            'observed_mean_diff': round(float(obs), 4),
            'p_value': round(float(np.mean([s >= obs - 1e-12
                                            for s in stats])), 4),
            'n_pairs': int(len(diff))}
        if logger:
            logger.info(f"  AA paired LFR-vs-random: diff="
                        f"{obs:+.4f}, p="
                        f"{results['lfr_vs_random_paired']['p_value']}")
    save_results(results, output_dir, f"aa_reeval_{dataset}")
    return results
