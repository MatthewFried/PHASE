"""
WSB Framework - Phase Classifiers Module
=========================================
Phase classifiers for all domains (RL, adversarial, games).
"""

import numpy as np
from typing import List, Optional, Tuple, Union
from abc import ABC, abstractmethod


# =============================================================================
# BASE CLASSIFIER
# =============================================================================

class PhaseClassifier(ABC):
    """Abstract base class for phase classifiers."""
    
    @abstractmethod
    def classify(self, x) -> int:
        """Classify input into a phase."""
        pass
    
    @property
    @abstractmethod
    def n_phases(self) -> int:
        """Number of phases."""
        pass
    
    def classify_batch(self, xs: List) -> np.ndarray:
        """Classify a batch of inputs."""
        return np.array([self.classify(x) for x in xs])
    
    def get_phase_counts(self, xs: List) -> np.ndarray:
        """Get counts per phase for a batch of inputs."""
        phases = self.classify_batch(xs)
        counts = np.zeros(self.n_phases)
        for p in phases:
            if 0 <= p < self.n_phases:
                counts[p] += 1
        return counts


# =============================================================================
# GENERAL CLASSIFIERS
# =============================================================================

class ThresholdClassifier(PhaseClassifier):
    """Binary classification by threshold."""
    
    def __init__(self, threshold: float):
        self.threshold = threshold
    
    @property
    def n_phases(self) -> int:
        return 2
    
    def classify(self, x: float) -> int:
        return 1 if x >= self.threshold else 0


class MultiThresholdClassifier(PhaseClassifier):
    """Multi-class classification by multiple thresholds."""
    
    def __init__(self, thresholds: List[float]):
        self.thresholds = sorted(thresholds)
    
    @property
    def n_phases(self) -> int:
        return len(self.thresholds) + 1
    
    def classify(self, x: float) -> int:
        for i, t in enumerate(self.thresholds):
            if x < t:
                return i
        return len(self.thresholds)


class QuantileClassifier(PhaseClassifier):
    """Classification by quantiles of reference distribution."""
    
    def __init__(self, n_quantiles: int, reference_values: np.ndarray):
        self.n_quantiles = n_quantiles
        percentiles = np.linspace(0, 100, n_quantiles + 1)[1:-1]
        self.thresholds = np.percentile(reference_values, percentiles)
    
    @property
    def n_phases(self) -> int:
        return self.n_quantiles
    
    def classify(self, x: float) -> int:
        for i, t in enumerate(self.thresholds):
            if x < t:
                return i
        return self.n_quantiles - 1


class KMeansClassifier(PhaseClassifier):
    """Classification by K-means clustering."""
    
    def __init__(self, n_clusters: int, reference_data: Optional[np.ndarray] = None):
        self.n_clusters = n_clusters
        self.centers = None
        
        if reference_data is not None:
            self.fit(reference_data)
    
    def fit(self, data: np.ndarray):
        from sklearn.cluster import KMeans
        km = KMeans(n_clusters=self.n_clusters, n_init=10, random_state=42)
        km.fit(data.reshape(-1, 1) if data.ndim == 1 else data)
        self.centers = km.cluster_centers_
    
    @property
    def n_phases(self) -> int:
        return self.n_clusters
    
    def classify(self, x: np.ndarray) -> int:
        if self.centers is None:
            return 0
        x = np.array(x).reshape(1, -1) if np.array(x).ndim == 1 else np.array(x).reshape(1, -1)
        distances = np.linalg.norm(self.centers - x, axis=1)
        return int(np.argmin(distances))


# =============================================================================
# RL CLASSIFIERS
# =============================================================================

class BinarySuccessClassifier(PhaseClassifier):
    """Classify by reward threshold (success/failure)."""
    
    def __init__(self, threshold: float):
        self.threshold = threshold
    
    @property
    def n_phases(self) -> int:
        return 2
    
    def classify(self, reward: float) -> int:
        return 1 if reward >= self.threshold else 0


class ReturnQuantileClassifier(PhaseClassifier):
    """Classify by return quantiles."""
    
    def __init__(self, n_quantiles: int, historical_returns: np.ndarray):
        self.n_quantiles = n_quantiles
        percentiles = np.linspace(0, 100, n_quantiles + 1)[1:-1]
        self.thresholds = np.percentile(historical_returns, percentiles)
    
    @property
    def n_phases(self) -> int:
        return self.n_quantiles
    
    def classify(self, reward: float) -> int:
        for i, t in enumerate(self.thresholds):
            if reward < t:
                return i
        return self.n_quantiles - 1


class SurvivalTimeClassifier(PhaseClassifier):
    """Classify by episode length buckets."""
    
    def __init__(self, time_thresholds: List[int]):
        self.thresholds = sorted(time_thresholds)
    
    @property
    def n_phases(self) -> int:
        return len(self.thresholds) + 1
    
    def classify(self, episode_length: int) -> int:
        for i, t in enumerate(self.thresholds):
            if episode_length < t:
                return i
        return len(self.thresholds)


class TerminalStateClusterClassifier(PhaseClassifier):
    """Classify by clustering of terminal states."""
    
    def __init__(self, n_clusters: int = 4):
        self.n_clusters = n_clusters
        self.kmeans = None
    
    def fit(self, terminal_states: np.ndarray):
        from sklearn.cluster import KMeans
        self.kmeans = KMeans(n_clusters=self.n_clusters, n_init=10, random_state=42)
        self.kmeans.fit(terminal_states)
    
    @property
    def n_phases(self) -> int:
        return self.n_clusters
    
    def classify(self, terminal_state: np.ndarray) -> int:
        if self.kmeans is None:
            return 0
        return int(self.kmeans.predict(terminal_state.reshape(1, -1))[0])


# =============================================================================
# ADVERSARIAL/CLASSIFICATION CLASSIFIERS
# =============================================================================

class PredictedClassClassifier(PhaseClassifier):
    """Phase = predicted class."""
    
    def __init__(self, n_classes: int):
        self._n_classes = n_classes
    
    @property
    def n_phases(self) -> int:
        return self._n_classes
    
    def classify(self, logits: np.ndarray) -> int:
        return int(np.argmax(logits))


class ConfidenceBucketClassifier(PhaseClassifier):
    """Classify by confidence level buckets combined with predicted class."""
    
    def __init__(self, n_buckets: int, n_classes: int):
        self.n_buckets = n_buckets
        self.n_classes = n_classes
        self.bucket_thresholds = np.linspace(0, 1, n_buckets + 1)[1:-1]
    
    @property
    def n_phases(self) -> int:
        return self.n_buckets * self.n_classes
    
    def classify(self, logits: np.ndarray) -> int:
        probs = np.exp(logits - np.max(logits))
        probs = probs / probs.sum()
        
        pred_class = int(np.argmax(probs))
        confidence = float(np.max(probs))
        
        bucket = 0
        for i, t in enumerate(self.bucket_thresholds):
            if confidence >= t:
                bucket = i + 1
        
        return pred_class * self.n_buckets + bucket


class Top2PairClassifier(PhaseClassifier):
    """Phase = pair of top-2 predicted classes."""
    
    def __init__(self, n_classes: int):
        self._n_classes = n_classes
    
    @property
    def n_phases(self) -> int:
        return self._n_classes * (self._n_classes - 1)
    
    def classify(self, logits: np.ndarray) -> int:
        top2 = np.argsort(logits)[-2:][::-1]
        # Encode as (top1 * (n_classes-1) + position_of_top2)
        top1, top2_class = top2[0], top2[1]
        # Adjust index since top2 can't equal top1
        top2_adj = top2_class if top2_class < top1 else top2_class - 1
        return int(top1 * (self._n_classes - 1) + top2_adj)


class BinaryCorrectClassifier(PhaseClassifier):
    """Phase = correct (1) or incorrect (0) prediction."""
    
    def __init__(self, true_label: int):
        self.true_label = true_label
    
    @property
    def n_phases(self) -> int:
        return 2
    
    def classify(self, logits: np.ndarray) -> int:
        pred = int(np.argmax(logits))
        return 1 if pred == self.true_label else 0


class EntropyBucketClassifier(PhaseClassifier):
    """Classify by prediction entropy buckets."""
    
    def __init__(self, n_buckets: int, max_entropy: Optional[float] = None):
        self.n_buckets = n_buckets
        self.max_entropy = max_entropy
    
    @property
    def n_phases(self) -> int:
        return self.n_buckets
    
    def classify(self, logits: np.ndarray) -> int:
        probs = np.exp(logits - np.max(logits))
        probs = probs / probs.sum()
        
        entropy = -np.sum(probs * np.log(probs + 1e-10))
        
        max_ent = self.max_entropy or np.log(len(probs))
        normalized_entropy = entropy / max_ent
        
        bucket = int(normalized_entropy * self.n_buckets)
        return min(bucket, self.n_buckets - 1)


class MarginBucketClassifier(PhaseClassifier):
    """Classify by margin between top-2 predictions."""
    
    def __init__(self, n_buckets: int):
        self.n_buckets = n_buckets
    
    @property
    def n_phases(self) -> int:
        return self.n_buckets
    
    def classify(self, logits: np.ndarray) -> int:
        probs = np.exp(logits - np.max(logits))
        probs = probs / probs.sum()
        
        sorted_probs = np.sort(probs)[::-1]
        margin = sorted_probs[0] - sorted_probs[1]  # In [0, 1]
        
        bucket = int(margin * self.n_buckets)
        return min(bucket, self.n_buckets - 1)


# =============================================================================
# GAME THEORY CLASSIFIERS
# =============================================================================

class NearestNashClassifier(PhaseClassifier):
    """Classify by nearest Nash equilibrium."""
    
    def __init__(self, nash_equilibria: List[Tuple[np.ndarray, np.ndarray]]):
        self.equilibria = nash_equilibria
        self._n_phases = max(len(nash_equilibria), 2)
    
    @property
    def n_phases(self) -> int:
        return self._n_phases
    
    def classify(self, strategy_vector: np.ndarray) -> int:
        if len(self.equilibria) == 0:
            return 0
        
        min_dist = float('inf')
        nearest = 0
        
        for i, (eq1, eq2) in enumerate(self.equilibria):
            eq_vec = np.concatenate([eq1, eq2])
            dist = np.linalg.norm(strategy_vector - eq_vec)
            if dist < min_dist:
                min_dist = dist
                nearest = i
        
        return nearest


class ActionProfileClassifier(PhaseClassifier):
    """Classify by most likely action profile."""
    
    def __init__(self, n_actions_per_player: Tuple[int, int]):
        self.n_actions = n_actions_per_player
    
    @property
    def n_phases(self) -> int:
        return self.n_actions[0] * self.n_actions[1]
    
    def classify(self, strategy_vector: np.ndarray) -> int:
        n1 = self.n_actions[0]
        s1 = strategy_vector[:n1]
        s2 = strategy_vector[n1:]
        
        a1 = int(np.argmax(s1))
        a2 = int(np.argmax(s2))
        
        return a1 * self.n_actions[1] + a2


class WelfareLevelClassifier(PhaseClassifier):
    """Classify by total welfare (sum of payoffs) bucket."""
    
    def __init__(self, n_buckets: int, welfare_range: Tuple[float, float]):
        self.n_buckets = n_buckets
        self.welfare_range = welfare_range
    
    @property
    def n_phases(self) -> int:
        return self.n_buckets
    
    def classify(self, total_welfare: float) -> int:
        low, high = self.welfare_range
        normalized = (total_welfare - low) / (high - low + 1e-10)
        normalized = np.clip(normalized, 0, 1)
        
        bucket = int(normalized * self.n_buckets)
        return min(bucket, self.n_buckets - 1)


class EquilibriumTypeClassifier(PhaseClassifier):
    """Classify by equilibrium type: pure/mixed × symmetric/asymmetric."""
    
    def __init__(self, purity_threshold: float = 0.9):
        self.purity_threshold = purity_threshold
    
    @property
    def n_phases(self) -> int:
        return 4  # (pure, symmetric), (pure, asymmetric), (mixed, symmetric), (mixed, asymmetric)
    
    def classify(self, strategy_vector: np.ndarray) -> int:
        n = len(strategy_vector) // 2
        s1, s2 = strategy_vector[:n], strategy_vector[n:]
        
        # Check purity
        is_pure = np.max(s1) > self.purity_threshold and np.max(s2) > self.purity_threshold
        
        # Check symmetry
        is_symmetric = np.allclose(s1, s2, atol=0.1)
        
        if is_pure and is_symmetric:
            return 0
        elif is_pure and not is_symmetric:
            return 1
        elif not is_pure and is_symmetric:
            return 2
        else:
            return 3


class ConvergenceTypeClassifier(PhaseClassifier):
    """Classify by convergence behavior."""
    
    def __init__(self, purity_threshold: float = 0.9, cycle_threshold: float = 0.1):
        self.purity_threshold = purity_threshold
        self.cycle_threshold = cycle_threshold
    
    @property
    def n_phases(self) -> int:
        return 4  # converged_pure, converged_mixed, cycling, diverging
    
    def classify(self, trajectory_info: dict) -> int:
        """
        trajectory_info should contain:
        - 'final_strategy': final strategy vector
        - 'converged': bool
        - 'variance': variance of last N strategies
        """
        if not trajectory_info.get('converged', False):
            variance = trajectory_info.get('variance', 0)
            if variance > self.cycle_threshold:
                return 2  # cycling
            return 3  # diverging
        
        final = trajectory_info.get('final_strategy', np.array([0.5, 0.5, 0.5, 0.5]))
        n = len(final) // 2
        s1, s2 = final[:n], final[n:]
        
        is_pure = np.max(s1) > self.purity_threshold and np.max(s2) > self.purity_threshold
        return 0 if is_pure else 1


# =============================================================================
# CLASSIFIER FACTORY
# =============================================================================

def get_phase_classifier(classifier_type: str, **kwargs) -> PhaseClassifier:
    """Factory function for phase classifiers."""
    
    classifiers = {
        # General
        "threshold": ThresholdClassifier,
        "multi_threshold": MultiThresholdClassifier,
        "quantile": QuantileClassifier,
        "kmeans": KMeansClassifier,
        
        # RL
        "binary_success": BinarySuccessClassifier,
        "return_quantile": ReturnQuantileClassifier,
        "survival_time": SurvivalTimeClassifier,
        "terminal_cluster": TerminalStateClusterClassifier,
        
        # Adversarial
        "predicted_class": PredictedClassClassifier,
        "confidence_bucket": ConfidenceBucketClassifier,
        "top2_pair": Top2PairClassifier,
        "binary_correct": BinaryCorrectClassifier,
        "entropy_bucket": EntropyBucketClassifier,
        "margin_bucket": MarginBucketClassifier,
        
        # Games
        "nearest_nash": NearestNashClassifier,
        "action_profile": ActionProfileClassifier,
        "welfare_level": WelfareLevelClassifier,
        "equilibrium_type": EquilibriumTypeClassifier,
        "convergence_type": ConvergenceTypeClassifier,
    }
    
    if classifier_type not in classifiers:
        raise ValueError(f"Unknown classifier: {classifier_type}. Available: {list(classifiers.keys())}")
    
    return classifiers[classifier_type](**kwargs)
