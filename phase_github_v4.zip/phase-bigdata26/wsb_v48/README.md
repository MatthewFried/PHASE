# wsb_v48: PHASE / Basin-Entropy Experimental Framework

Corrected and audited framework for the PHASE (basin-entropy diagnostic) and
identification-theory experiments. This version supersedes v30/v31 and the
monolithic `WSB_RL_GT_AT.ipynb`; **no numerical result produced by v30 should
be cited** (see "Corrections" below, two v30 bugs invalidate all vision
numbers and the RL/games entropies).

## Run order (mandatory)

```
python -m wsb_v48 download                      # STAGE 0: fetch + VERIFY all data
python -m wsb_v48 calibration                   # exact-ground-truth systems
python -m wsb_v48 option_c --game stag_hunt     # games
python -m wsb_v48 option_a --env CartPole-v1    # RL
python -m wsb_v48 option_b --dataset cifar10    # adversarial (headline table)
python -m wsb_v48 causal_intervention           # headline causal claim
```

or run `wsb_v48_runner.ipynb` top to bottom. Stage 0 writes
`wsb_results/data_manifest.json` (counts, shapes, value ranges, label ranges
for train AND test of mnist/cifar10/cifar100/svhn); every data-consuming stage
asserts this manifest and refuses to run without it. Every stage writes JSON
results plus a timestamped log file to `--output_dir` while mirroring to the
console.

## Protocol decisions a reviewer should know

1. **Data domain.** All dataset tensors are in [0, 1] (ToTensor only).
   Normalization is a layer inside the model (`NormalizedModel`), so attack
   epsilons (8/255), PHASE perturbation radii, and all `clamp(0, 1)` calls
   share one well-defined pixel domain.
2. **Attack crafting mode.** PGD-AT and TRADES craft adversarial examples in
   `eval()` mode (frozen BatchNorm statistics, no dropout noise in attack
   gradients) and update parameters in `train()` mode; this matches the
   official TRADES reference implementation. The TRADES objective flows
   gradients through both KL arguments (no detach), as in the reference.
3. **Local vs pooled entropy.** H_mean / H_max are statistics of PER-PROBE-
   POINT local entropies (one perturbation cloud per probe point). Pooled
   counts are recorded for diagnostics but their entropy is basin-FRACTION
   entropy, a different quantity, and is explicitly labeled as such
   (`pooled_entropy_DO_NOT_REPORT_AS_H_MEAN`). Vision code is per-sample;
   RL and games are per-probe-point.
4. **Entropy estimation.** Plug-in (MLE) entropy with zero-count phases
   masked (array length K never inflates H), with a Miller–Madow
   bias-corrected variant reported alongside (`method="miller_madow"`,
   correction (m−1)/(2N)). Both AUCs are logged; rankings should agree.
5. **Plateau guard.** Per sample we record the label-flip rate and the
   independence plateau 1 − Σp̂ᵢ². Radius-dependence of flip statistics is
   interpreted only where LFR / plateau < 0.9.
6. **Causal intervention.** The full training set is scored by default
   (`score_fraction=1.0`); scoring uses the canonical (non-augmented) images.
   Arms: remove-high-m and remove-low-m for each of five metrics, plus a
   size-matched random arm, all remove exactly the same number of samples,
   drawn from the same correctly-classified pool. Every model (baseline and
   all arms) is evaluated on the SAME fixed per-seed test index set. Outputs:
   absolute ASR and clean accuracy per arm, reductions, and a permutation
   test of high-H vs random reductions.
7. **Fixed evaluation subsets.** The Option B analysis set is fixed across
   seeds so cross-seed variance reflects training randomness only.
8. **Calibration criteria.** The refined fractality test compares S_bb
   against a flat-boundary reference MEASURED with the same square-box
   sampler on a certified straight boundary (self-calibrating; no constants
   imported from a different box geometry). The log-2 criterion is retained
   as the literature's criterion. On the triple well (provably smooth
   boundary) both criteria fire "fractal", a demonstrated false positive,
   which is the point; the S_bb ≤ log N_A ceiling holds throughout.
9. **Reproducibility.** All bootstrap/permutation resampling uses seeded
   `np.random.default_rng`; per-seed experiment loops seed numpy and torch.


## v31 -> v32: changes driven by external review (all 28 mandatory points)

**Estimand discipline.** Every experiment now computes one explicitly defined
estimand, and unsupported configuration choices RAISE instead of silently
substituting something else (unknown phase classifiers, no-op game sweeps,
unimplemented toy systems, continuous-action RL, zero removal counts).

**RL (Option A).** GAE termination mask moved to the correct timestep
(`dones[t]`); time-limit truncation bootstraps `gamma*V(s')` into the reward
(SB3-style) instead of being treated as absorbing; DQN stores
`done=terminated` only and its epsilon schedule now interpolates start->end;
MLPs honor `n_hidden_layers`; state-setting capability is verified by a
runtime set/get round-trip (LunarLander removed from the allowlist - it was
never implemented); the seed-based fallback is labeled
`initial_condition_global` with `is_local=False` and excluded from headline
claims; headline rollouts are deterministic-policy with a per-checkpoint
NOISE CONTROL (repeated rollouts from one unperturbed state - the
non-geometric entropy floor); return-quantile phase thresholds are frozen at
first fit; the fragility target is PROSPECTIVE (collapse within a forward
horizon) replacing the partially circular bottom-30%-of-current-reward
target; lead-time thresholds are fit on the pre-first-event prefix only and
use actual checkpoint step numbers.

**Games (Option C).** Phases are now DYNAMICAL REGIMES, not nearest Nash
points: converged trajectories are labeled by attractor, nonconverged ones
(cycles, orbits, boundary crawls) get a dedicated phase. Convergence
requires a verification phase - after the per-step change falls below tol,
the trajectory must stay inside a small ball for 200 further steps, which
distinguishes attracting fixed points from slow drift (on Matching Pennies,
Euler replicator crawls along the simplex boundary below tol and a naive
test declares it converged). Consequences validated numerically: Prisoner's
Dilemma gives H=0 with 0% nonconvergent (a demonstrated null - the cycle
phase was available), Matching Pennies gives 100% nonconvergent and H=0
(valid null: one regime, high raw outcome variance), the Stag Hunt
separatrix cloud still splits ~log 2 between the two pure attractors with
the unstable mixed equilibrium receiving zero counts. Parameter sweeps use
COMMON RANDOM NUMBERS (one base-point/offset set for the whole sweep;
bit-identical under different global seeds) and WSB detection requires a
prominence of at least 0.05 nats. The strategy-coordinate-vs-payoff-
parameter "wsb_error" was removed as ill-defined; the analytical check is
now bistable-REGION agreement. The classifier ablation actually switches
classifiers, and logit-response dynamics reset their temperature schedule
before every rollout.

**Causal intervention.** PRIMARY outcome is robust accuracy on a fixed
per-seed test set (arm-invariant denominator); conditioning each arm's ASR
on its own clean-correct set - the previous protocol - lets an arm that
damages clean accuracy on vulnerable samples look better as they exit the
denominator. Secondary: ASR on the baseline model's clean-correct
population, fixed across arms. Attack parameters come from the dataset's
config (no CIFAR hardcode on MNIST) with attack randomness seeded
identically across arms. Significance uses a PAIRED sign-flip permutation
test (arms share their seed's baseline) with exact enumeration for n<=20 and
the minimum attainable p (2^-n) reported: with 3 seeds no p below 0.125 is
possible; use >= 10 seeds for confirmatory claims.

**Adversarial (Option B).** `eval_attack_restarts` is implemented (success
if ANY restart flips; first successful adversarial example kept);
`--wsb_epsilon` and `--attack_epsilon` are separate CLI flags (the old
`--epsilon` was wired to a field the analysis never read); entropy
normalization uses the configured classifier's actual phase cardinality;
`confidence_bucket` is wired; both `h_basin_mean_all` and
`h_basin_mean_clean_correct` are reported and distribution inversion runs on
the clean-correct population; the plateau guard reports the per-sample
identified fraction; the local-Lipschitz baseline is one canonical function
(configured probe count honored, probes clamped to [0,1], denominator is the
post-projection displacement); `margdrop` holds the reference class fixed.

**Config precedence.** `resolve_option_a_config` / `resolve_option_b_config`
are the only places env/dataset defaults are applied (base defaults ->
env/dataset defaults -> explicit user overrides); analyzers never mutate the
config they receive, and the CLI passes only user-supplied values.

**Compression.** Training reuses the canonical `pgd_training_step` /
`trades_loss` (its private copy crafted attacks in train mode,
reintroducing the BN-corruption bug). The primary group comparison is
WITHIN-SAMPLE degradation (baseline-correct -> compressed-incorrect flip
rate, margin/confidence change) with a difficulty-matched gap; raw group
accuracies are retained but labeled as confounded. Methods are named
honestly: weight_quantization_simulated, magnitude_masking, channel_masking
(filter AND bias zeroed), low_rank_approx_dense_reconstruction.

**Statistics & infrastructure.** Transfer/epsilon-stability rankings are
PRIMARY on worst-case target AUC (ranking by AUC-change rewards
useless-but-stable metrics); `hbasin_wins` is flagged exploratory;
chi-square tests carry a `chi2_valid` expected-count flag; zero-count
distributions return NaN, not uniform; single-attractor systems are not
promoted to two phases; inversion reports absolute change and smoothed log
odds with the rarest phase restricted to observed phases; seed-level SDs use
ddof=1; the paired test is available in `StatisticalTests`; bare `except:`
is gone; the data manifest records its `data_dir` and every data-consuming
CLI command verifies the manifest against the directory it will actually
read. The toy double-well ground truth is the EXACT uniform-perturbation
formula, and a three-phase 1D triple-well toy demonstrates H beyond LFR
(validated: matched LFR 0.364 vs 0.345 with H 0.908 vs 0.644).

## Corrections from v30 (why v30 numbers are invalid)

- v30 normalized the data AND clamped attacks to [0, 1] in normalized space
  (values ≈ [−2, 2.7]), destroying images and rescaling epsilon; every attack
  / adversarial-training number was invalid (e.g. PGD-AT clean acc 31%).
- v30 crafted adversarial examples with `model.train()`: BN running stats
  were updated by every inner attack step.
- v30 RL/games pooled all outcomes into one count vector, basin-fraction
  entropy misreported as H_mean.
- v30 causal intervention scored 3,000/50,000 samples (removing ~1.2% of the
  trainset while described as 20%), had no low-H control arm, and measured
  baseline vs post-intervention ASR on different random test subsets.
- Smaller: entropy clipped zeros instead of masking (K inflated H by ~K·ε);
  unseeded bootstrap/permutation; degenerate PR-AUC reported as 0.5 instead
  of prevalence; a strategy-space coordinate was compared to a payoff
  parameter as a "WSB location error"; Cohen's d computed between metrics in
  different units; `type(model)(...)` reconstruction in compression broke
  under the model wrapper; 5,000 gym env constructions per RL checkpoint.

## Validated invariants (numpy modules, run in this audit)

- `H([n]) = 0` exactly (no −0.0), `H([25,25]) = log 2`, Miller–Madow adds
  exactly (m−1)/(2N), zero-masking keeps `H([3,0,0,0]) = 0`.
- Double well: entropy peak at x = 0.0000, H_max = 99.5% of log 2, deep-basin
  entropy exactly 0.
- Triple well: S_bb ≤ log 3 at every (δ, ε); both fractality criteria produce
  false positives on the smooth boundary.
- Parallel lines: criteria activate at spacing/box-diameter = 0.75 (wall
  density, not dimension); S_bb at ratio 1.0 matches the measured flat
  reference (0.547 vs 0.544).
- Stag hunt: a perturbation cloud at the separatrix (0.75, 0.75) yields local
  entropy 0.693 = log 2; interior clouds yield 0; the Prisoner's Dilemma
  (single attractor) yields H ≡ 0.
- Seeded bootstrap/permutation return identical results on repeat calls.
- Regime classification: PD H=0 with 0% nonconvergent; MP 100% nonconvergent,
  H=0; Stag Hunt separatrix counts split between pure attractors only.
- GAE verified against a hand-computed reference (terminal step does not
  bootstrap; mask at t); DQN epsilon schedule endpoints verified; dynamic
  MLPs construct for 1/2/3 hidden layers; get_action log-prob matches its
  sampled action; CartPole passes the state-setting round-trip probe and
  continuous-action envs are rejected; config factories keep explicit
  overrides and reject unknown fields.
- CRN sweeps are bit-identical under different global RNG states.
- Three-phase toy finds matched-LFR/different-H pairs (H beyond LFR).
- End-to-end micro Option A run (CPU): local_state mode on all seeds and a
  noise-control floor of exactly 0 under deterministic rollouts.

Torch-dependent paths (training loops, batched attacks) were audited by
logic review and static analysis (syntax, cross-module import and
call-signature checks, dataclass field-order check); they require the lab
machine's GPU environment for numerical validation.
