"""
WSB Framework - Calibration Module (v31, new)
==============================================
Exact-ground-truth systems for the merged (PHASE + identification-theory)
paper. Every quantity an estimator might target is known in closed form here,
so an estimator applied to these systems measures the estimator.

Systems:
  1. double_well:     V(x) = (x^2-1)^2, separatrix at x = 0, 2 attractors.
     Validates: entropy peak location, H_max vs log 2 ceiling.
  2. triple_well:     x'' = -(1/4) x (x^2-1)(x^2-4) - delta x'.
     Attractors x = 0, +/-2; saddles +/-1. Basin boundary = union of the two
     saddles' stable manifolds: SMOOTH, uncertainty exponent = 1.
     Validates: Proposition (ceiling) S_bb <= log N_A, and demonstrates that
     the log2 criterion / boundary-entropy verdicts change with BOX SIZE on a
     provably smooth boundary (every 'fractal' verdict here is a certain
     false positive).
  3. parallel_lines:  labels floor(x/s) on the unit square; no junctions,
     uncertainty exponent = 1. Validates: both single-scale criteria activate
     once spacing < box diameter (wall-density, not dimension).

All outputs go to JSON via the caller; per-system dicts include ground truth,
measurements, and pass/fail against the exact statements.
"""

import numpy as np
from typing import Dict, Tuple
from .core import compute_basin_entropy

LOG2 = float(np.log(2.0))

# Margin added to the measured flat-boundary reference before declaring
# "above flat" in the refined test. It absorbs sampling noise of the
# reference itself (n_boxes >= 500 gives S_bb standard error well below
# this) so that a verdict of 'fractal' requires a clear exceedance.
REFINED_MARGIN = 0.02


def _flat_boundary_reference(eps_grid_units: int, n_grid: int, n_boxes: int,
                             rng: np.random.Generator) -> float:
    """
    Empirical flat-boundary S_bb reference, measured with the SAME square-box
    sampler used for the test systems: a single straight boundary (vertical
    line at x = 1/2) on a two-label unit square. Any refined-test threshold
    must be self-calibrating in this way; a constant imported from a different
    box geometry (e.g. the disk-box literature value) is not comparable and
    would silently shift verdicts. Ground truth for this reference system:
    smooth boundary, uncertainty exponent exactly 1, S_bb ceiling log 2.
    """
    e = eps_grid_units
    half = n_grid // 2
    labels = (np.arange(n_grid) >= half).astype(np.int64)
    label_grid = np.tile(labels, (n_grid, 1)).T  # boundary along axis 0
    _, sbb, _ = _sbb_from_labels(label_grid, e, n_boxes, rng)
    return sbb


# =============================================================================
# 1. DOUBLE WELL (1D, gradient flow) - PHASE positive control
# =============================================================================

def _dw_attractor(x0: np.ndarray) -> np.ndarray:
    """
    Overdamped gradient flow x' = -V'(x) on V = (x^2-1)^2 sends x0 to sign(x0)
    (basin boundary exactly at 0). Integrating is unnecessary for the label,
    but we integrate anyway so the pipeline matches the mechanical systems.
    """
    x = x0.astype(np.float64).copy()
    dt, T = 0.01, 10.0
    for _ in range(int(T / dt)):
        x = x - dt * 4.0 * x * (x * x - 1.0)
    return (x > 0).astype(np.int64)  # 0 -> left well, 1 -> right well


def run_double_well(epsilon: float = 0.1, n_grid: int = 201,
                    n_perturbations: int = 200, seed: int = 0,
                    logger=None) -> Dict:
    rng = np.random.default_rng(seed)
    xs = np.linspace(-2.0, 2.0, n_grid)
    per_point_h = np.zeros(n_grid)
    for i, x0 in enumerate(xs):
        cloud = x0 + rng.uniform(-epsilon, epsilon, n_perturbations)
        labels = _dw_attractor(cloud)
        counts = np.bincount(labels, minlength=2)
        per_point_h[i] = compute_basin_entropy(counts)
    i_peak = int(np.argmax(per_point_h))
    x_peak = float(xs[i_peak])
    h_max = float(per_point_h[i_peak])
    out = {
        "system": "double_well",
        "ground_truth": {"separatrix": 0.0, "n_attractors": 2,
                         "h_ceiling": LOG2},
        "epsilon": epsilon, "n_grid": n_grid, "n_perturbations": n_perturbations,
        "x_peak_empirical": x_peak,
        "location_error": abs(x_peak),
        "h_max_empirical": h_max,
        "h_max_over_log2": h_max / LOG2,
        "h_profile": per_point_h.tolist(),
        "grid": xs.tolist(),
        "checks": {
            "peak_within_epsilon_of_separatrix": abs(x_peak) <= epsilon,
            "h_max_below_ceiling": h_max <= LOG2 + 1e-9,
            "deep_basin_entropy_zero": float(np.max(
                per_point_h[np.abs(xs) > 1.5])) < 1e-6,
        },
    }
    if logger:
        logger.info(f"[double_well] peak at x={x_peak:+.4f} (truth 0), "
                    f"H_max={h_max:.4f} ({100*h_max/LOG2:.1f}% of log2); "
                    f"checks={out['checks']}")
    return out


# =============================================================================
# 2. TRIPLE WELL (2D phase space, smooth boundary, 3 attractors)
# =============================================================================

def _tw_integrate(x0: np.ndarray, v0: np.ndarray, delta: float,
                  dt: float = 0.08, T: float = 300.0) -> np.ndarray:
    """
    Vectorized RK4 for x'' = -(1/4) x (x^2-1)(x^2-4) - delta x'.
    Returns attractor labels: 0 -> x=-2, 1 -> x=0, 2 -> x=+2.
    Energy decreases strictly, so every trajectory ends at an equilibrium;
    label by nearest attractor at final time (speeds are ~0 by then).
    """
    def force(x):
        return -0.25 * x * (x * x - 1.0) * (x * x - 4.0)

    x, v = x0.astype(np.float64).copy(), v0.astype(np.float64).copy()
    n_steps = int(T / dt)
    for _ in range(n_steps):
        k1x = v
        k1v = force(x) - delta * v
        k2x = v + 0.5 * dt * k1v
        k2v = force(x + 0.5 * dt * k1x) - delta * (v + 0.5 * dt * k1v)
        k3x = v + 0.5 * dt * k2v
        k3v = force(x + 0.5 * dt * k2x) - delta * (v + 0.5 * dt * k2v)
        k4x = v + dt * k3v
        k4v = force(x + dt * k3x) - delta * (v + dt * k3v)
        x = x + (dt / 6.0) * (k1x + 2 * k2x + 2 * k3x + k4x)
        v = v + (dt / 6.0) * (k1v + 2 * k2v + 2 * k3v + k4v)
    attractors = np.array([-2.0, 0.0, 2.0])
    return np.argmin(np.abs(x[:, None] - attractors[None, :]), axis=1)


def _sbb_from_labels(label_grid: np.ndarray, eps_grid_units: int,
                     n_boxes: int, rng: np.random.Generator
                     ) -> Tuple[float, float, float]:
    """
    Boundary basin entropy S_bb with square boxes of half-width eps (grid
    units), sampled at uniform admissible centers. Returns
    (S_b over all boxes, S_bb over multi-label boxes, mean labels per box).
    """
    H, W = label_grid.shape
    e = eps_grid_units
    entropies, bb_entropies, n_labels = [], [], []
    tries, found = 0, 0
    while found < n_boxes and tries < 50 * n_boxes:
        tries += 1
        ci = rng.integers(e, H - e)
        cj = rng.integers(e, W - e)
        box = label_grid[ci - e:ci + e + 1, cj - e:cj + e + 1].ravel()
        counts = np.bincount(box, minlength=3)
        h = compute_basin_entropy(counts)
        entropies.append(h)
        n_labels.append(int((counts > 0).sum()))
        if (counts > 0).sum() > 1:
            bb_entropies.append(h)
            found += 1
    sb = float(np.mean(entropies)) if entropies else 0.0
    sbb = float(np.mean(bb_entropies)) if bb_entropies else 0.0
    return sb, sbb, float(np.mean(n_labels)) if n_labels else 0.0


def run_triple_well(deltas: Tuple[float, ...] = (0.10, 0.20),
                    eps_list: Tuple[int, ...] = (3, 5, 10, 20),
                    n_grid: int = 300, n_boxes: int = 1500, seed: int = 0,
                    logger=None) -> Dict:
    """
    Reproduces the triple-well verdict table: same smooth boundary, verdicts
    flip with box size. Ground truth: boundary is 2 smooth curves (stable
    manifolds of the saddles at +/-1); ANY 'fractal' verdict is a false
    positive with certainty. Also verifies the ceiling S_bb <= log 3.
    """
    rng = np.random.default_rng(seed)
    out = {"system": "triple_well",
           "ground_truth": {"n_attractors": 3, "boundary": "2 smooth curves",
                            "uncertainty_exponent": 1.0,
                            "sbb_ceiling": float(np.log(3))},
           "n_grid": n_grid, "n_boxes": n_boxes, "rows": []}
    xs = np.linspace(-3, 3, n_grid)
    vs = np.linspace(-3, 3, n_grid)
    X, V = np.meshgrid(xs, vs, indexing="ij")
    for delta in deltas:
        labels = _tw_integrate(X.ravel(), V.ravel(), delta).reshape(n_grid, n_grid)
        fracs = np.bincount(labels.ravel(), minlength=3) / labels.size
        for e in eps_list:
            sb, sbb, mean_labels = _sbb_from_labels(labels, e, n_boxes, rng)
            flat_ref = _flat_boundary_reference(e, n_grid, n_boxes, rng)
            row = {"delta": delta, "eps_grid": int(e),
                   "S_b": sb, "S_bb": sbb, "mean_labels_per_box": mean_labels,
                   "flat_boundary_reference": flat_ref,
                   "log2_criterion_fractal": bool(sbb > LOG2),
                   "refined_test_fractal": bool(sbb > flat_ref + REFINED_MARGIN),
                   "ceiling_respected": bool(sbb <= np.log(3) + 1e-9)}
            out["rows"].append(row)
            if logger:
                logger.info(f"[triple_well] delta={delta} eps={e:2d} | "
                            f"S_bb={sbb:.4f} labels/box={mean_labels:.2f} | "
                            f"log2->{'FRACTAL(FP!)' if row['log2_criterion_fractal'] else 'smooth'} "
                            f"refined->{'FRACTAL(FP!)' if row['refined_test_fractal'] else 'smooth'}")
        out[f"basin_fractions_delta_{delta}"] = fracs.tolist()
    out["any_false_positive"] = any(r["log2_criterion_fractal"]
                                    or r["refined_test_fractal"]
                                    for r in out["rows"])
    out["all_ceilings_respected"] = all(r["ceiling_respected"] for r in out["rows"])
    return out


# =============================================================================
# 3. PARALLEL LINES (smooth, no junctions, exponent exactly 1)
# =============================================================================

def run_parallel_lines(spacing_ratios: Tuple[float, ...] = (4.0, 2.0, 1.5, 1.0,
                                                            0.75, 0.5, 0.35),
                       eps_grid: int = 5, n_grid: int = 1200, n_boxes: int = 3000,
                       seed: int = 0, logger=None) -> Dict:
    """
    Family of parallel lines with spacing s on [0,1]^2, each strip its own
    label. Boundary: straight lines, uncertainty exponent 1, no junctions.
    Expectation (identification theory): both criteria activate once
    s < 2*eps (a box first contains two walls) - wall DENSITY, not dimension.
    """
    rng = np.random.default_rng(seed)
    eps_frac = eps_grid / n_grid  # box half-width as fraction of unit square
    out = {"system": "parallel_lines",
           "ground_truth": {"uncertainty_exponent": 1.0, "junctions": 0},
           "eps_grid": eps_grid, "n_grid": n_grid, "rows": []}
    flat_ref = _flat_boundary_reference(eps_grid, n_grid, n_boxes, rng)
    out["flat_boundary_reference"] = flat_ref
    ii = np.arange(n_grid)
    for ratio in spacing_ratios:
        s = ratio * 2 * eps_frac  # spacing s.t. s/(2*eps) = ratio
        # label(x) = floor(x/s); build the 2D label grid (constant in y)
        col_labels = np.floor((ii / n_grid) / s).astype(np.int64)
        n_lab = int(col_labels.max()) + 1
        label_grid = np.tile(col_labels, (n_grid, 1)).T  # labels vary along axis 0
        # S_bb with the same box sampler; ceiling here is log(n_lab)
        entropies, bb_entropies, labels_per_box = [], [], []
        e = eps_grid
        found, tries = 0, 0
        while found < n_boxes and tries < 50 * n_boxes:
            tries += 1
            ci = rng.integers(e, n_grid - e)
            cj = rng.integers(e, n_grid - e)
            box = label_grid[ci - e:ci + e + 1, cj - e:cj + e + 1].ravel()
            counts = np.bincount(box, minlength=n_lab)
            h = compute_basin_entropy(counts)
            entropies.append(h)
            labels_per_box.append(int((counts > 0).sum()))
            if (counts > 0).sum() > 1:
                bb_entropies.append(h)
                found += 1
        sbb = float(np.mean(bb_entropies)) if bb_entropies else 0.0
        row = {"spacing_over_box_diameter": ratio, "spacing": s,
               "S_bb": sbb,
               "mean_labels_per_box": float(np.mean(labels_per_box)),
               "flat_boundary_reference": flat_ref,
               "log2_criterion_fractal": bool(sbb > LOG2),
               "refined_test_fractal": bool(sbb > flat_ref + REFINED_MARGIN)}
        out["rows"].append(row)
        if logger:
            logger.info(f"[parallel_lines] s/(2e)={ratio:4.2f} | S_bb={sbb:.4f} "
                        f"labels/box={row['mean_labels_per_box']:.2f} | "
                        f"log2->{'FRACTAL(FP!)' if row['log2_criterion_fractal'] else 'smooth'} "
                        f"refined->{'FRACTAL(FP!)' if row['refined_test_fractal'] else 'smooth'}")
    # Identification claim: activation happens between ratio 1.0 and 0.75.
    act = [r for r in out["rows"] if r["refined_test_fractal"]]
    out["first_activation_ratio"] = (max(r["spacing_over_box_diameter"] for r in act)
                                     if act else None)
    return out


def run_all_calibration(output_dir: str, logger=None, quick: bool = False) -> Dict:
    """
    Full calibration battery. quick=True shrinks grids for a fast pass;
    default sizes reproduce the paper-scale measurements.
    """
    kw_tw = {"n_grid": 150, "n_boxes": 500} if quick else {}
    kw_pl = {"n_grid": 600, "n_boxes": 1000} if quick else {}
    kw_dw = {"n_grid": 101, "n_perturbations": 100} if quick else {}
    kw_hl = {"n_grid": 121, "n_perturbations": 1000} if quick else {}
    results = {
        "double_well": run_double_well(logger=logger, **kw_dw),
        "triple_well": run_triple_well(logger=logger, **kw_tw),
        "parallel_lines": run_parallel_lines(logger=logger, **kw_pl),
        "h_vs_lfr": run_h_vs_lfr_toy(logger=logger, **kw_hl),
    }
    results["summary"] = {
        "double_well_ok": all(results["double_well"]["checks"].values()),
        "triple_well_ceiling_ok": results["triple_well"]["all_ceilings_respected"],
        "triple_well_criteria_produce_false_positives":
            results["triple_well"]["any_false_positive"],
        "parallel_lines_first_activation_ratio":
            results["parallel_lines"]["first_activation_ratio"],
        "h_beyond_lfr_demonstrated":
            results["h_vs_lfr"]["demonstrates_h_beyond_lfr"],
    }
    if logger:
        logger.info(f"[calibration summary] {results['summary']}")
    return results


# =============================================================================
# H vs LFR: three-phase toy
# =============================================================================

def run_h_vs_lfr_toy(eps: float = 1.5, n_grid: int = 241,
                     n_perturbations: int = 4000, T: float = 40.0,
                     dt: float = 0.01, logger=None, rng=None) -> Dict:
    """
    Demonstrates what entropy adds beyond the label-flip rate. In a TWO-basin
    cloud, H is exactly the binary entropy of the flip probability q, i.e. a
    monotone reparametrization of LFR for q <= 1/2 - so H and LFR rank
    two-basin samples almost identically BY CONSTRUCTION and a binary toy
    cannot distinguish them. With THREE terminal phases, two clouds can have
    IDENTICAL LFR but different outcome composition: a cloud leaking 30% into
    one neighboring basin (H = H(0.7, 0.3)) versus a cloud leaking 15% into
    each of two basins (H = H(0.7, 0.15, 0.15) - strictly larger).

    System: 1D overdamped triple well x' = -U'(x),
    U'(x) = (1/4) x (x^2 - 1)(x^2 - 4): attractors {-2, 0, 2}, boundaries at
    +/-1. Clouds are uniform x0 +/- eps. We scan base points and report pairs
    with matched LFR (|dLFR| < 0.02) but different H (|dH| > 0.15).
    """
    rng = rng or np.random.default_rng(0)

    def _settle(x):
        n_steps = int(T / dt)
        for _ in range(n_steps):
            x = x - dt * 0.25 * x * (x ** 2 - 1.0) * (x ** 2 - 4.0)
        return x

    # eps must exceed the center-basin half-width (=1) so that some clouds
    # straddle BOTH boundaries: only then do three-phase compositions occur
    # and H can differ at matched LFR. Cloud points are clipped to [-2.5, 2.5]
    # where Euler at dt=0.01 is stable (dt * U''(2.5) ~ 0.26).
    attractors = np.array([-2.0, 0.0, 2.0])
    xs = np.linspace(-2.0, 2.0, n_grid)
    rows = []
    for x0 in xs:
        cloud = np.clip(x0 + rng.uniform(-eps, eps, n_perturbations), -2.5, 2.5)
        finals = _settle(cloud.copy())
        labels = np.argmin(np.abs(finals[:, None] - attractors[None, :]), axis=1)
        clean_label = int(np.argmin(np.abs(_settle(np.array([x0]))[0] - attractors)))
        counts = np.bincount(labels, minlength=3)
        h = compute_basin_entropy(counts)
        lfr = 1.0 - counts[clean_label] / counts.sum()
        rows.append({"x0": float(x0), "h": float(h), "lfr": float(lfr),
                     "counts": counts.tolist(), "clean_label": clean_label})

    # matched-LFR, different-H pairs
    pairs = []
    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            if (abs(rows[i]["lfr"] - rows[j]["lfr"]) < 0.02
                    and abs(rows[i]["h"] - rows[j]["h"]) > 0.15):
                pairs.append({
                    "x_a": rows[i]["x0"], "x_b": rows[j]["x0"],
                    "lfr_a": rows[i]["lfr"], "lfr_b": rows[j]["lfr"],
                    "h_a": rows[i]["h"], "h_b": rows[j]["h"],
                    "counts_a": rows[i]["counts"], "counts_b": rows[j]["counts"],
                })
    pairs.sort(key=lambda p: -abs(p["h_a"] - p["h_b"]))
    out = {"system": "triple_well_1d_overdamped", "eps": eps,
           "n_matched_lfr_different_h_pairs": len(pairs),
           "top_pairs": pairs[:5], "rows": rows,
           "demonstrates_h_beyond_lfr": bool(len(pairs) > 0)}
    if logger:
        logger.info(f"[h_vs_lfr] {len(pairs)} matched-LFR/different-H pairs")
        for p in pairs[:3]:
            logger.info(f"  x={p['x_a']:+.2f} vs x={p['x_b']:+.2f}: "
                        f"LFR {p['lfr_a']:.3f}~{p['lfr_b']:.3f} but "
                        f"H {p['h_a']:.3f} vs {p['h_b']:.3f} "
                        f"(counts {p['counts_a']} vs {p['counts_b']})")
    return out
