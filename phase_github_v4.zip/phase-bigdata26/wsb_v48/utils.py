"""
WSB Framework - Utilities Module
=================================
Logging, results tracking, and I/O utilities.
"""

import json
import logging
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict
import numpy as np


class NumpyEncoder(json.JSONEncoder):
    """JSON encoder for numpy types."""
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.integer, np.int64, np.int32)):
            return int(obj)
        if isinstance(obj, (np.floating, np.float64, np.float32)):
            return float(obj)
        if isinstance(obj, np.bool_):
            return bool(obj)
        return super().default(obj)


def setup_logger(name: str, log_dir: str = None, level: int = logging.INFO) -> logging.Logger:
    """Setup logger with file and console handlers."""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.handlers = []
    
    formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s', datefmt='%H:%M:%S')
    
    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(formatter)
    logger.addHandler(console)
    
    if log_dir:
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        file_handler = logging.FileHandler(Path(log_dir) / f"{name}_{timestamp}.log")
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


class ResultsTracker:
    """Track and save experiment results."""
    
    def __init__(self, experiment_name: str, output_dir: str):
        self.experiment_name = experiment_name
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.metrics: Dict[str, List[Tuple[int, float]]] = defaultdict(list)
        self.metadata: Dict[str, Any] = {}
        self.start_time = time.time()
    
    def log(self, name: str, value: float, step: int):
        """Log a metric value."""
        self.metrics[name].append((step, float(value)))
    
    def set_metadata(self, key: str, value: Any):
        """Set metadata."""
        self.metadata[key] = value
    
    def get_metric_series(self, name: str) -> Tuple[List[int], List[float]]:
        """Get metric as (steps, values) tuple."""
        data = self.metrics.get(name, [])
        if not data:
            return [], []
        steps, values = zip(*data)
        return list(steps), list(values)
    
    def save(self, suffix: str = ""):
        """Save results to JSON."""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{self.experiment_name}{suffix}_{timestamp}.json"
        
        results = {
            "experiment_name": self.experiment_name,
            "timestamp": timestamp,
            "duration_seconds": time.time() - self.start_time,
            "metrics": {k: v for k, v in self.metrics.items()},
            "metadata": self.metadata,
        }
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(results, f, indent=2, cls=NumpyEncoder)
        
        return str(filepath)
    
    def load(self, filepath: str):
        """Load results from JSON."""
        with open(filepath) as f:
            data = json.load(f)
        self.experiment_name = data.get("experiment_name", "unknown")
        self.metrics = defaultdict(list, data.get("metrics", {}))
        self.metadata = data.get("metadata", {})


def save_results(results: Dict, output_dir: str, name: str) -> str:
    """Save results dict to JSON file."""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{name}_{timestamp}.json"
    filepath = Path(output_dir) / filename
    
    with open(filepath, 'w') as f:
        json.dump(results, f, indent=2, cls=NumpyEncoder)
    
    return str(filepath)


def load_results(filepath: str) -> Dict:
    """Load results from JSON file."""
    with open(filepath) as f:
        return json.load(f)


def merge_results(results_list: List[Dict], keys_to_merge: List[str] = None) -> Dict:
    """Merge multiple result dicts."""
    if not results_list:
        return {}
    
    merged = {"n_merged": len(results_list)}
    
    keys = keys_to_merge or set().union(*[r.keys() for r in results_list])
    
    for key in keys:
        values = [r.get(key) for r in results_list if key in r]
        if not values:
            continue
        
        if all(isinstance(v, (int, float)) for v in values):
            merged[f"{key}_mean"] = float(np.mean(values))
            merged[f"{key}_std"] = float(np.std(values))
            merged[f"{key}_min"] = float(np.min(values))
            merged[f"{key}_max"] = float(np.max(values))
        elif all(isinstance(v, list) for v in values):
            merged[key] = values
        else:
            merged[key] = values[0]
    
    return merged


def format_time(seconds: float) -> str:
    """Format seconds as human-readable string."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    else:
        return f"{seconds/3600:.1f}h"


def print_results_summary(results: Dict, indent: int = 0):
    """Print formatted results summary."""
    prefix = "  " * indent
    for key, value in results.items():
        if isinstance(value, dict):
            print(f"{prefix}{key}:")
            print_results_summary(value, indent + 1)
        elif isinstance(value, float):
            print(f"{prefix}{key}: {value:.4f}")
        elif isinstance(value, list) and len(value) > 5:
            print(f"{prefix}{key}: [{len(value)} items]")
        else:
            print(f"{prefix}{key}: {value}")


def compute_confidence_interval(data: np.ndarray, confidence: float = 0.95) -> Tuple[float, float, float]:
    """Compute mean and confidence interval."""
    from scipy import stats
    n = len(data)
    mean = np.mean(data)
    se = stats.sem(data)
    h = se * stats.t.ppf((1 + confidence) / 2, n - 1)
    return mean, mean - h, mean + h
