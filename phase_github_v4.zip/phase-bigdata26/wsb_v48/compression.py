"""
WSB Framework - Compression Experiment Module
===============================================
Test if H_basin predicts compression tolerance.
"""

import numpy as np
from typing import Dict, List
import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import CompressionConfig
from .core import compute_basin_entropy
from .adversarial import get_model, load_dataset


def quantize_model(model: nn.Module, bits: int, n_classes: int = 10, in_channels: int = 3) -> nn.Module:
    """Quantize model weights to specified bits."""
    import copy
    model_q = copy.deepcopy(model)  # deepcopy: works for any wrapper (incl. NormalizedModel)
    
    with torch.no_grad():
        for param in model_q.parameters():
            if param.dim() > 0:  # Skip biases with dim=0
                min_val, max_val = param.min(), param.max()
                scale = (max_val - min_val) / (2**bits - 1)
                if scale > 0:
                    param.data = torch.round((param - min_val) / scale) * scale + min_val
    
    return model_q


def prune_model(model: nn.Module, ratio: float, n_classes: int = 10, in_channels: int = 3) -> nn.Module:
    """Prune model weights by magnitude."""
    import copy
    model_p = copy.deepcopy(model)  # deepcopy: works for any wrapper (incl. NormalizedModel)
    
    with torch.no_grad():
        for param in model_p.parameters():
            if param.dim() > 1:  # Only prune weight matrices
                threshold = torch.quantile(param.abs().flatten(), ratio)
                mask = param.abs() >= threshold
                param.data *= mask.float()
    
    return model_p


def svd_compress_model(model: nn.Module, rank_ratio: float, n_classes: int = 10, in_channels: int = 3) -> nn.Module:
    """Compress model using SVD on linear layers (keep top rank_ratio of singular values)."""
    import copy
    model_svd = copy.deepcopy(model)  # deepcopy: works for any wrapper (incl. NormalizedModel)
    
    with torch.no_grad():
        for name, module in model_svd.named_modules():
            if isinstance(module, nn.Linear):
                W = module.weight.data
                U, S, Vh = torch.linalg.svd(W, full_matrices=False)
                k = max(1, int(len(S) * rank_ratio))
                W_approx = U[:, :k] @ torch.diag(S[:k]) @ Vh[:k, :]
                module.weight.data = W_approx
            elif isinstance(module, nn.Conv2d):
                # Reshape conv to 2D and apply SVD
                W = module.weight.data
                out_c, in_c, kh, kw = W.shape
                W_2d = W.view(out_c, -1)
                U, S, Vh = torch.linalg.svd(W_2d, full_matrices=False)
                k = max(1, int(len(S) * rank_ratio))
                W_approx = U[:, :k] @ torch.diag(S[:k]) @ Vh[:k, :]
                module.weight.data = W_approx.view(out_c, in_c, kh, kw)
    
    return model_svd


def channel_prune_model(model: nn.Module, ratio: float, n_classes: int = 10, in_channels: int = 3) -> nn.Module:
    """Prune entire channels based on L1 norm of filters."""
    import copy
    model_cp = copy.deepcopy(model)  # deepcopy: works for any wrapper (incl. NormalizedModel)
    
    with torch.no_grad():
        for name, module in model_cp.named_modules():
            if isinstance(module, nn.Conv2d) and module.out_channels > 1:
                W = module.weight.data
                # Compute L1 norm per output channel
                channel_norms = W.abs().sum(dim=(1, 2, 3))
                n_prune = int(module.out_channels * ratio)
                if n_prune > 0 and n_prune < module.out_channels:
                    _, indices = torch.topk(channel_norms, n_prune, largest=False)
                    W[indices] = 0
                    if module.bias is not None:
                        module.bias.data[indices] = 0  # bias kept "zeroed" channels alive
    
    return model_cp


class StudentCNN(nn.Module):
    """Smaller student network for knowledge distillation."""
    
    def __init__(self, n_classes: int = 10, in_channels: int = 3, width_factor: float = 0.5):
        super().__init__()
        base_width = 32
        w = int(base_width * width_factor)
        
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, w, 3, padding=1),
            nn.BatchNorm2d(w),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(w, w * 2, 3, padding=1),
            nn.BatchNorm2d(w * 2),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(w * 2, w * 4, 3, padding=1),
            nn.BatchNorm2d(w * 4),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(1),
        )
        self.classifier = nn.Linear(w * 4, n_classes)
    
    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        return self.classifier(x)


class CompressionAnalyzer:
    """Analyze compression tolerance vs H_basin."""
    
    def __init__(self, config: CompressionConfig, logger=None):
        self.config = config
        self.logger = logger
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Load dataset and model
        data_dir = config.data_dir if hasattr(config, 'data_dir') and config.data_dir else "./data"
        self.train_dataset, self.n_classes, self.in_channels = load_dataset(
            config.dataset, data_dir, train=True
        )
        self.test_dataset, _, _ = load_dataset(
            config.dataset, data_dir, train=False
        )
        self.model = get_model(config.model_name, self.n_classes, self.in_channels, dataset=config.dataset).to(self.device)
        
        if config.pretrained_path:
            self.model.load_state_dict(torch.load(config.pretrained_path))
            if logger:
                logger.info(f"Loaded pretrained model from {config.pretrained_path}")
        else:
            # Train the model first
            self._train_model()
        
        if logger:
            logger.info(f"Compression Analysis: {config.dataset}, {config.model_name}")
    
    def _train_model(self, epochs: int = None):
        """Train via the CANONICAL implementations in the adversarial module
        (pgd_training_step / trades_loss craft attacks in eval mode with
        frozen BN statistics). The previous in-module copy crafted attacks
        with the model in train() mode, reintroducing the exact BN-corruption
        bug the adversarial module fixes; one implementation, used everywhere.
        """
        from .adversarial import pgd_training_step, trades_loss
        epochs = epochs or self.config.train_epochs
        adv_mode = self.config.adversarial_training
        if self.logger:
            self.logger.info(f"Training model for {epochs} epochs "
                             f"(adversarial: {adv_mode})...")
        train_loader = torch.utils.data.DataLoader(
            self.train_dataset, batch_size=128, shuffle=True, num_workers=2)
        optimizer = torch.optim.SGD(self.model.parameters(), lr=0.1,
                                    momentum=0.9, weight_decay=5e-4)
        scheduler = torch.optim.lr_scheduler.MultiStepLR(
            optimizer, milestones=[int(epochs * 0.5), int(epochs * 0.75)],
            gamma=0.1)
        eps, alpha, attack_steps, beta = 8 / 255, 2 / 255, 7, 6.0

        for epoch in range(epochs):
            self.model.train()
            total_loss, correct, total = 0.0, 0, 0
            for x, y in train_loader:
                x, y = x.to(self.device), y.to(self.device)
                if adv_mode == "pgd":
                    loss_val = pgd_training_step(self.model, optimizer, x, y,
                                                 eps, alpha, attack_steps,
                                                 self.device)
                    total_loss += loss_val
                elif adv_mode == "trades":
                    optimizer.zero_grad()
                    loss = trades_loss(self.model, x, y, eps, alpha,
                                       attack_steps, beta, self.device)
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item()
                else:
                    optimizer.zero_grad()
                    loss = F.cross_entropy(self.model(x), y)
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item()
                with torch.no_grad():
                    self.model.eval()
                    correct += (self.model(x).argmax(1) == y).sum().item()
                    self.model.train()
                    total += y.size(0)
            scheduler.step()
            if (epoch + 1) % 10 == 0 and self.logger:
                self.logger.info(f"  Epoch {epoch+1}/{epochs} | "
                                 f"Loss: {total_loss/len(train_loader):.4f} | "
                                 f"Acc: {correct/total:.2%}")
        self.model.eval()
        if self.logger:
            self.logger.info("Model training complete.")

    def compute_per_sample_h_basin(self) -> List[Dict]:
        """Compute H_basin for test samples."""
        if self.logger:
            self.logger.info("Computing H_basin for test samples...")
        
        indices = np.random.choice(
            len(self.test_dataset), 
            min(self.config.n_test_samples, len(self.test_dataset)), 
            replace=False
        )
        
        results = []
        self.model.eval()
        
        for i, idx in enumerate(indices):
            x, y = self.test_dataset[idx]
            x = x.unsqueeze(0).to(self.device)
            
            # Get prediction and baseline metrics
            with torch.no_grad():
                logits = self.model(x).cpu().numpy()[0]
                pred = np.argmax(logits)
                probs = np.exp(logits - np.max(logits))  # softmax
                probs = probs / probs.sum()
                
                # Margin: gap between top two logits
                sorted_logits = np.sort(logits)[::-1]
                margin = sorted_logits[0] - sorted_logits[1]
                
                # Confidence: max probability
                confidence = probs.max()
                
                # Entropy of prediction distribution
                pred_entropy = -np.sum(probs * np.log(probs + 1e-10))
            
            # Compute H_basin
            from .classifiers import PredictedClassClassifier
            clf = PredictedClassClassifier(self.n_classes)
            counts = np.zeros(clf.n_phases)
            
            for _ in range(self.config.n_perturbations):
                pert = torch.empty_like(x).uniform_(-self.config.epsilon, self.config.epsilon)
                x_pert = torch.clamp(x + pert, 0, 1)
                with torch.no_grad():
                    logits_pert = self.model(x_pert).cpu().numpy()[0]
                phase = clf.classify(logits_pert)
                counts[phase] += 1
            
            h_basin = compute_basin_entropy(counts)
            
            results.append({
                "idx": int(idx),
                "true_label": int(y),
                "pred_label": int(pred),
                "correct": pred == y,
                "h_basin": h_basin,
                "margin": float(margin),
                "confidence": float(confidence),
                "pred_entropy": float(pred_entropy),
            })
            
            if (i + 1) % 100 == 0 and self.logger:
                self.logger.info(f"  Processed {i+1}/{len(indices)}")
        
        return results
    
    def _group_eval(self, model_c, low_h_samples, high_h_samples,
                    low_h_dicts, high_h_dicts) -> Dict:
        """Group accuracies (legacy) + PRIMARY within-sample degradation."""
        acc_lo = self.evaluate_compressed_model(model_c, low_h_samples)
        acc_hi = self.evaluate_compressed_model(model_c, high_h_samples)
        ws_lo = self.evaluate_within_sample(model_c, low_h_dicts)
        ws_hi = self.evaluate_within_sample(model_c, high_h_dicts)
        return {"low_h_acc": acc_lo["accuracy"], "high_h_acc": acc_hi["accuracy"],
                "acc_gap": acc_lo["accuracy"] - acc_hi["accuracy"],
                "low_h_flip_rate": ws_lo["flip_rate"],
                "high_h_flip_rate": ws_hi["flip_rate"],
                "flip_rate_gap": (ws_hi["flip_rate"] - ws_lo["flip_rate"])
                    if np.isfinite(ws_lo["flip_rate"]) and np.isfinite(ws_hi["flip_rate"])
                    else float("nan"),
                "low_h_margin_change": ws_lo["mean_margin_change"],
                "high_h_margin_change": ws_hi["mean_margin_change"]}

    def evaluate_compressed_model(
        self, 
        model: nn.Module, 
        sample_indices: List[int]
    ) -> Dict:
        """Group accuracy on specific samples (kept for aggregate reporting;
        NOT the primary group comparison - see evaluate_within_sample)."""
        model.eval()
        model = model.to(self.device)
        correct, total = 0, 0
        for idx in sample_indices:
            x, y = self.test_dataset[idx]
            x = x.unsqueeze(0).to(self.device)
            with torch.no_grad():
                pred = model(x).argmax(1).item()
            if pred == y:
                correct += 1
            total += 1
        return {"accuracy": correct / total if total > 0 else 0, "n_samples": total}

    def evaluate_within_sample(self, model_c: nn.Module,
                               samples: List[Dict]) -> Dict:
        """
        WITHIN-SAMPLE degradation (primary response variable). Comparing raw
        post-compression group accuracies confounds compression sensitivity
        with baseline difficulty: if low-H starts at 99% and high-H at 80%,
        equal 4-point losses still show a 19-point compressed-model gap.
        Restricted to samples the BASELINE model classifies correctly;
        reports correct->incorrect flip rate, mean margin change and mean
        confidence change under the compressed model.
        Each element of samples needs keys idx/correct/margin/confidence
        (from compute_per_sample_h_basin).
        """
        model_c.eval().to(self.device)
        base_ok = [s for s in samples if s["correct"]]
        if not base_ok:
            return {"n": 0, "flip_rate": float("nan"),
                    "mean_margin_change": float("nan"),
                    "mean_conf_change": float("nan")}
        flips, dmargin, dconf = 0, [], []
        for s in base_ok:
            x, y = self.test_dataset[s["idx"]]
            x = x.unsqueeze(0).to(self.device)
            with torch.no_grad():
                logits = model_c(x).cpu().numpy()[0]
            pred = int(np.argmax(logits))
            probs = np.exp(logits - logits.max()); probs /= probs.sum()
            sl = np.sort(logits)[::-1]
            flips += int(pred != y)
            dmargin.append(float(sl[0] - sl[1]) - s["margin"])
            dconf.append(float(probs.max()) - s["confidence"])
        return {"n": len(base_ok), "flip_rate": flips / len(base_ok),
                "mean_margin_change": float(np.mean(dmargin)),
                "mean_conf_change": float(np.mean(dconf))}

    @staticmethod
    def matched_flip_gap(low_samples: List[Dict], high_samples: List[Dict],
                         low_eval: Dict, high_eval: Dict,
                         flips_by_idx_low: Dict[int, int],
                         flips_by_idx_high: Dict[int, int],
                         n_bins: int = 5) -> Dict:
        """
        Difficulty-matched flip-rate gap: bins baseline-correct samples by
        CLEAN margin quantiles (pooled across groups) and averages the
        within-bin (high - low) flip-rate difference weighted by bin
        occupancy, so the comparison is not driven by the two groups sitting
        at different clean difficulties.
        """
        lo = [s for s in low_samples if s["correct"]]
        hi = [s for s in high_samples if s["correct"]]
        if not lo or not hi:
            return {"matched_gap": float("nan"), "n_bins_used": 0}
        all_m = np.array([s["margin"] for s in lo + hi])
        edges = np.quantile(all_m, np.linspace(0, 1, n_bins + 1))
        edges[0], edges[-1] = -np.inf, np.inf
        gaps, weights = [], []
        for b in range(n_bins):
            lo_b = [s for s in lo if edges[b] <= s["margin"] < edges[b + 1]]
            hi_b = [s for s in hi if edges[b] <= s["margin"] < edges[b + 1]]
            if len(lo_b) < 3 or len(hi_b) < 3:
                continue
            fr_lo = np.mean([flips_by_idx_low[s["idx"]] for s in lo_b])
            fr_hi = np.mean([flips_by_idx_high[s["idx"]] for s in hi_b])
            gaps.append(fr_hi - fr_lo)
            weights.append(len(lo_b) + len(hi_b))
        if not gaps:
            return {"matched_gap": float("nan"), "n_bins_used": 0}
        w = np.array(weights, dtype=float); w /= w.sum()
        return {"matched_gap": float(np.dot(gaps, w)),
                "n_bins_used": int(len(gaps))}

    def _run_knowledge_distillation(
        self,
        low_h_samples: List[int],
        high_h_samples: List[int],
        sample_results: List[Dict]
    ) -> Dict:
        """Train student networks with KD and evaluate on H_basin splits."""
        
        # Create student network (half width)
        student_hard = StudentCNN(self.n_classes, self.in_channels, width_factor=0.5).to(self.device)
        student_kd = StudentCNN(self.n_classes, self.in_channels, width_factor=0.5).to(self.device)
        
        train_loader = torch.utils.data.DataLoader(
            self.train_dataset, batch_size=128, shuffle=True, num_workers=2
        )
        
        criterion = nn.CrossEntropyLoss()
        kd_temp = 4.0  # Temperature for soft labels
        kd_alpha = 0.7  # Weight for KD loss
        
        # Train student with hard labels only
        if self.logger:
            self.logger.info("  Training student (hard labels)...")
        optimizer = torch.optim.SGD(student_hard.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
        scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[15, 25], gamma=0.1)
        
        student_hard.train()
        for epoch in range(30):
            for x, y in train_loader:
                x, y = x.to(self.device), y.to(self.device)
                optimizer.zero_grad()
                loss = criterion(student_hard(x), y)
                loss.backward()
                optimizer.step()
            scheduler.step()
        
        # Train student with KD (soft labels from teacher)
        if self.logger:
            self.logger.info("  Training student (KD from teacher)...")
        optimizer = torch.optim.SGD(student_kd.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
        scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[15, 25], gamma=0.1)
        
        self.model.eval()
        student_kd.train()
        for epoch in range(30):
            for x, y in train_loader:
                x, y = x.to(self.device), y.to(self.device)
                
                with torch.no_grad():
                    teacher_logits = self.model(x)
                
                student_logits = student_kd(x)
                
                # Hard label loss
                loss_hard = criterion(student_logits, y)
                
                # Soft label loss (KD)
                loss_soft = F.kl_div(
                    F.log_softmax(student_logits / kd_temp, dim=1),
                    F.softmax(teacher_logits / kd_temp, dim=1),
                    reduction='batchmean'
                ) * (kd_temp ** 2)
                
                loss = (1 - kd_alpha) * loss_hard + kd_alpha * loss_soft
                
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            scheduler.step()
        
        # Evaluate both students
        student_hard.eval()
        student_kd.eval()
        
        results = {}
        
        for name, student in [("hard_labels", student_hard), ("kd_soft_labels", student_kd)]:
            low_h_result = self.evaluate_compressed_model(student, low_h_samples)
            high_h_result = self.evaluate_compressed_model(student, high_h_samples)
            
            results[name] = {
                "low_h_acc": low_h_result["accuracy"],
                "high_h_acc": high_h_result["accuracy"],
                "acc_gap": low_h_result["accuracy"] - high_h_result["accuracy"],
            }
            
            if self.logger:
                self.logger.info(
                    f"  Student ({name}): Low-H acc={low_h_result['accuracy']:.3f}, "
                    f"High-H acc={high_h_result['accuracy']:.3f}, "
                    f"Gap={low_h_result['accuracy'] - high_h_result['accuracy']:.3f}"
                )
        
        return results
    
    def run_compression_experiment(self, tracker=None) -> Dict:
        """Main compression experiment."""
        if self.logger:
            self.logger.info("=" * 60 + "\nCOMPRESSION EXPERIMENT\n" + "=" * 60)
        
        # Step 1: Compute H_basin for all samples
        sample_results = self.compute_per_sample_h_basin()
        
        # Sort by H_basin
        sample_results.sort(key=lambda x: x["h_basin"])
        
        # Split into low-H and high-H groups
        n_low = self.config.n_low_h_samples
        n_high = self.config.n_high_h_samples
        
        low_h_dicts = sample_results[:n_low]
        high_h_dicts = sample_results[-n_high:]
        low_h_samples = [r["idx"] for r in low_h_dicts]
        high_h_samples = [r["idx"] for r in high_h_dicts]
        
        low_h_mean = np.mean([r["h_basin"] for r in sample_results[:n_low]])
        high_h_mean = np.mean([r["h_basin"] for r in sample_results[-n_high:]])
        
        if self.logger:
            self.logger.info(f"Low-H group: n={n_low}, mean H={low_h_mean:.4f}")
            self.logger.info(f"High-H group: n={n_high}, mean H={high_h_mean:.4f}")
        
        # Step 2: Test quantization
        # Honest naming (review point 27): this is SIMULATED weight-only
        # quantization (weights rounded, activations stay float); no deployed
        # model-size reduction is claimed.
        quantization_results = {"method": "weight_quantization_simulated",
                                "bits": [], "low_h_acc": [], "high_h_acc": [],
                                "acc_gap": [], "low_h_flip_rate": [],
                                "high_h_flip_rate": [], "flip_rate_gap": []}
        for bits in self.config.quantization_bits:
            model_q = quantize_model(self.model, bits, self.n_classes, self.in_channels)
            ev = self._group_eval(model_q, low_h_samples, high_h_samples,
                                  low_h_dicts, high_h_dicts)
            quantization_results["bits"].append(bits)
            for k in ("low_h_acc", "high_h_acc", "acc_gap", "low_h_flip_rate",
                      "high_h_flip_rate", "flip_rate_gap"):
                quantization_results[k].append(ev[k])
            if self.logger:
                self.logger.info(
                    f"  {bits}-bit: flip-rate low-H={ev['low_h_flip_rate']:.3f} "
                    f"high-H={ev['high_h_flip_rate']:.3f} "
                    f"(gap {ev['flip_rate_gap']:+.3f}; PRIMARY) | "
                    f"acc gap={ev['acc_gap']:.3f} (confounded by difficulty)")
        
        # Step 3: Test pruning
        # Honest naming: magnitude MASKING (weights zeroed in place; no
        # deployed size/FLOP reduction).
        pruning_results = {"method": "magnitude_masking", "ratio": [],
                           "low_h_acc": [], "high_h_acc": [], "acc_gap": [],
                           "low_h_flip_rate": [], "high_h_flip_rate": [],
                           "flip_rate_gap": []}
        for ratio in self.config.pruning_ratios:
            model_p = prune_model(self.model, ratio, self.n_classes, self.in_channels)
            ev = self._group_eval(model_p, low_h_samples, high_h_samples,
                                  low_h_dicts, high_h_dicts)
            pruning_results["ratio"].append(ratio)
            for k in ("low_h_acc", "high_h_acc", "acc_gap", "low_h_flip_rate",
                      "high_h_flip_rate", "flip_rate_gap"):
                pruning_results[k].append(ev[k])
            if self.logger:
                self.logger.info(
                    f"  Mask {ratio:.0%}: flip-rate low-H="
                    f"{ev['low_h_flip_rate']:.3f} high-H="
                    f"{ev['high_h_flip_rate']:.3f} "
                    f"(gap {ev['flip_rate_gap']:+.3f}; PRIMARY)")
        
        # Summary statistics
        results = {
            "n_samples": len(sample_results),
            "n_low_h": n_low,
            "n_high_h": n_high,
            "low_h_mean": float(low_h_mean),
            "high_h_mean": float(high_h_mean),
            "quantization_wsb": quantization_results,
            "pruning_wsb": pruning_results,
        }
        
        # Step 4: Baseline comparison - split by MARGIN instead of H_basin
        if self.logger:
            self.logger.info("\n--- Baseline: Margin Split ---")
        
        # Sort by margin (high margin = confident, low margin = uncertain)
        sample_results_margin = sorted(sample_results, key=lambda x: x["margin"])
        low_margin_samples = [r["idx"] for r in sample_results_margin[:n_low]]
        high_margin_samples = [r["idx"] for r in sample_results_margin[-n_high:]]
        
        low_margin_mean = np.mean([r["margin"] for r in sample_results_margin[:n_low]])
        high_margin_mean = np.mean([r["margin"] for r in sample_results_margin[-n_high:]])
        
        if self.logger:
            self.logger.info(f"Low-margin group: n={n_low}, mean margin={low_margin_mean:.4f}")
            self.logger.info(f"High-margin group: n={n_high}, mean margin={high_margin_mean:.4f}")
        
        # Pruning with margin split
        pruning_margin_results = {"ratio": [], "low_margin_acc": [], "high_margin_acc": [], "acc_gap": []}
        
        for ratio in self.config.pruning_ratios:
            model_p = prune_model(self.model, ratio, self.n_classes, self.in_channels)
            
            low_result = self.evaluate_compressed_model(model_p, low_margin_samples)
            high_result = self.evaluate_compressed_model(model_p, high_margin_samples)
            
            pruning_margin_results["ratio"].append(ratio)
            pruning_margin_results["low_margin_acc"].append(low_result["accuracy"])
            pruning_margin_results["high_margin_acc"].append(high_result["accuracy"])
            pruning_margin_results["acc_gap"].append(high_result["accuracy"] - low_result["accuracy"])  # Note: high margin should be MORE robust
            
            if self.logger:
                self.logger.info(
                    f"  Prune {ratio:.0%}: Low-margin acc={low_result['accuracy']:.3f}, "
                    f"High-margin acc={high_result['accuracy']:.3f}, "
                    f"Gap={high_result['accuracy'] - low_result['accuracy']:.3f}"
                )
        
        results["pruning_margin"] = pruning_margin_results
        results["low_margin_mean"] = float(low_margin_mean)
        results["high_margin_mean"] = float(high_margin_mean)
        
        # Step 5: Random baseline (to show WSB isn't just noise)
        if self.logger:
            self.logger.info("\n--- Baseline: Random Split ---")
        
        all_indices = [r["idx"] for r in sample_results]
        np.random.shuffle(all_indices)
        random_low_samples = all_indices[:n_low]
        random_high_samples = all_indices[-n_high:]
        
        pruning_random_results = {"ratio": [], "low_acc": [], "high_acc": [], "acc_gap": []}
        
        for ratio in self.config.pruning_ratios:
            model_p = prune_model(self.model, ratio, self.n_classes, self.in_channels)
            
            low_result = self.evaluate_compressed_model(model_p, random_low_samples)
            high_result = self.evaluate_compressed_model(model_p, random_high_samples)
            
            pruning_random_results["ratio"].append(ratio)
            pruning_random_results["low_acc"].append(low_result["accuracy"])
            pruning_random_results["high_acc"].append(high_result["accuracy"])
            pruning_random_results["acc_gap"].append(abs(low_result["accuracy"] - high_result["accuracy"]))
            
            if self.logger:
                self.logger.info(
                    f"  Prune {ratio:.0%}: Random-A acc={low_result['accuracy']:.3f}, "
                    f"Random-B acc={high_result['accuracy']:.3f}, "
                    f"Gap={abs(low_result['accuracy'] - high_result['accuracy']):.3f}"
                )
        
        results["pruning_random"] = pruning_random_results
        
        # Step 6: SVD compression (structured, representation-level)
        if self.logger:
            self.logger.info("\n--- SVD Compression (WSB Split) ---")
        
        # Honest naming: LOW-RANK APPROXIMATION with dense reconstruction
        # (truncated factors multiplied back into the original dense tensor;
        # storage/FLOPs unchanged - review point 27).
        svd_results = {"method": "low_rank_approx_dense_reconstruction",
                       "rank_ratio": [], "low_h_acc": [], "high_h_acc": [],
                       "acc_gap": [], "low_h_flip_rate": [],
                       "high_h_flip_rate": [], "flip_rate_gap": []}
        svd_ratios = [1.0, 0.7, 0.5, 0.3, 0.1]
        
        for rank_ratio in svd_ratios:
            model_svd = svd_compress_model(self.model, rank_ratio, self.n_classes, self.in_channels)
            model_svd = model_svd.to(self.device)
            ev = self._group_eval(model_svd, low_h_samples, high_h_samples,
                                  low_h_dicts, high_h_dicts)
            svd_results["rank_ratio"].append(rank_ratio)
            for k in ("low_h_acc", "high_h_acc", "acc_gap", "low_h_flip_rate",
                      "high_h_flip_rate", "flip_rate_gap"):
                svd_results[k].append(ev[k])
            if self.logger:
                self.logger.info(
                    f"  Low-rank {rank_ratio:.0%}: flip-rate low-H="
                    f"{ev['low_h_flip_rate']:.3f} high-H="
                    f"{ev['high_h_flip_rate']:.3f} "
                    f"(gap {ev['flip_rate_gap']:+.3f}; PRIMARY)")
        
        results["svd_wsb"] = svd_results
        
        # Step 6: Channel pruning (structured pruning)
        if self.logger:
            self.logger.info("\n--- Channel Pruning (WSB Split) ---")
        
        # Honest naming: CHANNEL MASKING (filters + biases zeroed; channels
        # are not physically removed and downstream BatchNorm can re-activate
        # a masked channel via its own affine terms).
        channel_results = {"method": "channel_masking", "ratio": [],
                           "low_h_acc": [], "high_h_acc": [], "acc_gap": [],
                           "low_h_flip_rate": [], "high_h_flip_rate": [],
                           "flip_rate_gap": []}
        channel_ratios = [0.0, 0.3, 0.5, 0.7]
        
        for ratio in channel_ratios:
            model_cp = channel_prune_model(self.model, ratio, self.n_classes, self.in_channels)
            model_cp = model_cp.to(self.device)
            ev = self._group_eval(model_cp, low_h_samples, high_h_samples,
                                  low_h_dicts, high_h_dicts)
            channel_results["ratio"].append(ratio)
            for k in ("low_h_acc", "high_h_acc", "acc_gap", "low_h_flip_rate",
                      "high_h_flip_rate", "flip_rate_gap"):
                channel_results[k].append(ev[k])
            if self.logger:
                self.logger.info(
                    f"  Channel-mask {ratio:.0%}: flip-rate low-H="
                    f"{ev['low_h_flip_rate']:.3f} high-H="
                    f"{ev['high_h_flip_rate']:.3f} "
                    f"(gap {ev['flip_rate_gap']:+.3f}; PRIMARY)")
        
        results["channel_pruning_wsb"] = channel_results
        
        # Step 8: Knowledge Distillation (semantic compression) - WSB split
        if self.logger:
            self.logger.info("\n--- Knowledge Distillation (WSB Split) ---")
        
        kd_results = self._run_knowledge_distillation(
            low_h_samples, high_h_samples, sample_results
        )
        results["knowledge_distillation_wsb"] = kd_results
        
        # Step 9: Knowledge Distillation with MARGIN split (baseline)
        if self.logger:
            self.logger.info("\n--- Knowledge Distillation (Margin Split) ---")
        
        kd_margin_results = self._run_knowledge_distillation(
            low_margin_samples, high_margin_samples, sample_results
        )
        results["knowledge_distillation_margin"] = kd_margin_results
        
        # Comprehensive comparison. PRIMARY: within-sample flip-rate gaps
        # per method. The old max-acc-gap comparison across splits is kept
        # but explicitly labeled confounded (baseline difficulty differs
        # between splits; the margin split's large acc gap is exactly that
        # confound, not compression sensitivity).
        def _mx(g):
            f = [x for x in g if x is not None and np.isfinite(x)]
            return max(f) if f else float("nan")

        flip_gaps_by_method = {
            "magnitude_masking": _mx(pruning_results["flip_rate_gap"]),
            "low_rank_approx": _mx(svd_results["flip_rate_gap"]),
            "channel_masking": _mx(channel_results["flip_rate_gap"]),
        }
        wsb_gaps = {
            "pruning": max(pruning_results["acc_gap"]) if pruning_results["acc_gap"] else 0,
            "svd": max(svd_results["acc_gap"]) if svd_results["acc_gap"] else 0,
            "channel": max(channel_results["acc_gap"]) if channel_results["acc_gap"] else 0,
            "kd": max(kd_results.get("hard_labels", {}).get("acc_gap", 0), 
                     kd_results.get("kd_soft_labels", {}).get("acc_gap", 0)),
        }
        margin_gaps = {
            "pruning": max(pruning_margin_results["acc_gap"]) if pruning_margin_results["acc_gap"] else 0,
            "kd": max(kd_margin_results.get("hard_labels", {}).get("acc_gap", 0),
                     kd_margin_results.get("kd_soft_labels", {}).get("acc_gap", 0)),
        }
        random_gaps = {
            "pruning": max(pruning_random_results["acc_gap"]) if pruning_random_results["acc_gap"] else 0,
        }
        results["comprehensive_comparison"] = {
            "primary_max_flip_rate_gap_by_method": flip_gaps_by_method,
            "CONFOUNDED_acc_gaps": {
                "wsb_gaps": wsb_gaps, "margin_gaps": margin_gaps,
                "random_gaps": random_gaps,
                "wsb_mean_gap": float(np.mean(list(wsb_gaps.values()))),
                "margin_mean_gap": float(np.mean(list(margin_gaps.values()))),
                "random_mean_gap": float(np.mean(list(random_gaps.values()))),
                "note": "group acc gaps confound compression sensitivity "
                        "with baseline difficulty; primary metric is the "
                        "within-sample flip-rate gap",
            },
        }
        
        if self.logger:
            self.logger.info(f"\n" + "=" * 60)
            self.logger.info("COMPREHENSIVE COMPARISON")
            self.logger.info("=" * 60)
            self.logger.info(
                "PRIMARY (within-sample max flip-rate gap, high-H minus low-H): "
                + ", ".join(f"{k}={v:+.1%}" for k, v in flip_gaps_by_method.items()))
            self.logger.info(
                f"Confounded group-acc gaps (reference only): "
                f"WSB mean={np.mean(list(wsb_gaps.values())):.1%}, "
                f"Margin mean={np.mean(list(margin_gaps.values())):.1%}, "
                f"Random mean={np.mean(list(random_gaps.values())):.1%}")
        
        # PRIMARY summary: within-sample flip-rate gaps (high-H minus low-H
        # among baseline-correct samples). The raw group accuracy gaps are
        # kept for reference but are CONFOUNDED by baseline difficulty and
        # must not be summarized as the compression-sensitivity finding: in
        # the MNIST smoke run the confounded margin-split acc gap reached
        # 38% while the within-sample flip gaps were 0.6-4.1% and changed
        # sign at heavy compression.
        def _finite(xs):
            return [x for x in xs if x is not None and np.isfinite(x)]

        flip_gaps = {
            "weight_quantization_simulated": _finite(quantization_results["flip_rate_gap"]),
            "magnitude_masking": _finite(pruning_results["flip_rate_gap"]),
        }
        results["primary_flip_rate_gaps"] = {
            name: {"max": float(max(g)) if g else float("nan"),
                   "mean": float(np.mean(g)) if g else float("nan"),
                   "per_level": g}
            for name, g in flip_gaps.items()}
        all_gaps = [x for g in flip_gaps.values() for x in g]
        max_flip_gap = max(all_gaps) if all_gaps else float("nan")
        results["max_flip_rate_gap"] = float(max_flip_gap)

        # Confounded legacy comparison, explicitly labeled.
        wsb_max_gap = max(pruning_results["acc_gap"]) if pruning_results["acc_gap"] else 0
        margin_max_gap = max(pruning_margin_results["acc_gap"]) if pruning_margin_results["acc_gap"] else 0
        results["wsb_vs_margin_CONFOUNDED_acc_gaps"] = {
            "wsb_max_gap": wsb_max_gap,
            "margin_max_gap": margin_max_gap,
            "note": "group accuracy gaps confound compression sensitivity "
                    "with baseline difficulty; use primary_flip_rate_gaps",
        }

        results["key_finding"] = (
            f"High-H samples flip more under compression (max within-sample "
            f"flip-rate gap: {max_flip_gap:+.1%})"
            if np.isfinite(max_flip_gap) and max_flip_gap > 0.02
            else "No consistent within-sample compression-sensitivity gap "
                 "between H groups (flip-rate gaps small or sign-inconsistent)"
        )
        
        if tracker:
            tracker.set_metadata("compression_results", results)
        
        if self.logger:
            self.logger.info(f"\nKey Finding (PRIMARY, within-sample): "
                             f"{results['key_finding']}")
            self.logger.info(f"  (Confounded group-acc gaps kept under "
                             f"'wsb_vs_margin_CONFOUNDED_acc_gaps' for reference)")
        
        return results


def run_compression(config: CompressionConfig, logger=None, tracker=None) -> Dict:
    """Run compression experiment."""
    analyzer = CompressionAnalyzer(config, logger)
    return analyzer.run_compression_experiment(tracker)
