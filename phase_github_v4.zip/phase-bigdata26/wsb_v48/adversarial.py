"""
WSB Framework - Adversarial Module (v31, corrected)
====================================================
Key corrections vs v30 (all are correctness bugs, not style):

1. DOMAIN FIX. v30 applied transforms.Normalize to the data, then clamped
   attacks/perturbations to [0, 1] in NORMALIZED space. Normalized CIFAR
   pixels span roughly [-1.99, 2.13]; clamp(0, 1) destroys the image and
   attack_epsilon = 8/255 becomes epsilon*std in pixel units. This
   invalidated every attack/AT number (e.g. PGD-AT clean acc 31%).
   Now: datasets are ToTensor-only ([0, 1] pixel space); normalization is
   a layer inside the model (NormalizedModel). All epsilons, clamps, and
   PHASE perturbations are therefore in the standard pixel domain.

2. EVAL-MODE ATTACK CRAFTING. v30 crafted PGD/TRADES adversarial examples
   with model.train(): BatchNorm running stats were updated by every inner
   attack step and dropout noised the attack gradients. Now: attacks are
   crafted in eval() mode; only the parameter update runs in train() mode.
   TRADES natural logits are computed once (eval, no_grad), not per step.

3. BATCHED EVALUATION. Per-sample loops replaced by batched PHASE
   (vectorized bincount for the predicted-class fast path) and batched
   PGD, ~30-100x faster on GPU with identical semantics.

4. STRATIFIED ANALYSIS. Hard/easy (by confidence) and low/high margin
   splits are computed inside the main analysis (the paper's headline
   table), with the same sample sets across all metrics.

5. PLATEAU GUARD + ESTIMATOR. Per-sample independence plateau
   1 - sum p_i^2 and label-flip rate recorded so epsilon-sweeps can mark
   the identified window; Miller-Madow entropy reported alongside MLE.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader

from .config import OptionBConfig
from .core import (compute_basin_entropy, independence_plateau, StatisticalTests,
                   analyze_distribution_inversion, aggregate_seed_results,
                   compare_to_baselines)
from .classifiers import (PredictedClassClassifier, BinaryCorrectClassifier,
                          EntropyBucketClassifier, MarginBucketClassifier,
                          ConfidenceBucketClassifier)
from .data import DATASET_STATS


# =============================================================================
# MODELS (backbone unchanged; normalization moved inside via NormalizedModel)
# =============================================================================

def _flat_dim(features: nn.Module, in_channels: int, image_size: int) -> int:
    """Flatten dimension by dummy forward: architectures stay identical for
    their intended input sizes but no longer CRASH on other sizes (v32 bug:
    CIFARCNN hardcoded 256*4*4 for 32x32; MNIST's 28x28 gives a different
    flatten dim and the first Linear failed)."""
    with torch.no_grad():
        z = features(torch.zeros(1, in_channels, image_size, image_size))
    return int(z.numel())


class SimpleCNN(nn.Module):
    def __init__(self, n_classes=10, in_channels=1, image_size=28):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 64, 3, padding=1), nn.ReLU(),
        )
        d = _flat_dim(self.conv, in_channels, image_size)  # 64*7*7 at 28x28
        self.fc = nn.Sequential(nn.Flatten(), nn.Linear(d, 256), nn.ReLU(),
                                nn.Linear(256, n_classes))

    def forward(self, x):
        return self.fc(self.conv(x))


class CIFARCNN(nn.Module):
    def __init__(self, n_classes=10, in_channels=3, image_size=32):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout(0.25),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.Conv2d(128, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout(0.25),
            nn.Conv2d(128, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(),
            nn.Conv2d(256, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout(0.25),
        )
        d = _flat_dim(self.features, in_channels, image_size)  # 256*4*4 at 32x32
        self.classifier = nn.Sequential(nn.Flatten(), nn.Linear(d, 512),
                                        nn.ReLU(), nn.Dropout(0.5),
                                        nn.Linear(512, n_classes))

    def forward(self, x):
        return self.classifier(self.features(x))


class ResNetBlock(nn.Module):
    def __init__(self, in_c, out_c, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_c, out_c, 3, stride, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_c)
        self.conv2 = nn.Conv2d(out_c, out_c, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_c)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_c != out_c:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_c, out_c, 1, stride, bias=False), nn.BatchNorm2d(out_c))

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return F.relu(out + self.shortcut(x))


class ResNet18(nn.Module):
    def __init__(self, n_classes=10, in_channels=3):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, 64, 3, 1, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.layer1 = self._make_layer(64, 64, 2, 1)
        self.layer2 = self._make_layer(64, 128, 2, 2)
        self.layer3 = self._make_layer(128, 256, 2, 2)
        self.layer4 = self._make_layer(256, 512, 2, 2)
        self.fc = nn.Linear(512, n_classes)

    def _make_layer(self, in_c, out_c, n_blocks, stride):
        layers = [ResNetBlock(in_c, out_c, stride)]
        for _ in range(1, n_blocks):
            layers.append(ResNetBlock(out_c, out_c, 1))
        return nn.Sequential(*layers)

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.layer4(self.layer3(self.layer2(self.layer1(out))))
        out = F.adaptive_avg_pool2d(out, 1).view(out.size(0), -1)
        return self.fc(out)


class NormalizedModel(nn.Module):
    """
    Wraps a backbone so its INPUT domain is [0, 1] pixel space and the
    dataset normalization happens inside the forward pass. This is the
    single point through which the domain fix flows: everything outside
    (attacks, PHASE clouds, clamps) works in pixel space.
    """
    def __init__(self, backbone: nn.Module, mean, std):
        super().__init__()
        self.backbone = backbone
        self.register_buffer("mu", torch.tensor(mean, dtype=torch.float32).view(1, -1, 1, 1))
        self.register_buffer("sd", torch.tensor(std, dtype=torch.float32).view(1, -1, 1, 1))

    def forward(self, x):
        return self.backbone((x - self.mu) / self.sd)


DATASET_IMAGE_SIZE = {"mnist": 28, "cifar10": 32, "cifar100": 32, "svhn": 32}


def get_model(name, n_classes, in_channels, dataset: Optional[str] = None) -> nn.Module:
    img = DATASET_IMAGE_SIZE.get(dataset, 32 if in_channels == 3 else 28)
    if name == "simple_cnn":
        backbone = SimpleCNN(n_classes, in_channels, image_size=img)
    elif name == "cifar_cnn":
        backbone = CIFARCNN(n_classes, in_channels, image_size=img)
    elif name == "resnet18":
        backbone = ResNet18(n_classes, in_channels)
    else:
        raise ValueError(f"Unknown model: {name}")
    if dataset is not None and dataset in DATASET_STATS:
        mean, std = DATASET_STATS[dataset]
        return NormalizedModel(backbone, mean, std)
    # No known stats: identity normalization (still [0,1] domain).
    return NormalizedModel(backbone, (0.0,) * in_channels, (1.0,) * in_channels)


def load_dataset(name, data_dir, train=True, augment=True):
    """
    Returns dataset with tensors in [0, 1] (ToTensor only, plus PIL-space
    augmentation for training when augment=True). NEVER add
    transforms.Normalize here; the model normalizes internally
    (see NormalizedModel).

    augment=False returns the train split WITHOUT RandomCrop/Flip: required
    whenever per-sample scores must refer to the canonical image (e.g. the
    causal-intervention scoring pass), since an augmented dataset returns a
    different random view on every access.
    """
    from torchvision import datasets, transforms
    if name == "mnist":
        t = transforms.ToTensor()
        return datasets.MNIST(data_dir, train=train, download=True, transform=t), 10, 1
    if name == "cifar10":
        t = (transforms.Compose([transforms.RandomCrop(32, 4),
                                 transforms.RandomHorizontalFlip(),
                                 transforms.ToTensor()])
             if (train and augment) else transforms.ToTensor())
        return datasets.CIFAR10(data_dir, train=train, download=True, transform=t), 10, 3
    if name == "cifar100":
        t = (transforms.Compose([transforms.RandomCrop(32, 4),
                                 transforms.RandomHorizontalFlip(),
                                 transforms.ToTensor()])
             if (train and augment) else transforms.ToTensor())
        return datasets.CIFAR100(data_dir, train=train, download=True, transform=t), 100, 3
    if name == "svhn":
        t = transforms.ToTensor()
        return (datasets.SVHN(data_dir, split='train' if train else 'test',
                              download=True, transform=t), 10, 3)
    raise ValueError(f"Unknown dataset: {name}")


# =============================================================================
# ATTACKS (all operate in [0, 1] pixel space; consistent with NormalizedModel)
# =============================================================================

class PGDAttack:
    """
    L-inf PGD with independent random restarts. Crafts in eval() mode and
    restores the model's prior mode. A sample counts as attacked successfully
    if ANY restart flips it; the returned adversarial example per sample is
    the first successful one (or the last restart's if none succeeded).
    restarts=1 reproduces single-run PGD. (v31.0 defined
    eval_attack_restarts in the config but never implemented it.)
    """
    def __init__(self, model, epsilon, alpha, steps, device, random_start=True,
                 restarts=1):
        self.model, self.epsilon, self.alpha, self.steps = model, epsilon, alpha, steps
        self.device, self.random_start = device, random_start
        self.restarts = max(1, int(restarts))

    def _one_restart(self, x, y):
        x_adv = x.clone()
        if self.random_start:
            x_adv = x_adv + torch.empty_like(x_adv).uniform_(-self.epsilon, self.epsilon)
            x_adv = torch.clamp(x_adv, 0, 1)
        for _ in range(self.steps):
            x_adv.requires_grad_(True)
            loss = F.cross_entropy(self.model(x_adv), y)
            grad = torch.autograd.grad(loss, x_adv)[0]
            x_adv = x_adv.detach() + self.alpha * grad.sign()
            x_adv = torch.min(torch.max(x_adv, x - self.epsilon), x + self.epsilon)
            x_adv = torch.clamp(x_adv, 0, 1)
        with torch.no_grad():
            success = (self.model(x_adv).argmax(1) != y)
        return x_adv.detach(), success

    def attack(self, x, y):
        was_training = self.model.training
        self.model.eval()
        x = x.detach()
        best_adv, any_success = None, None
        for _ in range(self.restarts):
            x_adv, success = self._one_restart(x, y)
            if best_adv is None:
                best_adv, any_success = x_adv, success
            else:
                newly = success & ~any_success
                if newly.any():
                    best_adv = torch.where(
                        newly.view(-1, *([1] * (x.dim() - 1))), x_adv, best_adv)
                any_success = any_success | success
            if bool(any_success.all()):
                break
        if was_training:
            self.model.train()
        return best_adv, any_success


class FGSMAttack:
    def __init__(self, model, epsilon, device):
        self.model, self.epsilon, self.device = model, epsilon, device

    def attack(self, x, y):
        was_training = self.model.training
        self.model.eval()
        x = x.detach()
        x_req = x.clone().requires_grad_(True)
        loss = F.cross_entropy(self.model(x_req), y)
        grad = torch.autograd.grad(loss, x_req)[0]
        x_adv = torch.clamp(x + self.epsilon * grad.sign(), 0, 1)
        with torch.no_grad():
            pred = self.model(x_adv).argmax(1)
            success = (pred != y)
        if was_training:
            self.model.train()
        return x_adv, success


@torch.no_grad()
def local_lipschitz_batch(model, xb: torch.Tensor, n_samples: int,
                          sigma: float = 0.01) -> np.ndarray:
    """
    Canonical local-Lipschitz estimate (single implementation; reviewer_proof
    previously probed unclamped, out-of-domain inputs and adversarial.py
    silently capped the configured probe count at 10 and divided by the
    PRE-projection perturbation norm). Probes are clamped into [0, 1] and the
    denominator is the ACTUAL post-projection displacement; near-zero
    displacements are skipped.
    """
    model.eval()
    base = model(xb)
    acc = torch.zeros(xb.size(0), device=xb.device)
    used = torch.zeros(xb.size(0), device=xb.device)
    for _ in range(max(1, int(n_samples))):
        x_pert = torch.clamp(xb + torch.randn_like(xb) * sigma, 0, 1)
        disp = (x_pert - xb).view(xb.size(0), -1).norm(dim=-1)
        ok = disp > 1e-8
        out = model(x_pert)
        ratio = (out - base).norm(dim=-1) / disp.clamp(min=1e-8)
        acc += torch.where(ok, ratio, torch.zeros_like(ratio))
        used += ok.float()
    return (acc / used.clamp(min=1.0)).cpu().numpy()


def _craft_pgd(model, x, y, epsilon, alpha, steps):
    """Shared PGD crafting (eval mode assumed by caller)."""
    x_adv = x.detach() + torch.empty_like(x).uniform_(-epsilon, epsilon)
    x_adv = torch.clamp(x_adv, 0, 1)
    for _ in range(steps):
        x_adv.requires_grad_(True)
        loss = F.cross_entropy(model(x_adv), y)
        grad = torch.autograd.grad(loss, x_adv)[0]
        x_adv = x_adv.detach() + alpha * grad.sign()
        x_adv = torch.min(torch.max(x_adv, x - epsilon), x + epsilon)
        x_adv = torch.clamp(x_adv, 0, 1)
    return x_adv.detach()


def pgd_training_step(model, optimizer, x, y, epsilon, alpha, steps, device):
    """
    Madry adversarial training step. Attack crafted in eval() mode (frozen
    BN stats, no dropout noise in attack gradients); update in train() mode.
    """
    model.eval()
    x_adv = _craft_pgd(model, x, y, epsilon, alpha, steps)
    model.train()
    optimizer.zero_grad()
    loss = F.cross_entropy(model(x_adv), y)
    loss.backward()
    optimizer.step()
    return loss.item()


def trades_loss(model, x, y, epsilon, alpha, steps, beta, device):
    """
    TRADES loss. Inner maximization runs in eval() mode against FIXED
    natural logits (computed once); the returned loss re-runs both forward
    passes in train() mode so BN/dropout behave as in normal training and
    gradients flow to parameters.
    """
    # --- inner maximization (eval mode, fixed natural target) ---
    was_training = model.training
    model.eval()
    with torch.no_grad():
        nat_soft = F.softmax(model(x), dim=1)
    x_adv = x.detach() + 0.001 * torch.randn_like(x)
    x_adv = torch.clamp(x_adv, 0, 1)
    for _ in range(steps):
        x_adv.requires_grad_(True)
        kl = F.kl_div(F.log_softmax(model(x_adv), dim=1), nat_soft,
                      reduction='batchmean')
        grad = torch.autograd.grad(kl, x_adv)[0]
        x_adv = x_adv.detach() + alpha * grad.sign()
        x_adv = torch.min(torch.max(x_adv, x - epsilon), x + epsilon)
        x_adv = torch.clamp(x_adv, 0, 1)
    x_adv = x_adv.detach()
    if was_training:
        model.train()
    # --- loss for the parameter update (train mode) ---
    # Matches the official TRADES objective: gradients flow through BOTH
    # arguments of the KL term (no detach on the natural branch).
    nat_logits = model(x)
    adv_logits = model(x_adv)
    loss_nat = F.cross_entropy(nat_logits, y)
    loss_rob = F.kl_div(F.log_softmax(adv_logits, dim=1),
                        F.softmax(nat_logits, dim=1),
                        reduction='batchmean')
    return loss_nat + beta * loss_rob


# =============================================================================
# PER-SAMPLE RECORD
# =============================================================================

@dataclass
class SampleResult:
    idx: int
    true_label: int
    pred_label: int
    correct: bool
    h_basin: float
    h_basin_mm: float          # Miller-Madow corrected
    lfr: float                 # label-flip rate within the PHASE cloud
    plateau: float             # 1 - sum p_i^2 (independence plateau)
    phase_counts: List[float]
    attack_success: bool
    confidence: float
    margin: float
    entropy: float
    gradient_norm: float
    local_lipschitz: float = 0.0

    def to_dict(self):
        return asdict(self)


# =============================================================================
# ANALYZER
# =============================================================================

class AdversarialAnalyzer:
    def __init__(self, config: OptionBConfig, logger=None):
        self.config, self.logger = config, logger
        self.device = torch.device(config.device if torch.cuda.is_available() else "cpu")
        # NOTE: the analyzer never rewrites the config it is handed. Dataset
        # defaults are applied ONLY at construction time via
        # config.resolve_option_b_config (precedence: base defaults ->
        # dataset defaults -> explicit user overrides). v31.0 overwrote
        # explicit user settings here, so CLI runs silently differed from the
        # requested experiment.
        self.train_dataset, self.n_classes, self.in_channels = load_dataset(
            config.dataset, config.data_dir, True)
        self.test_dataset, _, _ = load_dataset(config.dataset, config.data_dir, False)
        self.model = get_model(config.model_name, self.n_classes, self.in_channels,
                               dataset=config.dataset).to(self.device)
        if logger:
            logger.info(f"Dataset: {config.dataset}, Model: {config.model_name} "
                        f"(normalization inside model; data domain [0,1])")
            logger.info(f"  Classes: {self.n_classes}, Channels: {self.in_channels}")

    # ---------------- training ----------------

    def train_model(self, tracker=None):
        if self.logger:
            self.logger.info(f"Training for {self.config.train_epochs} epochs "
                             f"(AT: {self.config.adversarial_training})")
        train_loader = DataLoader(self.train_dataset, batch_size=self.config.batch_size,
                                  shuffle=True, num_workers=2, pin_memory=True)
        optimizer = optim.SGD(self.model.parameters(), lr=self.config.learning_rate,
                              momentum=self.config.momentum,
                              weight_decay=self.config.weight_decay)
        if self.config.lr_schedule == "multistep":
            scheduler = optim.lr_scheduler.MultiStepLR(
                optimizer, milestones=list(self.config.lr_milestones),
                gamma=self.config.lr_gamma)
        else:
            scheduler = optim.lr_scheduler.CosineAnnealingLR(
                optimizer, T_max=self.config.train_epochs)

        for epoch in range(self.config.train_epochs):
            self.model.train()
            total_loss, correct, total = 0.0, 0, 0
            for x, y in train_loader:
                x, y = x.to(self.device), y.to(self.device)
                if self.config.adversarial_training == "pgd":
                    loss = pgd_training_step(self.model, optimizer, x, y,
                                             self.config.attack_epsilon,
                                             self.config.attack_alpha,
                                             self.config.attack_steps, self.device)
                    total_loss += loss * x.size(0)
                elif self.config.adversarial_training == "trades":
                    optimizer.zero_grad()
                    loss = trades_loss(self.model, x, y, self.config.attack_epsilon,
                                       self.config.attack_alpha,
                                       self.config.attack_steps,
                                       self.config.trades_beta, self.device)
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item() * x.size(0)
                else:
                    optimizer.zero_grad()
                    loss = F.cross_entropy(self.model(x), y)
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item() * x.size(0)
                with torch.no_grad():
                    correct += (self.model(x).argmax(1) == y).sum().item()
                    total += x.size(0)
            scheduler.step()
            if (epoch + 1) % 10 == 0 and self.logger:
                self.logger.info(f"Epoch {epoch+1}/{self.config.train_epochs} | "
                                 f"Loss: {total_loss/total:.4f} | "
                                 f"Acc: {100*correct/total:.2f}%")
            if tracker:
                tracker.log("train_loss", total_loss / total, epoch)
                tracker.log("train_acc", correct / total, epoch)

    # ---------------- PHASE ----------------

    def _get_classifier(self, y):
        if self.config.adv_phase_classifier == "predicted_class":
            return PredictedClassClassifier(self.n_classes)
        elif self.config.adv_phase_classifier == "binary_correct":
            return BinaryCorrectClassifier(y)
        elif self.config.adv_phase_classifier == "entropy_bucket":
            return EntropyBucketClassifier(self.config.n_entropy_buckets,
                                           np.log(self.n_classes))
        elif self.config.adv_phase_classifier == "margin_bucket":
            return MarginBucketClassifier(self.config.n_confidence_buckets)
        elif self.config.adv_phase_classifier == "confidence_bucket":
            return ConfidenceBucketClassifier(self.config.n_confidence_buckets,
                                              self.n_classes)
        raise ValueError(
            f"Unknown adv_phase_classifier '{self.config.adv_phase_classifier}'"
            " - refusing to silently fall back to predicted_class (an ablation"
            " that requested a different classifier would become a duplicate).")

    @torch.no_grad()
    def compute_h_basin_batch(self, xb: torch.Tensor, clean_logits: torch.Tensor,
                              yb: torch.Tensor,
                              n_perturbations: Optional[int] = None
                              ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Vectorized PHASE for a batch of B samples.

        Args:
            xb: [B, C, H, W] inputs in [0, 1].
            clean_logits: [B, n_classes] logits of the UNPERTURBED inputs
                (used only to define each sample's reference phase for LFR).
            yb: [B] true labels (needed to construct the binary_correct
                classifier; unused by the other classifiers).

        Returns (h_basin[B], counts[B, K], lfr[B], plateau[B]) where
        lfr[b] is the fraction of cloud outcomes whose PHASE differs from the
        phase of the clean input (for predicted_class this is the label-flip
        rate; for bucket classifiers it is the bucket-flip rate).

        Fast path: predicted_class classifier -> argmax + bincount, no
        per-logit python loop. Other classifiers fall back to a python loop
        over logits (they are cheap 1D functions).
        """
        n_pert = n_perturbations or self.config.n_perturbations
        B = xb.size(0)
        use_fast = self.config.adv_phase_classifier == "predicted_class"
        ys_np = yb.cpu().numpy()
        clean_logits_np = clean_logits.cpu().numpy()
        if use_fast:
            K = self.n_classes
            clfs = None
            clean_phase = clean_logits.argmax(1).cpu().numpy()
        else:
            # One classifier per sample: binary_correct depends on the TRUE
            # label of that sample; the others ignore the argument.
            clfs = [self._get_classifier(int(ys_np[b])) for b in range(B)]
            K = clfs[0].n_phases
            clean_phase = np.array([clfs[b].classify(clean_logits_np[b])
                                    for b in range(B)])
        counts = np.zeros((B, K), dtype=np.int64)
        self.model.eval()

        # Chunk over perturbations to bound memory: (B * chunk) images per forward.
        chunk = max(1, min(n_pert, max(1, 4096 // max(B, 1))))
        done = 0
        while done < n_pert:
            c = min(chunk, n_pert - done)
            x_rep = xb.repeat_interleave(c, dim=0)                      # [B*c, ...]
            pert = torch.empty_like(x_rep).uniform_(-self.config.wsb_epsilon,
                                                    self.config.wsb_epsilon)
            x_pert = torch.clamp(x_rep + pert, 0, 1)
            logits = self.model(x_pert)                                 # [B*c, C]
            if use_fast:
                phases = logits.argmax(1).view(B, c).cpu().numpy()
                for b in range(B):
                    counts[b] += np.bincount(phases[b], minlength=K)
            else:
                logits_np = logits.view(B, c, -1).cpu().numpy()
                for b in range(B):
                    for l in logits_np[b]:
                        p = clfs[b].classify(l)
                        if 0 <= p < K:
                            counts[b, p] += 1
            done += c

        h = np.array([compute_basin_entropy(counts[b]) for b in range(B)])
        totals = counts.sum(axis=1).astype(np.float64)
        same = counts[np.arange(B), np.clip(clean_phase, 0, K - 1)]
        lfr = 1.0 - same / np.maximum(totals, 1.0)
        plateau = np.array([independence_plateau(counts[b]) for b in range(B)])
        return h, counts, lfr, plateau

    # ---------------- pointwise baselines ----------------

    def compute_baselines_batch(self, xb: torch.Tensor, yb: torch.Tensor) -> Dict[str, np.ndarray]:
        self.model.eval()
        x = xb.detach().clone().requires_grad_(True)
        logits = self.model(x)
        loss = F.cross_entropy(logits, yb, reduction='sum')
        grad = torch.autograd.grad(loss, x)[0]
        gradient_norm = grad.view(grad.size(0), -1).norm(2, dim=1).detach().cpu().numpy()
        with torch.no_grad():
            probs = F.softmax(logits, dim=-1)
            confidence = probs.max(dim=-1)[0].cpu().numpy()
            sp = probs.sort(dim=-1, descending=True)[0]
            margin = (sp[:, 0] - sp[:, 1]).cpu().numpy() if sp.size(1) > 1 \
                else np.zeros(sp.size(0))
            entropy = (-probs * torch.log(probs + 1e-10)).sum(-1).cpu().numpy()
        local_lip = np.zeros(xb.size(0))
        if self.config.compute_local_lipschitz:
            local_lip = local_lipschitz_batch(
                self.model, xb, self.config.lipschitz_n_samples)
        return {"gradient_norm": gradient_norm, "confidence": confidence,
                "margin": margin, "entropy": entropy, "local_lipschitz": local_lip}

    # ---------------- main analysis ----------------

    def run_analysis(self, tracker=None) -> Dict:
        cfg = self.config
        if self.logger:
            self.logger.info(f"Analyzing {cfg.n_test_samples} test samples (batched)")
        # Fixed (seed-independent) evaluation subset: all seeds are scored on
        # the same test samples, so cross-seed variance reflects training
        # randomness only, and seeds are directly comparable.
        rng = np.random.default_rng(0)
        indices = rng.choice(len(self.test_dataset),
                             min(cfg.n_test_samples, len(self.test_dataset)),
                             replace=False)
        attack = PGDAttack(self.model, cfg.attack_epsilon, cfg.attack_alpha,
                           cfg.eval_attack_steps, self.device,
                           restarts=getattr(cfg, "eval_attack_restarts", 1))
        eval_bs = 128
        sample_results: List[SampleResult] = []

        for start in range(0, len(indices), eval_bs):
            batch_idx = indices[start:start + eval_bs]
            xs, ys = zip(*[self.test_dataset[int(i)] for i in batch_idx])
            xb = torch.stack(xs).to(self.device)
            yb = torch.tensor(ys).to(self.device)
            with torch.no_grad():
                self.model.eval()
                logits = self.model(xb)
                preds = logits.argmax(1)
            h, counts, lfr, plateau = self.compute_h_basin_batch(xb, logits, yb)
            h_mm = np.array([compute_basin_entropy(counts[b], method="miller_madow")
                             for b in range(len(batch_idx))])
            base = self.compute_baselines_batch(xb, yb)
            _, succ = attack.attack(xb, yb)
            succ = succ.cpu().numpy()
            preds_np, ys_np = preds.cpu().numpy(), yb.cpu().numpy()
            for b, idx in enumerate(batch_idx):
                sample_results.append(SampleResult(
                    idx=int(idx), true_label=int(ys_np[b]), pred_label=int(preds_np[b]),
                    correct=bool(preds_np[b] == ys_np[b]),
                    h_basin=float(h[b]), h_basin_mm=float(h_mm[b]),
                    lfr=float(lfr[b]), plateau=float(plateau[b]),
                    phase_counts=counts[b].tolist(),
                    attack_success=bool(succ[b]),
                    confidence=float(base["confidence"][b]),
                    margin=float(base["margin"][b]),
                    entropy=float(base["entropy"][b]),
                    gradient_norm=float(base["gradient_norm"][b]),
                    local_lipschitz=float(base["local_lipschitz"][b])))
            if self.logger and (start // eval_bs) % 2 == 1:
                asr = np.mean([r.attack_success for r in sample_results if r.correct]) \
                    if any(r.correct for r in sample_results) else 0.0
                self.logger.info(f"  {len(sample_results)}/{len(indices)} samples | "
                                 f"H mean so far: "
                                 f"{np.mean([r.h_basin for r in sample_results]):.4f} | "
                                 f"ASR: {100*asr:.2f}%")

        return self._analyze_results(sample_results, tracker)

    @staticmethod
    def _stratified_auc(scores: Dict[str, np.ndarray], target: np.ndarray,
                        confidence: np.ndarray, margin: np.ndarray) -> Dict:
        """
        AUC per metric on: All / Easy (top-50% conf) / Hard (bottom-50% conf) /
        HighMargin / LowMargin. Same sample sets across metrics by construction.
        """
        med_c = np.median(confidence)
        med_m = np.median(margin)
        splits = {
            "all": np.ones_like(target, dtype=bool),
            "easy_high_conf": confidence >= med_c,
            "hard_low_conf": confidence < med_c,
            "high_margin": margin >= med_m,
            "low_margin": margin < med_m,
        }
        out = {}
        for split_name, mask in splits.items():
            if mask.sum() < 20 or len(np.unique(target[mask])) < 2:
                out[split_name] = {"n": int(mask.sum()), "degenerate": True}
                continue
            row = {"n": int(mask.sum()),
                   "asr": float(np.mean(target[mask]))}
            for mname, s in scores.items():
                roc = StatisticalTests.roc_auc_analysis(target[mask], s[mask],
                                                        n_bootstrap=200)
                row[mname] = float(roc["roc_auc"])
            ordered = sorted([m for m in scores], key=lambda m: -row[m])
            row["ranking"] = ordered
            row["h_basin_rank"] = ordered.index("h_basin") + 1
            out[split_name] = row
        return out

    def _analyze_results(self, results: List[SampleResult], tracker=None) -> Dict:
        h_vals = np.array([r.h_basin for r in results])
        h_mm = np.array([r.h_basin_mm for r in results])
        attack_success = np.array([r.attack_success for r in results])
        correct = np.array([r.correct for r in results])
        # Normalize by the ACTUAL phase cardinality of the configured
        # classifier (log n_classes is only right for predicted_class; for
        # binary_correct K=2, buckets K=n_buckets, etc.).
        n_phases = self._get_classifier(0).n_phases
        log_k = float(np.log(n_phases)) if n_phases > 1 else 1.0

        # Per-sample plateau guard: fraction of samples whose flip statistics
        # are identified (LFR_i / plateau_i < 0.9); pure clouds (plateau=0,
        # LFR=0) are identified by convention. A ratio of aggregate means
        # hides samples sitting on the plateau.
        lfr_arr = np.array([r.lfr for r in results])
        plat_arr = np.array([r.plateau for r in results])
        with np.errstate(divide="ignore", invalid="ignore"):
            ratio = np.where(plat_arr > 1e-12, lfr_arr / plat_arr, 0.0)
        identified = ratio < 0.9

        analysis = {
            "n_samples": len(results),
            "clean_accuracy": float(correct.mean()),
            "attack_success_rate": float(attack_success[correct].mean())
                if correct.sum() > 0 else 0,
            # Two explicit estimands: H over ALL analyzed samples and H over
            # the clean-correct subpopulation (the one ASR/AUC condition on).
            # Model-to-model comparisons of H_all are confounded by clean
            # accuracy; use the matching estimand for the comparison at hand.
            "h_basin_mean_all": float(h_vals.mean()),
            "h_basin_mean_clean_correct": float(h_vals[correct].mean())
                if correct.sum() > 0 else float("nan"),
            "h_basin_mean": float(h_vals.mean()),  # legacy alias of _all
            "h_basin_std": float(h_vals.std()),
            "h_basin_max": float(h_vals.max()),
            "h_basin_min": float(h_vals.min()),
            "h_basin_mm_mean": float(h_mm.mean()),
            "h_basin_mean_normalized": float(h_vals.mean() / log_k),
            "h_basin_max_normalized": float(h_vals.max() / log_k),
            "n_phases": int(n_phases),
            "log_n_phases": log_k,
            "mean_plateau": float(plat_arr.mean()),
            "mean_lfr": float(lfr_arr.mean()),
            "plateau_identified_fraction": float(identified.mean()),
            "per_sample": [r.to_dict() for r in results]
                if self.config.save_per_sample else [],
        }

        if correct.sum() > 0:
            target = attack_success[correct].astype(int)
            h_correct = h_vals[correct]
            # AUC VALIDITY GATE: an AUC needs enough of BOTH classes. At
            # ASR ~100% (standard CIFAR at eps=8/255) the target is (near-)
            # constant: seeds with 1-2 survivors produce AUCs resting on 1-2
            # negatives and ASR=100% seeds pin AUC at 0.5; averaging those
            # into a cross-seed aggregate is meaningless. Seeds failing the
            # gate carry auc_valid=False and are excluded from the aggregate
            # AUC (n_auc_valid_seeds is reported). The regime-level statement
            # for such seeds is the ASR itself, not a discrimination score.
            n_pos, n_neg = int(target.sum()), int(len(target) - target.sum())
            analysis["auc_n_pos"] = n_pos
            analysis["auc_n_neg"] = n_neg
            analysis["auc_valid"] = bool(min(n_pos, n_neg) >= 10)
            if not analysis["auc_valid"] and self.logger:
                self.logger.warning(
                    f"  DEGENERATE TARGET for AUC: n_attacked={n_pos}, "
                    f"n_survived={n_neg} among clean-correct (need >=10 "
                    f"each); this seed's AUCs are flagged invalid and "
                    f"excluded from the aggregate.")
            roc = StatisticalTests.roc_auc_analysis(target, h_correct)
            analysis["h_basin_roc_auc"] = roc["roc_auc"]
            analysis["h_basin_roc_auc_ci"] = (roc["roc_auc_ci_lower"],
                                              roc["roc_auc_ci_upper"])
            # Miller-Madow sanity: correction is monotone per support size, but
            # verify the ranking of samples is essentially unchanged.
            mm_roc = StatisticalTests.roc_auc_analysis(target, h_mm[correct],
                                                       n_bootstrap=100)
            analysis["h_basin_mm_roc_auc"] = mm_roc["roc_auc"]
            if self.config.save_roc_data:
                analysis["roc_curve"] = {"fpr": roc["fpr"], "tpr": roc["tpr"]}

            baselines = {
                "gradient_norm": np.array([r.gradient_norm for r in results])[correct],
                "margin": -np.array([r.margin for r in results])[correct],
                "confidence": -np.array([r.confidence for r in results])[correct],
                "entropy": np.array([r.entropy for r in results])[correct],
                "local_lipschitz": np.array([r.local_lipschitz for r in results])[correct],
            }
            analysis["baseline_comparison"] = compare_to_baselines(
                h_correct, baselines, target)

            # HEADLINE TABLE: stratified hard/easy + margin splits.
            scores = dict(baselines)
            scores["h_basin"] = h_correct
            scores["lfr"] = np.array([r.lfr for r in results])[correct]
            analysis["stratified"] = self._stratified_auc(
                scores, target,
                confidence=np.array([r.confidence for r in results])[correct],
                margin=np.array([r.margin for r in results])[correct])

        # Distribution inversion over the CLEAN-CORRECT population - the same
        # population the vulnerability target conditions on.
        cc_counts = [np.array(r.phase_counts) for r, c in zip(results, correct) if c]
        if len(cc_counts) > 10:
            try:
                inversion = analyze_distribution_inversion(h_vals[correct], cc_counts)
                analysis["distribution_inversion"] = inversion.to_dict()
                analysis["distribution_inversion"]["population"] = "clean_correct"
            except Exception:
                pass

        corr = StatisticalTests.correlation_test(
            h_vals[correct], attack_success[correct].astype(float))
        analysis["h_basin_asr_correlation"] = corr

        if tracker:
            tracker.set_metadata("analysis",
                                 {k: v for k, v in analysis.items() if k != "per_sample"})

        if self.logger:
            self.logger.info("\n--- Analysis Results ---")
            self.logger.info(f"  Samples: {analysis['n_samples']}, "
                             f"Clean Acc: {100*analysis['clean_accuracy']:.2f}%, "
                             f"ASR: {100*analysis['attack_success_rate']:.2f}%")
            self.logger.info(f"  H_basin: mean={analysis['h_basin_mean']:.4f} "
                             f"(MM {analysis['h_basin_mm_mean']:.4f}), "
                             f"max={analysis['h_basin_max']:.4f}, "
                             f"mean/logK={analysis['h_basin_mean_normalized']:.4f}")
            self.logger.info(f"  Plateau guard: identified fraction="
                             f"{analysis['plateau_identified_fraction']:.3f} "
                             f"(per-sample LFR_i/plateau_i < 0.9); "
                             f"mean LFR={analysis['mean_lfr']:.4f}, "
                             f"mean plateau={analysis['mean_plateau']:.4f}")
            self.logger.info(f"  H_basin ROC-AUC: {analysis.get('h_basin_roc_auc', 0):.4f} "
                             f"(CI {analysis.get('h_basin_roc_auc_ci', (0, 0))}); "
                             f"MM ROC-AUC: {analysis.get('h_basin_mm_roc_auc', 0):.4f}")
            if "stratified" in analysis:
                self.logger.info("  Stratified ROC-AUC (headline table):")
                for split, row in analysis["stratified"].items():
                    if row.get("degenerate"):
                        continue
                    self.logger.info(
                        f"    {split:16s} n={row['n']:5d} ASR={100*row['asr']:5.1f}% | "
                        f"H={row['h_basin']:.3f} grad={row.get('gradient_norm', 0):.3f} "
                        f"conf={row.get('confidence', 0):.3f} "
                        f"marg={row.get('margin', 0):.3f} "
                        f"ent={row.get('entropy', 0):.3f} "
                        f"lfr={row.get('lfr', 0):.3f} | "
                        f"H rank {row['h_basin_rank']}/{len(row['ranking'])}")
            if "distribution_inversion" in analysis:
                di = analysis["distribution_inversion"]
                self.logger.info(
                    f"  Distribution inversion: KL(uniform) low-H="
                    f"{di.get('low_h_kl_from_uniform', 0):.4f}, "
                    f"high-H={di.get('high_h_kl_from_uniform', 0):.4f}, "
                    f"rare-phase increase="
                    f"{di.get('rare_phase_increase_factor', 0):.2f}x")
            self.logger.info(
                f"  H_basin-ASR: Spearman r={corr.get('spearman_r', 0):.4f} "
                f"(p={corr.get('spearman_p', 1):.4g})")

        return analysis


def run_option_b(config: OptionBConfig, logger=None, tracker=None) -> Dict:
    if logger:
        logger.info("=" * 60 + "\nOPTION B: Adversarial Robustness\n" + "=" * 60)
    all_results = []
    seeds = (list(config.seed_list) if getattr(config, "seed_list", None)
             else list(range(config.n_seeds)))
    for seed in seeds:
        if logger:
            logger.info(f"\n--- Seed {seed + 1} ({len(seeds)} seed(s) this run) ---")
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
        analyzer = AdversarialAnalyzer(config, logger)
        analyzer.train_model(tracker)
        results = analyzer.run_analysis(tracker)
        results["seed"] = seed
        all_results.append(results)

    agg_keys = ["h_basin_mean_all", "h_basin_mean_clean_correct",
                "h_basin_mm_mean", "h_basin_max", "h_basin_mean_normalized",
                "attack_success_rate", "clean_accuracy",
                "mean_plateau", "mean_lfr", "plateau_identified_fraction"]
    # TRAINABILITY GATE: a seed whose clean accuracy is below 3x chance
    # never trained (observed: cifar100 PGD-AT seed at 1.0% = chance).
    # Such seeds are excluded from EVERY aggregate; per-seed records keep
    # them with trained=False (the AUC gate alone left descriptive means
    # polluted by the collapsed seed).
    n_ph = all_results[0].get("n_phases", 10) if all_results else 10
    chance = 1.0 / max(n_ph, 2)
    for r in all_results:
        r["trained"] = bool(r.get("clean_accuracy", 0.0) >= 3.0 * chance)
    informative = [r for r in all_results if r["trained"]]
    excluded_train = [r for r in all_results if not r["trained"]]
    if excluded_train and logger:
        logger.warning(
            f"  TRAINING COLLAPSE: {len(excluded_train)} seed(s) below 3x "
            f"chance clean accuracy, excluded from all aggregates "
            f"(clean: {[round(r['clean_accuracy'],3) for r in excluded_train]}).")
    aggregate = aggregate_seed_results(informative or all_results, agg_keys, 1000)
    aggregate["n_seeds_trained"] = len(informative)
    aggregate["n_seeds_training_collapsed"] = len(excluded_train)
    # AUC aggregated over seeds with a valid (two-sided) target only.
    valid_aucs = [r["h_basin_roc_auc"] for r in informative if r.get("auc_valid")]
    aggregate["n_auc_valid_seeds"] = len(valid_aucs)
    aggregate["n_auc_degenerate_seeds"] = len(all_results) - len(valid_aucs)
    if valid_aucs:
        aggregate["h_basin_roc_auc_mean"] = float(np.mean(valid_aucs))
        aggregate["h_basin_roc_auc_sd"] = (float(np.std(valid_aucs, ddof=1))
                                           if len(valid_aucs) > 1 else 0.0)
    else:
        aggregate["h_basin_roc_auc_mean"] = None
    aggregate["dataset"] = config.dataset
    aggregate["model"] = config.model_name
    aggregate["adversarial_training"] = config.adversarial_training
    aggregate["per_seed"] = [{k: v for k, v in r.items() if k != "per_sample"}
                             for r in all_results]

    if tracker:
        tracker.set_metadata("aggregate", aggregate)
    if logger:
        logger.info(f"\nOption B Complete.")
        if aggregate.get("h_basin_roc_auc_mean") is not None:
            logger.info(f"  H_basin ROC-AUC: {aggregate['h_basin_roc_auc_mean']:.4f} "
                        f"over {aggregate['n_auc_valid_seeds']} valid seeds "
                        f"({aggregate['n_auc_degenerate_seeds']} degenerate excluded)")
        else:
            logger.info("  H_basin ROC-AUC: undefined (all seeds had a "
                        "degenerate target; report the ASR itself)")
        logger.info(f"  ASR: {100*aggregate.get('attack_success_rate_mean', 0):.2f}%")
    return aggregate


# =============================================================================
# STANDALONE TRAINING FUNCTIONS (for reviewer_proof.py) - corrected modes
# =============================================================================

def train_standard(model: nn.Module, train_loader: DataLoader, epochs: int,
                   device: str, logger=None, epoch_callback=None):
    optimizer = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
    scheduler = optim.lr_scheduler.MultiStepLR(
        optimizer, milestones=[epochs // 2, 3 * epochs // 4], gamma=0.1)
    for epoch in range(epochs):
        model.train()
        total_loss, correct, total = 0.0, 0, 0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            logits = model(x)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * x.size(0)
            correct += (logits.argmax(1) == y).sum().item()
            total += x.size(0)
        scheduler.step()
        if logger and (epoch + 1) % 20 == 0:
            logger.info(f"  Epoch {epoch+1}/{epochs}: Loss={total_loss/total:.4f}, "
                        f"Acc={100*correct/total:.2f}%")
        if epoch_callback is not None:
            epoch_callback(epoch, model)


def train_pgd(model: nn.Module, train_loader: DataLoader, epochs: int,
              epsilon: float, alpha: float, steps: int, device: str, logger=None):
    optimizer = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
    scheduler = optim.lr_scheduler.MultiStepLR(
        optimizer, milestones=[epochs // 2, 3 * epochs // 4], gamma=0.1)
    for epoch in range(epochs):
        total_loss, correct, total = 0.0, 0, 0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            loss = pgd_training_step(model, optimizer, x, y, epsilon, alpha, steps, device)
            total_loss += loss * x.size(0)
            with torch.no_grad():
                correct += (model(x).argmax(1) == y).sum().item()
            total += x.size(0)
        scheduler.step()
        if logger and (epoch + 1) % 20 == 0:
            logger.info(f"  Epoch {epoch+1}/{epochs}: Loss={total_loss/total:.4f}, "
                        f"Acc={100*correct/total:.2f}%")


def train_trades(model: nn.Module, train_loader: DataLoader, epochs: int,
                 epsilon: float, alpha: float, steps: int, beta: float,
                 device: str, logger=None):
    optimizer = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
    scheduler = optim.lr_scheduler.MultiStepLR(
        optimizer, milestones=[epochs // 2, 3 * epochs // 4], gamma=0.1)
    for epoch in range(epochs):
        model.train()
        total_loss, correct, total = 0.0, 0, 0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            loss = trades_loss(model, x, y, epsilon, alpha, steps, beta, device)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * x.size(0)
            with torch.no_grad():
                correct += (model(x).argmax(1) == y).sum().item()
            total += x.size(0)
        scheduler.step()
        if logger and (epoch + 1) % 20 == 0:
            logger.info(f"  Epoch {epoch+1}/{epochs}: Loss={total_loss/total:.4f}, "
                        f"Acc={100*correct/total:.2f}%")
