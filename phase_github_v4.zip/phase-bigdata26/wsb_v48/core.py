"""
WSB Framework - Core Module
============================
Basin entropy computation, statistical tests, and distribution analysis.
"""

import numpy as np
from typing import Dict, List, Optional, Callable, Any
from scipy import stats
from dataclasses import dataclass


# =============================================================================
# BASIN ENTROPY COMPUTATION
# =============================================================================

def compute_basin_entropy(phase_counts: np.ndarray, eps: float = 1e-10,
                          method: str = "mle") -> float:
    """
    Compute basin entropy H_basin = -sum(p * log(p)) in nats.

    Args:
        phase_counts: Array of counts per phase.
        eps: unused, kept for API compatibility.
        method: "mle" (plug-in) or "miller_madow" (adds (m-1)/(2N) bias
            correction, m = observed support size, N = total count).
            The plug-in estimator is biased DOWN by ~(m-1)/(2N); with
            N in {32, 64} and K up to 100 this matters, so headline
            numbers should be reported with miller_madow and shown to
            agree in ranking with mle.

    Zero-count phases are masked (contribute exactly 0), rather than
    clipped to eps, so K (array length) never inflates the entropy.
    """
    counts = np.asarray(phase_counts, dtype=np.float64)
    total = counts.sum()
    if total <= 0:
        return 0.0
    p = counts[counts > 0] / total
    h = max(0.0, float(-np.sum(p * np.log(p))))  # 0.0 first: max(-0.0, 0.0) keeps -0.0
    if method == "miller_madow":
        m = int((counts > 0).sum())
        h += (m - 1) / (2.0 * total)
    return h


def independence_plateau(phase_counts: np.ndarray) -> float:
    """
    1 - sum_i p_i^2 for the empirical phase distribution.

    This is the expected label-flip fraction under statistical independence
    of paired evaluations (the "independence plateau"). On any perturbation
    radius where the observed flip rate has reached this value, radius-
    dependence of flip statistics is UNIDENTIFIED: report the ratio
    lfr / independence_plateau and only interpret epsilon-scaling where
    the ratio is bounded away from 1 (we use ratio < 0.9 as the guard).
    """
    counts = np.asarray(phase_counts, dtype=np.float64)
    total = counts.sum()
    if total <= 0:
        return 0.0
    p = counts / total
    return float(1.0 - np.sum(p * p))


def local_entropy_stats(per_point_counts: List[np.ndarray],
                        n_attractors: Optional[int] = None,
                        method: str = "mle") -> Dict[str, Any]:
    """
    Aggregate PER-POINT basin entropies into the quantities the paper reports.

    IMPORTANT: H_mean / H_max are statistics of LOCAL entropies (one entropy
    per probe point, each computed from that point's own perturbation cloud).
    Pooling all counts into one vector and taking a single entropy measures
    global basin FRACTIONS, which is a different (and much less informative)
    quantity. Never report pooled entropy as H_mean.

    Args:
        per_point_counts: list of count vectors, one per probe point.
        n_attractors: number of distinct attractors N_A for normalization
            (ceiling: H <= log N_A). Defaults to the max observed support.
        method: entropy estimator, see compute_basin_entropy.
    """
    hs = np.array([compute_basin_entropy(c, method=method) for c in per_point_counts])
    pooled = np.sum([np.asarray(c, dtype=np.float64) for c in per_point_counts], axis=0)
    if n_attractors is None:
        # Observed support; a genuine single-attractor system stays K=1
        # (H must be 0 and normalized entropy is defined as 0), instead of
        # being silently promoted to a two-phase system (v31.0 behavior).
        n_attractors = max(1, int((pooled > 0).sum()))
    log_na = np.log(n_attractors) if n_attractors > 1 else 1.0
    return {
        "h_mean": float(hs.mean()) if len(hs) else 0.0,
        "h_max": float(hs.max()) if len(hs) else 0.0,
        "h_std": float(hs.std()) if len(hs) else 0.0,
        "h_mean_normalized": float(hs.mean() / log_na) if len(hs) else 0.0,
        "h_max_normalized": float(hs.max() / log_na) if len(hs) else 0.0,
        "n_attractors": int(n_attractors),
        "log_n_attractors": float(log_na),
        "n_probe_points": len(hs),
        "per_point_h": hs.tolist(),
        "pooled_counts": pooled.tolist(),
        "pooled_entropy_DO_NOT_REPORT_AS_H_MEAN": float(
            compute_basin_entropy(pooled, method=method)),
        "independence_plateau_pooled": independence_plateau(pooled),
        "estimator": method,
    }


def compute_kl_from_uniform(phase_counts: np.ndarray, eps: float = 1e-10) -> float:
    """
    Compute KL divergence from uniform distribution.
    D_KL(p || uniform) = log(K) - H(p)
    
    Lower = closer to uniform = at WSB.
    """
    counts = np.array(phase_counts, dtype=np.float64)
    K = len(counts)
    
    if K <= 1:
        return 0.0
    
    h_basin = compute_basin_entropy(counts, eps)
    h_max = np.log(K)
    
    return float(h_max - h_basin)


def max_entropy(K: int) -> float:
    """Maximum entropy for K phases = log(K)."""
    return np.log(K) if K > 1 else 0.0


def normalized_entropy(phase_counts: np.ndarray, eps: float = 1e-10) -> float:
    """Normalized entropy H/H_max in [0, 1]."""
    K = len(phase_counts)
    if K <= 1:
        return 0.0
    
    h = compute_basin_entropy(phase_counts, eps)
    h_max = max_entropy(K)
    
    return float(h / h_max) if h_max > 0 else 0.0


def compute_phase_probabilities(phase_counts: np.ndarray) -> np.ndarray:
    """Convert counts to probabilities. Zero total returns NaNs: "no
    observations" must not be silently converted into "maximum uncertainty"
    (v30 returned the uniform distribution here)."""
    counts = np.array(phase_counts, dtype=np.float64)
    total = counts.sum()
    return counts / total if total > 0 else np.full_like(counts, np.nan)


def is_near_uniform(phase_counts: np.ndarray, threshold: float = 0.1) -> bool:
    """Check if distribution is near uniform (normalized entropy > 1 - threshold)."""
    return normalized_entropy(phase_counts) > (1 - threshold)


# =============================================================================
# DISTRIBUTION INVERSION ANALYSIS
# =============================================================================

@dataclass
class DistributionInversionResult:
    """Results from distribution inversion analysis."""
    low_h_phase_probs: np.ndarray
    high_h_phase_probs: np.ndarray
    uniform_probs: np.ndarray
    
    # KL divergences
    low_h_kl_from_uniform: float
    high_h_kl_from_uniform: float
    
    # Rare phase analysis
    rarest_phase_idx: int
    rarest_phase_low_h_prob: float
    rarest_phase_high_h_prob: float
    rare_phase_increase_factor: float
    
    # Statistical test
    chi2_low_h: float
    chi2_high_h: float
    pvalue_low_h: float
    pvalue_high_h: float
    rare_phase_abs_increase: float = 0.0
    rare_phase_log_odds_change: float = 0.0
    
    def to_dict(self) -> Dict:
        return {
            "low_h_phase_probs": self.low_h_phase_probs.tolist(),
            "high_h_phase_probs": self.high_h_phase_probs.tolist(),
            "uniform_probs": self.uniform_probs.tolist(),
            "low_h_kl_from_uniform": self.low_h_kl_from_uniform,
            "high_h_kl_from_uniform": self.high_h_kl_from_uniform,
            "rarest_phase_idx": self.rarest_phase_idx,
            "rarest_phase_low_h_prob": self.rarest_phase_low_h_prob,
            "rarest_phase_high_h_prob": self.rarest_phase_high_h_prob,
            "rare_phase_increase_factor": self.rare_phase_increase_factor,
            "rare_phase_abs_increase": self.rare_phase_abs_increase,
            "rare_phase_log_odds_change": self.rare_phase_log_odds_change,
            "chi2_low_h": self.chi2_low_h,
            "chi2_high_h": self.chi2_high_h,
            "pvalue_low_h": self.pvalue_low_h,
            "pvalue_high_h": self.pvalue_high_h,
        }


def analyze_distribution_inversion(
    h_basin_values: np.ndarray,
    phase_counts_list: List[np.ndarray],
    low_percentile: float = 25,
    high_percentile: float = 75
) -> DistributionInversionResult:
    """
    Analyze distribution inversion: rare phases become common at high H_basin.
    
    This is the KEY theoretical claim: at WSB, distribution approaches uniform.
    
    Args:
        h_basin_values: Array of H_basin values
        phase_counts_list: List of phase count arrays corresponding to each H_basin
        low_percentile: Percentile threshold for "low H" samples
        high_percentile: Percentile threshold for "high H" samples
    """
    h_values = np.array(h_basin_values)
    
    low_threshold = np.percentile(h_values, low_percentile)
    high_threshold = np.percentile(h_values, high_percentile)
    
    low_h_idx = np.where(h_values <= low_threshold)[0]
    high_h_idx = np.where(h_values >= high_threshold)[0]
    
    # Aggregate phase counts
    low_h_counts = np.sum([phase_counts_list[i] for i in low_h_idx], axis=0)
    high_h_counts = np.sum([phase_counts_list[i] for i in high_h_idx], axis=0)
    
    # Convert to probabilities
    low_h_probs = compute_phase_probabilities(low_h_counts)
    high_h_probs = compute_phase_probabilities(high_h_counts)
    
    K = len(low_h_probs)
    uniform_probs = np.ones(K) / K
    
    # KL divergences
    low_h_kl = compute_kl_from_uniform(low_h_counts)
    high_h_kl = compute_kl_from_uniform(high_h_counts)
    
    # Rarest phase under the low-H distribution, restricted to phases that
    # were observed at all (argmin over zero-probability phases plus a tiny
    # denominator produced meaningless ~1e8x "increases" in v30). Report the
    # absolute change and smoothed log-odds alongside the ratio.
    observed = (low_h_counts + high_h_counts) > 0
    if observed.any():
        cand = np.where(observed)[0]
        rarest_idx = cand[np.argmin(low_h_probs[cand])]
    else:
        rarest_idx = int(np.argmin(low_h_probs))
    rarest_low = float(low_h_probs[rarest_idx])
    rarest_high = float(high_h_probs[rarest_idx])
    increase_factor = rarest_high / (rarest_low + 1e-10)
    # +0.5 count smoothing for log odds (Haldane-Anscombe)
    n_low, n_high = low_h_counts.sum(), high_h_counts.sum()
    p_lo = (low_h_counts[rarest_idx] + 0.5) / (n_low + 1.0)
    p_hi = (high_h_counts[rarest_idx] + 0.5) / (n_high + 1.0)
    rare_abs_increase = rarest_high - rarest_low
    rare_log_odds_change = float(np.log(p_hi / (1 - p_hi)) - np.log(p_lo / (1 - p_lo)))
    
    # Chi-squared tests against uniform
    expected = np.ones(K) * low_h_counts.sum() / K
    chi2_low, p_low = stats.chisquare(low_h_counts, expected)
    
    expected_high = np.ones(K) * high_h_counts.sum() / K
    chi2_high, p_high = stats.chisquare(high_h_counts, expected_high)
    
    return DistributionInversionResult(
        low_h_phase_probs=low_h_probs,
        high_h_phase_probs=high_h_probs,
        uniform_probs=uniform_probs,
        low_h_kl_from_uniform=low_h_kl,
        high_h_kl_from_uniform=high_h_kl,
        rarest_phase_idx=int(rarest_idx),
        rarest_phase_low_h_prob=rarest_low,
        rarest_phase_high_h_prob=rarest_high,
        rare_phase_increase_factor=increase_factor,
        rare_phase_abs_increase=float(rare_abs_increase),
        rare_phase_log_odds_change=rare_log_odds_change,
        chi2_low_h=float(chi2_low),
        chi2_high_h=float(chi2_high),
        pvalue_low_h=float(p_low),
        pvalue_high_h=float(p_high),
    )


# =============================================================================
# STATISTICAL TESTS
# =============================================================================

class StatisticalTests:
    """Comprehensive statistical tests for WSB analysis."""
    
    @staticmethod
    def chi_squared_uniformity(
        phase_counts: np.ndarray,
        alpha: float = 0.05
    ) -> Dict[str, Any]:
        """Chi-squared test for uniform distribution."""
        counts = np.array(phase_counts)
        K = len(counts)
        total = counts.sum()
        
        if total == 0 or K <= 1:
            return {"statistic": 0, "p_value": 1.0, "is_uniform": True}
        
        expected = np.ones(K) * total / K
        statistic, p_value = stats.chisquare(counts, expected)
        
        return {
            "statistic": float(statistic),
            "p_value": float(p_value),
            "is_uniform": p_value > alpha,
            # Asymptotic chi-square requires adequate expected cell counts;
            # with many phases and few perturbations the p-value is invalid.
            "chi2_valid": bool(np.all(expected >= 5)),
            "expected_per_phase": float(total / K),
            "degrees_of_freedom": K - 1,
        }
    
    @staticmethod
    def correlation_test(
        x: np.ndarray,
        y: np.ndarray
    ) -> Dict[str, float]:
        """Compute Spearman and Pearson correlations with p-values."""
        x, y = np.array(x), np.array(y)
        
        # Remove NaN
        mask = ~(np.isnan(x) | np.isnan(y))
        x, y = x[mask], y[mask]
        
        if len(x) < 3:
            return {"spearman_r": 0, "spearman_p": 1, "pearson_r": 0, "pearson_p": 1, "degenerate": True}
        
        # Check for constant input
        if np.std(x) < 1e-10 or np.std(y) < 1e-10:
            return {"spearman_r": 0, "spearman_p": 1, "pearson_r": 0, "pearson_p": 1, "degenerate": True}
        
        spearman_r, spearman_p = stats.spearmanr(x, y)
        pearson_r, pearson_p = stats.pearsonr(x, y)
        
        return {
            "spearman_r": float(spearman_r) if not np.isnan(spearman_r) else 0,
            "spearman_p": float(spearman_p) if not np.isnan(spearman_p) else 1,
            "pearson_r": float(pearson_r) if not np.isnan(pearson_r) else 0,
            "pearson_p": float(pearson_p) if not np.isnan(pearson_p) else 1,
            "degenerate": False,
        }
    
    @staticmethod
    def bootstrap_confidence_interval(
        data: np.ndarray,
        statistic_fn: Callable = np.mean,
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95
    ) -> Dict[str, float]:
        """Bootstrap confidence interval."""
        data = np.array(data)
        n = len(data)
        
        if n == 0:
            return {"estimate": 0, "ci_lower": 0, "ci_upper": 0, "std_error": 0}
        
        rng = np.random.default_rng(12345)
        bootstrap_stats = []
        for _ in range(n_bootstrap):
            sample = rng.choice(data, size=n, replace=True)
            bootstrap_stats.append(statistic_fn(sample))
        
        bootstrap_stats = np.array(bootstrap_stats)
        
        alpha = 1 - confidence_level
        ci_lower = np.percentile(bootstrap_stats, alpha/2 * 100)
        ci_upper = np.percentile(bootstrap_stats, (1 - alpha/2) * 100)
        
        return {
            "estimate": float(statistic_fn(data)),
            "ci_lower": float(ci_lower),
            "ci_upper": float(ci_upper),
            "std_error": float(np.std(bootstrap_stats)),
        }
    
    @staticmethod
    def permutation_test(
        group1: np.ndarray,
        group2: np.ndarray,
        n_permutations: int = 10000,
        alternative: str = "two-sided"
    ) -> Dict[str, float]:
        """Permutation test for difference in means."""
        g1, g2 = np.array(group1), np.array(group2)
        observed_diff = np.mean(g1) - np.mean(g2)
        
        combined = np.concatenate([g1, g2])
        n1 = len(g1)
        
        rng = np.random.default_rng(12345)
        count = 0
        for _ in range(n_permutations):
            rng.shuffle(combined)
            perm_diff = np.mean(combined[:n1]) - np.mean(combined[n1:])
            
            if alternative == "two-sided":
                if abs(perm_diff) >= abs(observed_diff):
                    count += 1
            elif alternative == "greater":
                if perm_diff >= observed_diff:
                    count += 1
            else:  # less
                if perm_diff <= observed_diff:
                    count += 1
        
        p_value = (count + 1) / (n_permutations + 1)
        
        return {
            "observed_diff": float(observed_diff),
            "p_value": float(p_value),
            "n_permutations": n_permutations,
        }
    
    @staticmethod
    def effect_size_cohens_d(
        group1: np.ndarray,
        group2: np.ndarray
    ) -> float:
        """Cohen's d effect size."""
        g1, g2 = np.array(group1), np.array(group2)
        
        n1, n2 = len(g1), len(g2)
        var1, var2 = np.var(g1, ddof=1), np.var(g2, ddof=1)
        
        pooled_std = np.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))
        
        if pooled_std == 0:
            return 0.0
        
        return float((np.mean(g1) - np.mean(g2)) / pooled_std)
    
    @staticmethod
    def roc_auc_analysis(
        y_true: np.ndarray,
        y_score: np.ndarray,
        n_bootstrap: int = 1000
    ) -> Dict[str, Any]:
        """Comprehensive ROC-AUC analysis with CI and full curve."""
        from sklearn.metrics import roc_auc_score, roc_curve, precision_recall_curve, average_precision_score
        
        y_true = np.array(y_true)
        y_score = np.array(y_score)
        
        # Handle edge cases - constant target or constant scores
        if len(np.unique(y_true)) < 2 or np.std(y_score) < 1e-10:
            prevalence = float(np.mean(y_true)) if len(y_true) else 0.5
            return {
                "roc_auc": 0.5,
                "roc_auc_ci_lower": 0.5,
                "roc_auc_ci_upper": 0.5,
                "pr_auc": prevalence,  # PR baseline is prevalence, not 0.5
                "fpr": [0, 1],
                "tpr": [0, 1],
                "thresholds": [1, 0],
                "degenerate": True,
            }
        
        # ROC curve
        fpr, tpr, thresholds = roc_curve(y_true, y_score)
        roc_auc = roc_auc_score(y_true, y_score)
        
        # PR curve
        precision, recall, _ = precision_recall_curve(y_true, y_score)
        pr_auc = average_precision_score(y_true, y_score)
        
        # Bootstrap CI for AUC (seeded generator: reproducible, independent of global state)
        n = len(y_true)
        rng = np.random.default_rng(12345)
        bootstrap_aucs = []
        for _ in range(n_bootstrap):
            idx = rng.choice(n, size=n, replace=True)
            if len(np.unique(y_true[idx])) < 2:
                continue
            try:
                bootstrap_aucs.append(roc_auc_score(y_true[idx], y_score[idx]))
            except Exception:
                continue
        
        if len(bootstrap_aucs) > 0:
            ci_lower = np.percentile(bootstrap_aucs, 2.5)
            ci_upper = np.percentile(bootstrap_aucs, 97.5)
        else:
            ci_lower = ci_upper = roc_auc
        
        # Optimal threshold (Youden's J)
        j_scores = tpr - fpr
        optimal_idx = np.argmax(j_scores)
        optimal_threshold = thresholds[optimal_idx]
        
        return {
            "roc_auc": float(roc_auc),
            "roc_auc_ci_lower": float(ci_lower),
            "roc_auc_ci_upper": float(ci_upper),
            "pr_auc": float(pr_auc),
            "optimal_threshold": float(optimal_threshold),
            "fpr": fpr.tolist(),
            "tpr": tpr.tolist(),
            "thresholds": thresholds.tolist(),
            "precision": precision.tolist(),
            "recall": recall.tolist(),
        }
    
    @staticmethod
    def lead_time_analysis(
        h_basin_series: np.ndarray,
        event_times: np.ndarray,
        checkpoint_steps: np.ndarray,
        threshold_percentile: float = 90,
        lookback_steps: int = 20000,
    ) -> Dict[str, Any]:
        """
        Lead time between H_basin warnings and events, WITHOUT future leakage:
        the warning threshold is fit on the PREFIX of the H series strictly
        before the first event (a threshold computed from the full trajectory,
        as in v30, is retrospective and cannot be claimed as early warning).
        Uses ACTUAL checkpoint step numbers (PPO checkpoints land after
        buffer boundaries, not at exact nominal intervals).

        Args:
            h_basin_series: H value per checkpoint.
            event_times: event step numbers (env steps).
            checkpoint_steps: step number of each checkpoint (same length as
                h_basin_series).
            threshold_percentile: percentile of the PRE-EVENT prefix used as
                the warning threshold.
            lookback_steps: how far before an event (in env steps) a warning
                counts as predicting it.
        """
        h_values = np.asarray(h_basin_series, dtype=float)
        steps = np.asarray(checkpoint_steps)
        events = np.sort(np.asarray(event_times))
        if len(events) == 0 or len(h_values) == 0 or len(steps) != len(h_values):
            return {"n_events": int(len(events)), "n_detected": 0,
                    "detection_rate": 0.0, "mean_lead_time": 0.0,
                    "degenerate": True}

        prefix_mask = steps < events[0]
        if prefix_mask.sum() < 5:
            return {"n_events": int(len(events)), "n_detected": 0,
                    "detection_rate": 0.0, "mean_lead_time": 0.0,
                    "degenerate": True,
                    "reason": "fewer than 5 checkpoints before first event; "
                              "cannot fit a leakage-free threshold"}
        threshold = float(np.percentile(h_values[prefix_mask],
                                        threshold_percentile))
        warning_steps = steps[h_values >= threshold]

        lead_times = []
        detected = 0
        for ev in events:
            w = warning_steps[(warning_steps < ev)
                              & (warning_steps >= ev - lookback_steps)]
            if len(w) > 0:
                detected += 1
                lead_times.append(float(ev - w[0]))  # first warning in window
        lead_times = np.array(lead_times)
        return {
            "threshold": threshold,
            "threshold_fit_on_n_prefix_checkpoints": int(prefix_mask.sum()),
            "n_events": int(len(events)),
            "n_detected": int(detected),
            "detection_rate": detected / len(events),
            "mean_lead_time": float(lead_times.mean()) if len(lead_times) else 0.0,
            "std_lead_time": float(lead_times.std()) if len(lead_times) else 0.0,
            "min_lead_time": float(lead_times.min()) if len(lead_times) else 0.0,
            "max_lead_time": float(lead_times.max()) if len(lead_times) else 0.0,
            "lead_times": lead_times.tolist(),
        }

    @staticmethod
    def paired_permutation_test(
        group1: np.ndarray,
        group2: np.ndarray,
        n_permutations: int = 10000,
        alternative: str = "greater",
    ) -> Dict[str, float]:
        """
        Paired sign-flip permutation test on d_i = group1_i - group2_i
        (e.g. per-seed reductions under two arms sharing the same baseline).
        Exact enumeration of all 2^n sign patterns when n <= 20; Monte Carlo
        otherwise. NOTE: with n pairs the smallest attainable one-sided
        p-value is 1/2^n (n=3 -> 0.125), which is reported so small-n runs
        cannot be over-claimed.
        """
        d = np.asarray(group1, dtype=float) - np.asarray(group2, dtype=float)
        n = len(d)
        if n == 0:
            return {"observed_mean_diff": 0.0, "p_value": 1.0, "n_pairs": 0}
        obs = d.mean()
        if n <= 20:
            from itertools import product
            count, total = 0, 0
            for signs in product((1.0, -1.0), repeat=n):
                m = (d * np.array(signs)).mean()
                total += 1
                if alternative == "greater":
                    count += (m >= obs - 1e-15)
                elif alternative == "less":
                    count += (m <= obs + 1e-15)
                else:
                    count += (abs(m) >= abs(obs) - 1e-15)
            p = count / total
            exact = True
        else:
            rng = np.random.default_rng(12345)
            count = 0
            for _ in range(n_permutations):
                m = (d * rng.choice((1.0, -1.0), size=n)).mean()
                if alternative == "greater":
                    count += (m >= obs)
                elif alternative == "less":
                    count += (m <= obs)
                else:
                    count += (abs(m) >= abs(obs))
            p = (count + 1) / (n_permutations + 1)
            exact = False
        return {"observed_mean_diff": float(obs), "p_value": float(p),
                "n_pairs": int(n), "exact": bool(exact),
                "min_attainable_p": float(2.0 ** -n)}


# =============================================================================
# BASELINE COMPARISON UTILITIES
# =============================================================================

def compare_to_baselines(
    h_basin: np.ndarray,
    baselines: Dict[str, np.ndarray],
    target: np.ndarray,
    n_bootstrap: int = 1000
) -> Dict[str, Dict]:
    """
    Compare H_basin to baseline metrics for predicting target.
    
    Args:
        h_basin: H_basin values
        baselines: Dict of baseline metric arrays
        target: Binary target (e.g., attack success, collapse)
        n_bootstrap: Number of bootstrap samples
        
    Returns:
        Dict with comparison results for each metric
    """
    results = {}
    
    # H_basin performance
    h_roc = StatisticalTests.roc_auc_analysis(target, h_basin, n_bootstrap)
    results["h_basin"] = {
        "roc_auc": h_roc["roc_auc"],
        "roc_auc_ci": (h_roc["roc_auc_ci_lower"], h_roc["roc_auc_ci_upper"]),
        "pr_auc": h_roc["pr_auc"],
    }
    
    # Each baseline
    for name, values in baselines.items():
        if len(values) != len(target):
            continue
        
        roc = StatisticalTests.roc_auc_analysis(target, values, n_bootstrap)
        
        results[name] = {
            "roc_auc": roc["roc_auc"],
            "roc_auc_ci": (roc["roc_auc_ci_lower"], roc["roc_auc_ci_upper"]),
            "pr_auc": roc["pr_auc"],
            # AUC difference is the scale-free comparison; Cohen's d between
            # metrics in different units (v30) is not interpretable.
            "auc_diff_vs_h_basin": float(results["h_basin"]["roc_auc"]
                                         - roc["roc_auc"]),
        }
    
    # Rank metrics by AUC
    ranking = sorted(results.items(), key=lambda x: x[1]["roc_auc"], reverse=True)
    results["ranking"] = [name for name, _ in ranking]
    results["h_basin_rank"] = results["ranking"].index("h_basin") + 1
    
    return results


# =============================================================================
# AGGREGATION UTILITIES
# =============================================================================

def aggregate_seed_results(
    seed_results: List[Dict],
    keys_to_aggregate: List[str],
    n_bootstrap: int = 1000
) -> Dict[str, Any]:
    """
    Aggregate results across seeds with bootstrap CIs.
    
    Args:
        seed_results: List of result dicts from each seed
        keys_to_aggregate: Keys to compute statistics for
        n_bootstrap: Bootstrap samples for CI
    """
    aggregated = {
        "n_seeds": len(seed_results),
    }
    
    for key in keys_to_aggregate:
        values = []
        for r in seed_results:
            if key in r and r[key] is not None:
                values.append(r[key])
        
        if len(values) == 0:
            continue
        
        values = np.array(values)
        
        # Basic stats
        aggregated[f"{key}_mean"] = float(np.mean(values))
        aggregated[f"{key}_std"] = float(np.std(values))
        aggregated[f"{key}_min"] = float(np.min(values))
        aggregated[f"{key}_max"] = float(np.max(values))
        
        # Bootstrap CI
        if len(values) >= 3:
            ci = StatisticalTests.bootstrap_confidence_interval(
                values, np.mean, n_bootstrap
            )
            aggregated[f"{key}_ci_lower"] = ci["ci_lower"]
            aggregated[f"{key}_ci_upper"] = ci["ci_upper"]
    
    return aggregated
