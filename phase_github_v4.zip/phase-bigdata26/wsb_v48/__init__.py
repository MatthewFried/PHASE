"""
WSB Framework - Witnessing State Boundary Analysis
====================================================

A unified framework for analyzing phase boundaries in dynamical systems.

Modules:
- config: Configuration dataclasses
- core: Basin entropy computation and statistics
- classifiers: Phase classifiers for all domains
- rl: Option A - RL early warning
- adversarial: Option B - Adversarial robustness
- games: Option C - Game theory dynamics
- ablations: Toy systems and ablation studies
- compression: Compression tolerance experiments
- utils: Logging and I/O utilities
"""

from .config import (
    WSBConfig,
    OptionAConfig,
    OptionBConfig,
    OptionCConfig,
    ToySystemConfig,
    CompressionConfig,
    AblationConfig,
    FullExperimentConfig,
)

from .core import (
    compute_basin_entropy,
    compute_kl_from_uniform,
    max_entropy,
    normalized_entropy,
    independence_plateau,
    local_entropy_stats,
    is_near_uniform,
    analyze_distribution_inversion,
    StatisticalTests,
    aggregate_seed_results,
)
from .data import download_and_verify, assert_manifest, DATASET_STATS
from .calibration import run_all_calibration

from .classifiers import (
    PhaseClassifier,
    ThresholdClassifier,
    QuantileClassifier,
    BinarySuccessClassifier,
    PredictedClassClassifier,
    NearestNashClassifier,
    get_phase_classifier,
)

from .rl import run_option_a
from .adversarial import run_option_b
from .games import run_option_c
from .ablations import run_toy_system, run_ablations
from .compression import run_compression

from .utils import (
    setup_logger,
    ResultsTracker,
    save_results,
    load_results,
)

__version__ = "48.0.0"
__author__ = "WSB Framework"

__all__ = [
    # Config
    "WSBConfig", "OptionAConfig", "OptionBConfig", "OptionCConfig",
    "ToySystemConfig", "CompressionConfig", "AblationConfig", "FullExperimentConfig",
    # Core
    "compute_basin_entropy", "compute_kl_from_uniform", "max_entropy",
    "normalized_entropy", "independence_plateau", "local_entropy_stats",
    "is_near_uniform", "analyze_distribution_inversion",
    "StatisticalTests", "aggregate_seed_results",
    # Classifiers
    "PhaseClassifier", "ThresholdClassifier", "QuantileClassifier",
    "BinarySuccessClassifier", "PredictedClassClassifier", "NearestNashClassifier",
    "get_phase_classifier",
    # Runners
    "run_option_a", "run_option_b", "run_option_c",
    "run_toy_system", "run_ablations", "run_compression", "run_all_calibration",
    # Data stage
    "download_and_verify", "assert_manifest", "DATASET_STATS",
    # Utils
    "setup_logger", "ResultsTracker", "save_results", "load_results",
]
