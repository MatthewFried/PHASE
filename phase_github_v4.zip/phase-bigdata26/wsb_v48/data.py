"""
WSB Framework - Data Stage (STAGE 0 - RUN FIRST)
=================================================
Downloads and verifies all datasets before any experiment runs.
Writes a manifest JSON so downstream stages can assert data integrity.

All tensors downstream are in [0, 1] pixel space (ToTensor only).
Normalization is applied INSIDE the model via NormalizedModel so that
attack epsilons, PHASE perturbations, and clamp(0, 1) are all in the
same, correct domain. Do NOT add transforms.Normalize to these datasets.
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np

# Per-dataset normalization constants (applied inside the model, not the data).
DATASET_STATS: Dict[str, Tuple[Tuple[float, ...], Tuple[float, ...]]] = {
    "mnist":    ((0.1307,), (0.3081,)),
    "cifar10":  ((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)),
    "cifar100": ((0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761)),
    "svhn":     ((0.4377, 0.4438, 0.4728), (0.1980, 0.2010, 0.1970)),
}

EXPECTED_COUNTS = {
    "mnist":    {"train": 60000, "test": 10000, "n_classes": 10, "channels": 1, "size": 28},
    "cifar10":  {"train": 50000, "test": 10000, "n_classes": 10, "channels": 3, "size": 32},
    "cifar100": {"train": 50000, "test": 10000, "n_classes": 100, "channels": 3, "size": 32},
    "svhn":     {"train": 73257, "test": 26032, "n_classes": 10, "channels": 3, "size": 32},
}


def _get_raw(name: str, data_dir: str, train: bool):
    from torchvision import datasets, transforms
    t = transforms.ToTensor()
    if name == "mnist":
        return datasets.MNIST(data_dir, train=train, download=True, transform=t)
    if name == "cifar10":
        return datasets.CIFAR10(data_dir, train=train, download=True, transform=t)
    if name == "cifar100":
        return datasets.CIFAR100(data_dir, train=train, download=True, transform=t)
    if name == "svhn":
        return datasets.SVHN(data_dir, split="train" if train else "test",
                             download=True, transform=t)
    raise ValueError(f"Unknown dataset: {name}")


def _verify_split(ds, name: str, split: str, exp: Dict, logger) -> Dict:
    """Verify sample count, tensor shape, value range, label range, class coverage."""
    n = len(ds)
    ok = True
    issues: List[str] = []

    if n != exp[split]:
        ok = False
        issues.append(f"count {n} != expected {exp[split]}")

    # Probe a deterministic subset of samples.
    rng = np.random.default_rng(0)
    probe_idx = rng.choice(n, size=min(256, n), replace=False)
    labels_seen = set()
    vmin, vmax = np.inf, -np.inf
    shape_ok = True
    for i in probe_idx:
        x, y = ds[int(i)]
        labels_seen.add(int(y))
        vmin = min(vmin, float(x.min()))
        vmax = max(vmax, float(x.max()))
        if tuple(x.shape) != (exp["channels"], exp["size"], exp["size"]):
            shape_ok = False
    if not shape_ok:
        ok = False
        issues.append(f"shape mismatch (expected {(exp['channels'], exp['size'], exp['size'])})")
    if vmin < -1e-6 or vmax > 1 + 1e-6:
        ok = False
        issues.append(f"values outside [0,1]: [{vmin:.4f}, {vmax:.4f}] "
                      f"(a Normalize transform leaked into the dataset)")
    bad_labels = [l for l in labels_seen if l < 0 or l >= exp["n_classes"]]
    if bad_labels:
        ok = False
        issues.append(f"labels out of range: {sorted(bad_labels)[:5]}")

    rec = {"n_samples": n, "value_min": vmin, "value_max": vmax,
           "n_labels_seen_in_probe": len(labels_seen), "ok": ok, "issues": issues}
    status = "OK" if ok else "FAIL"
    logger.info(f"  [{status}] {name}/{split}: n={n}, values=[{vmin:.4f},{vmax:.4f}], "
                f"labels-in-probe={len(labels_seen)}"
                + (f"  ISSUES: {issues}" if issues else ""))
    return rec


def download_and_verify(datasets_list: List[str], data_dir: str, output_dir: str,
                        logger) -> Dict:
    """
    Download all requested datasets (train AND test splits), verify integrity,
    write manifest to {output_dir}/data_manifest.json.

    Returns manifest dict. Raises RuntimeError if any dataset fails verification,
    so no downstream stage can run on bad data.
    """
    Path(data_dir).mkdir(parents=True, exist_ok=True)
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    logger.info("=" * 60)
    logger.info("STAGE 0: DATA DOWNLOAD + VERIFICATION")
    logger.info("=" * 60)

    manifest: Dict = {"data_dir": str(Path(data_dir).resolve()), "datasets": {}}
    all_ok = True

    for name in datasets_list:
        name = name.strip().lower()
        if name not in EXPECTED_COUNTS:
            logger.warning(f"  Skipping unknown dataset '{name}'")
            continue
        exp = EXPECTED_COUNTS[name]
        logger.info(f"Dataset: {name}")
        rec = {"expected": exp, "mean": DATASET_STATS[name][0], "std": DATASET_STATS[name][1]}
        for split, train in (("train", True), ("test", False)):
            ds = _get_raw(name, data_dir, train)
            rec[split] = _verify_split(ds, name, split, exp, logger)
            all_ok = all_ok and rec[split]["ok"]
        manifest["datasets"][name] = rec

    manifest["all_ok"] = all_ok
    manifest_path = Path(output_dir) / "data_manifest.json"
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    logger.info(f"Manifest written: {manifest_path}")

    if not all_ok:
        raise RuntimeError("Data verification FAILED - see manifest and log. "
                           "Refusing to run experiments on unverified data.")
    logger.info("All datasets verified. Safe to proceed.")
    return manifest


def assert_manifest(output_dir: str, dataset: str, data_dir: str = None):
    """Downstream stages call this to require that stage 0 ran and passed FOR
    THE SAME resolved data directory the stage will read - otherwise path A
    can be verified while the run reads path B, voiding the guarantee."""
    p = Path(output_dir) / "data_manifest.json"
    if not p.exists():
        raise RuntimeError(f"No data manifest at {p}. Run the 'download' stage first.")
    m = json.loads(p.read_text())
    if not m.get("all_ok"):
        raise RuntimeError("Data manifest indicates failed verification.")
    if dataset not in m.get("datasets", {}):
        raise RuntimeError(f"Dataset '{dataset}' not in verified manifest. "
                           f"Re-run download with --datasets {dataset}")
    if data_dir is not None:
        recorded = m.get("data_dir")
        if recorded is not None and \
                os.path.realpath(recorded) != os.path.realpath(data_dir):
            raise RuntimeError(
                f"Manifest verified data_dir='{recorded}' but this run uses "
                f"data_dir='{data_dir}'. Re-run download for this path or "
                f"point --data_dir at the verified one.")
