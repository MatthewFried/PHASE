"""
WSB Framework - Toy System & Ablation Module
==============================================
Analytical validation and comprehensive ablation studies.
"""

import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass, asdict

from .config import ToySystemConfig, AblationConfig, OptionAConfig, OptionBConfig, OptionCConfig
from .core import compute_basin_entropy


# =============================================================================
# TOY SYSTEM: Analytical Validation
# =============================================================================

@dataclass
class ToySystemResult:
    x_values: List[float]
    h_basin_values: List[float]
    theoretical_h_values: List[float]
    wsb_location_empirical: float
    wsb_location_theoretical: float
    wsb_error: float
    max_h_basin: float
    theoretical_max_h: float
    h_at_wsb: float
    
    def to_dict(self):
        return asdict(self)


class DoubleWellSystem:
    """
    Double-well potential: V(x) = (x^2 - 1)^2
    WSB exactly at x = 0 where H_basin = log(2)
    """
    
    def __init__(self, config: ToySystemConfig):
        self.config = config
        self.wsb_location = 0.0
        self.n_basins = 2
        self.theoretical_max_h = np.log(2)
    
    def potential(self, x: float) -> float:
        return (x**2 - 1)**2
    
    def gradient(self, x: float) -> float:
        return 4 * x * (x**2 - 1)
    
    def integrate(self, x0: float, t_max: float, dt: float) -> float:
        x = x0
        for _ in range(int(t_max / dt)):
            x = x - dt * self.gradient(x)
            if abs(x) > 2:
                break
        return x
    
    def classify_basin(self, x_final: float) -> int:
        return 0 if x_final < 0 else 1
    
    def compute_h_basin(self, x0: float, n_perturbations: int = None) -> Tuple[float, np.ndarray]:
        n_pert = n_perturbations or self.config.n_perturbations
        counts = np.zeros(self.n_basins)
        for _ in range(n_pert):
            pert = np.random.uniform(-self.config.epsilon, self.config.epsilon)
            x_pert = x0 + pert
            x_final = self.integrate(x_pert, self.config.integration_time, self.config.dt)
            basin = self.classify_basin(x_final)
            counts[basin] += 1
        return compute_basin_entropy(counts), counts
    
    def theoretical_h_basin(self, x0: float) -> float:
        """
        EXACT ground truth for uniform perturbations u ~ U[-eps, eps] and the
        basin boundary at 0 (the previous logistic expression was an ad-hoc
        approximation, defeating the purpose of an exact sanity check):
            P(x0 + u > 0) = clip((x0 + eps) / (2 eps), 0, 1)
        and H is the binary entropy of that probability.
        """
        eps = self.config.epsilon
        p_right = float(np.clip((x0 + eps) / (2.0 * eps), 0.0, 1.0))
        p_left = 1.0 - p_right
        if p_left < 1e-12 or p_right < 1e-12:
            return 0.0
        return -(p_left * np.log(p_left) + p_right * np.log(p_right))
    
    def run_validation(self) -> ToySystemResult:
        x_values = np.linspace(self.config.x_range[0], self.config.x_range[1], self.config.n_grid_points)
        h_basin_values, theoretical_h_values = [], []
        for x in x_values:
            h, _ = self.compute_h_basin(x)
            h_basin_values.append(h)
            theoretical_h_values.append(self.theoretical_h_basin(x))
        h_basin_values = np.array(h_basin_values)
        theoretical_h_values = np.array(theoretical_h_values)
        wsb_idx = np.argmax(h_basin_values)
        wsb_empirical = float(x_values[wsb_idx])
        return ToySystemResult(
            x_values=x_values.tolist(), h_basin_values=h_basin_values.tolist(),
            theoretical_h_values=theoretical_h_values.tolist(),
            wsb_location_empirical=wsb_empirical, wsb_location_theoretical=self.wsb_location,
            wsb_error=abs(wsb_empirical - self.wsb_location),
            max_h_basin=float(np.max(h_basin_values)), theoretical_max_h=self.theoretical_max_h,
            h_at_wsb=float(h_basin_values[wsb_idx]),
        )


def run_toy_system(config: ToySystemConfig, logger=None) -> Dict:
    if getattr(config, "system_type", "double_well") != "double_well":
        raise NotImplementedError(
            f"system_type='{config.system_type}' is advertised but not "
            "implemented; only 'double_well' exists. Refusing to silently "
            "substitute the double well.")
    if logger:
        logger.info("=" * 60 + "\nTOY SYSTEM: Analytical Validation\n" + "=" * 60)
    system = DoubleWellSystem(config)
    result = system.run_validation()
    if logger:
        logger.info(f"Double Well Validation:")
        logger.info(f"  Theoretical WSB: x = {result.wsb_location_theoretical}")
        logger.info(f"  Empirical WSB:   x = {result.wsb_location_empirical:.4f}")
        logger.info(f"  Error: {result.wsb_error:.4f}")
        logger.info(f"  Theoretical max H: {result.theoretical_max_h:.4f} (log 2)")
        logger.info(f"  Empirical max H:   {result.max_h_basin:.4f}")
    return result.to_dict()


# =============================================================================
# ABLATION STUDIES
# =============================================================================

class AblationStudy:
    def __init__(self, config: AblationConfig, logger=None):
        self.config, self.logger = config, logger
    
    def run_epsilon_ablation(self, domain: str = "adversarial") -> Dict:
        if self.logger:
            self.logger.info(f"Running epsilon ablation for {domain}")
        results = {"epsilon_values": [], "metrics": []}
        for eps in self.config.epsilon_values:
            if self.logger:
                self.logger.info(f"  epsilon = {eps}")
            if domain == "adversarial":
                cfg = OptionBConfig(epsilon=eps, wsb_epsilon=eps, n_seeds=self.config.ablation_n_seeds, n_test_samples=200, train_epochs=20)
                from .adversarial import run_option_b
                result = run_option_b(cfg)
            elif domain == "rl":
                cfg = OptionAConfig(epsilon=eps, n_seeds=self.config.ablation_n_seeds, total_timesteps=50000)
                from .rl import run_option_a
                result = run_option_a(cfg)
            else:
                cfg = OptionCConfig(epsilon=eps, n_seeds=self.config.ablation_n_seeds, param_sweep_steps=30)
                from .games import run_option_c
                result = run_option_c(cfg)
            results["epsilon_values"].append(eps)
            results["metrics"].append(result)
        return results
    
    def run_n_perturbations_ablation(self, domain: str = "adversarial") -> Dict:
        if self.logger:
            self.logger.info(f"Running n_perturbations ablation for {domain}")
        results = {"n_values": [], "metrics": [], "convergence": []}
        for n in self.config.n_perturbations_values:
            if self.logger:
                self.logger.info(f"  n_perturbations = {n}")
            if domain == "adversarial":
                cfg = OptionBConfig(n_perturbations=n, n_seeds=self.config.ablation_n_seeds, n_test_samples=200, train_epochs=20)
                from .adversarial import run_option_b
                result = run_option_b(cfg)
            elif domain == "rl":
                cfg = OptionAConfig(n_perturbations=n, n_seeds=self.config.ablation_n_seeds, total_timesteps=50000)
                from .rl import run_option_a
                result = run_option_a(cfg)
            else:
                cfg = OptionCConfig(n_perturbations=n, n_seeds=self.config.ablation_n_seeds, param_sweep_steps=30)
                from .games import run_option_c
                result = run_option_c(cfg)
            results["n_values"].append(n)
            results["metrics"].append(result)
        if len(results["metrics"]) > 1:
            h_values = [m.get("h_basin_mean_mean", 0) for m in results["metrics"]]
            final_h = h_values[-1]
            for i, h in enumerate(h_values):
                results["convergence"].append({"n": results["n_values"][i], "h_basin": h, "error_from_final": abs(h - final_h)})
        return results
    
    def run_classifier_ablation(self, domain: str = "adversarial") -> Dict:
        if self.logger:
            self.logger.info(f"Running classifier ablation for {domain}")
        if domain == "adversarial":
            classifiers = self.config.adv_classifiers
        elif domain == "rl":
            classifiers = self.config.rl_classifiers
        else:
            classifiers = self.config.game_classifiers
        results = {"classifiers": [], "metrics": []}
        for clf_name in classifiers:
            if self.logger:
                self.logger.info(f"  classifier = {clf_name}")
            if domain == "adversarial":
                cfg = OptionBConfig(adv_phase_classifier=clf_name, n_seeds=self.config.ablation_n_seeds, n_test_samples=200, train_epochs=20)
                from .adversarial import run_option_b
                result = run_option_b(cfg)
            elif domain == "rl":
                cfg = OptionAConfig(rl_phase_classifier=clf_name, n_seeds=self.config.ablation_n_seeds, total_timesteps=50000)
                from .rl import run_option_a
                result = run_option_a(cfg)
            else:
                cfg = OptionCConfig(game_phase_classifier=clf_name, n_seeds=self.config.ablation_n_seeds, param_sweep_steps=30)
                from .games import run_option_c
                result = run_option_c(cfg)
            results["classifiers"].append(clf_name)
            results["metrics"].append(result)
        return results
    
    def run_full_ablation_suite(self) -> Dict:
        if self.logger:
            self.logger.info("=" * 60 + "\nFULL ABLATION SUITE\n" + "=" * 60)
        all_results = {}
        for domain in ["adversarial", "rl", "games"]:
            if self.logger:
                self.logger.info(f"\n--- Domain: {domain} ---")
            all_results[f"{domain}_epsilon"] = self.run_epsilon_ablation(domain)
            all_results[f"{domain}_n_perturbations"] = self.run_n_perturbations_ablation(domain)
            all_results[f"{domain}_classifier"] = self.run_classifier_ablation(domain)
        return all_results


def run_ablations(config: AblationConfig, logger=None) -> Dict:
    study = AblationStudy(config, logger)
    return study.run_full_ablation_suite()


# Convergence analysis
def analyze_h_basin_convergence(compute_fn, n_values=[5, 10, 20, 50, 100, 200, 500], n_repeats=10, **kwargs) -> Dict:
    results = {"n_values": n_values, "mean": [], "std": [], "error_from_max": []}
    all_h = {}
    for n in n_values:
        h_values = []
        for _ in range(n_repeats):
            h, _ = compute_fn(n_perturbations=n, **kwargs)
            h_values.append(h)
        all_h[n] = h_values
        results["mean"].append(float(np.mean(h_values)))
        results["std"].append(float(np.std(h_values)))
    reference = np.mean(all_h[max(n_values)])
    results["error_from_max"] = [abs(m - reference) for m in results["mean"]]
    for i, err in enumerate(results["error_from_max"]):
        if err < 0.01:
            results["recommended_n"] = n_values[i]
            break
    else:
        results["recommended_n"] = max(n_values)
    return results


# Finite-sample bounds
def hoeffding_bound_for_entropy(n_samples: int, K: int, delta: float = 0.05) -> float:
    return np.sqrt(np.log(2 * K / delta) / (2 * n_samples)) * np.log(K)

def required_samples_for_error(K: int, epsilon: float, delta: float = 0.05) -> int:
    log_term = np.log(2 * K / delta)
    log_K = np.log(K)
    n = log_term * (log_K / epsilon) ** 2 / 2
    return int(np.ceil(n))
