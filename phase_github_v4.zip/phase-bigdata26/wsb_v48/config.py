"""
WSB Framework - Configuration Module
=====================================
Complete configuration for bulletproof experiments.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Tuple, Optional, Dict, Any


@dataclass
class WSBConfig:
    """Base WSB configuration."""
    
    # Core WSB parameters
    epsilon: float = 0.1
    n_perturbations: int = 50
    n_probe_points: int = 100
    
    # Statistical rigor
    n_seeds: int = 10
    n_bootstrap: int = 1000
    confidence_level: float = 0.95
    
    # Device
    device: str = "cuda"
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class OptionAConfig(WSBConfig):
    """Option A: RL Early Warning Configuration."""
    
    # Environment
    env_name: str = "CartPole-v1"
    
    # Algorithm
    algo: str = "ppo"  # ppo, dqn
    
    # Training
    total_timesteps: int = 100000
    checkpoint_interval: int = 2000  # Compute H_basin every N steps
    
    # Network
    hidden_dim: int = 64
    n_hidden_layers: int = 2
    
    # PPO hyperparameters
    learning_rate: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_epsilon: float = 0.2
    entropy_coef: float = 0.01
    value_coef: float = 0.5
    max_grad_norm: float = 0.5
    ppo_epochs: int = 10
    batch_size: int = 64
    buffer_size: int = 2048
    normalize_advantage: bool = True
    
    # DQN hyperparameters
    dqn_buffer_size: int = 10000
    dqn_batch_size: int = 64
    dqn_target_update: int = 100
    dqn_epsilon_start: float = 1.0
    dqn_epsilon_end: float = 0.01
    dqn_epsilon_decay: int = 10000
    dqn_double: bool = True
    dqn_dueling: bool = False
    
    # WSB computation
    rollout_max_steps: int = 500
    # Headline WSB rollouts are deterministic-policy so measured entropy is
    # state-perturbation sensitivity, not action-sampling noise; the
    # per-checkpoint noise control quantifies the non-geometric floor.
    rollout_deterministic: bool = True
    compute_noise_control: bool = True
    
    # Phase classifier
    rl_phase_classifier: str = "binary_success"
    reward_threshold: float = 195.0  # CartPole success
    n_return_quantiles: int = 4
    
    # Collapse detection
    collapse_threshold: float = 0.5
    collapse_window: int = 20
    min_episodes_for_collapse: int = 50
    warning_threshold_percentile: float = 90
    
    # Baselines to compute
    compute_policy_entropy: bool = True
    compute_value_variance: bool = True
    compute_reward_variance: bool = True
    compute_td_error: bool = True
    
    # Output
    output_dir: str = "./wsb_results"
    save_trajectories: bool = True  # Save full H_basin trajectory
    save_per_checkpoint: bool = True  # Save detailed per-checkpoint data


@dataclass
class OptionBConfig(WSBConfig):
    """Option B: Adversarial Robustness Configuration."""
    
    # Dataset
    dataset: str = "cifar10"
    data_dir: str = "./data"
    
    # Model
    model_name: str = "cifar_cnn"
    
    # Training
    train_epochs: int = 100
    batch_size: int = 128
    learning_rate: float = 0.1
    momentum: float = 0.9
    weight_decay: float = 5e-4
    lr_schedule: str = "multistep"  # multistep, cosine
    lr_milestones: Tuple[int, ...] = (50, 75, 90)
    lr_gamma: float = 0.1
    
    # Adversarial training
    adversarial_training: str = "none"  # none, pgd, trades
    # Explicit seed list overrides range(n_seeds): rerun a collapsed seed
    # alone, or extend with fresh seeds without repeating the others.
    seed_list: Optional[List[int]] = None
    
    # Attack parameters (aligned train/eval)
    attack_epsilon: float = 8/255  # Standard CIFAR epsilon
    attack_alpha: float = 2/255
    attack_steps: int = 10
    
    # Evaluation attack (stronger)
    eval_attack_steps: int = 20
    eval_attack_restarts: int = 1
    
    # TRADES
    trades_beta: float = 6.0
    
    # WSB computation
    n_test_samples: int = 1000
    wsb_epsilon: float = 0.1  # Perturbation for H_basin
    
    # Phase classifiers
    adv_phase_classifier: str = "predicted_class"
    n_confidence_buckets: int = 5
    n_entropy_buckets: int = 5
    
    # Baselines to compute
    compute_gradient_norm: bool = True
    compute_margin: bool = True
    compute_confidence: bool = True
    compute_entropy: bool = True
    compute_local_lipschitz: bool = True
    lipschitz_n_samples: int = 50
    
    # Output
    output_dir: str = "./wsb_results"
    save_per_sample: bool = True  # Save per-sample analysis
    save_roc_data: bool = True  # Save full ROC curve data


@dataclass  
class OptionCConfig(WSBConfig):
    """Option C: Game Theory Configuration."""
    
    # Game
    game_type: str = "stag_hunt"
    
    # Game parameters
    stag_payoff: float = 4.0
    hare_payoff: float = 3.0
    temptation: float = 3.0
    bos_high: float = 3.0
    bos_low: float = 1.0
    pd_reward: float = 3.0
    pd_temptation: float = 5.0
    pd_sucker: float = 0.0
    pd_punishment: float = 1.0
    
    # Dynamics
    dynamics: str = "replicator"
    dynamics_lr: float = 0.1
    dynamics_steps: int = 1000
    convergence_threshold: float = 1e-6
    
    # Replicator specific
    replicator_dt: float = 0.1
    replicator_mutation: float = 0.0
    
    # Fictitious play
    fp_initial_weight: float = 10.0
    
    # Logit response
    logit_temperature: float = 1.0
    logit_temperature_decay: float = 0.0
    
    # Regret matching
    rm_plus: bool = True
    
    # Parameter sweep
    param_sweep_var: str = "stag_payoff"
    param_sweep_range: Tuple[float, float] = (1.0, 6.0)
    param_sweep_steps: int = 50
    
    # 2D sweep
    param_sweep_2d: bool = False
    param_sweep_var_2: str = "temptation"
    param_sweep_range_2: Tuple[float, float] = (1.0, 6.0)
    param_sweep_steps_2: int = 30
    
    # Phase classifier
    game_phase_classifier: str = "nearest_nash"
    welfare_n_buckets: int = 4
    
    # Analytical validation
    compute_analytical_wsb: bool = True  # Compare to known boundary
    
    # Output
    output_dir: str = "./wsb_results"


@dataclass
class ToySystemConfig:
    """Toy system for analytical validation."""
    
    system_type: str = "double_well"  # double_well, saddle_node
    
    # Double well: V(x) = (x^2 - 1)^2
    # Known boundary at x = 0
    
    # Grid for evaluation
    x_range: Tuple[float, float] = (-2.0, 2.0)
    n_grid_points: int = 100
    
    # WSB parameters
    epsilon: float = 0.1
    n_perturbations: int = 100
    integration_time: float = 10.0
    dt: float = 0.01
    
    # Output
    output_dir: str = "./wsb_results"


@dataclass
class CompressionConfig:
    """Compression experiment configuration."""
    
    # Model to compress
    dataset: str = "cifar10"
    model_name: str = "cifar_cnn"
    pretrained_path: Optional[str] = None
    data_dir: str = "./data"
    
    # Training mode
    adversarial_training: str = "none"  # none, pgd, trades
    train_epochs: int = 50  # More epochs for adversarial training
    
    # Compression methods
    quantization_bits: List[int] = field(default_factory=lambda: [8, 6, 4, 2])
    pruning_ratios: List[float] = field(default_factory=lambda: [0.0, 0.3, 0.5, 0.7, 0.9])
    
    # Analysis
    n_test_samples: int = 1000
    n_low_h_samples: int = 200  # Samples with lowest H_basin
    n_high_h_samples: int = 200  # Samples with highest H_basin
    
    # WSB parameters
    epsilon: float = 0.1
    n_perturbations: int = 50
    
    # Output
    output_dir: str = "./wsb_results"


@dataclass
class AblationConfig:
    """Ablation study configuration."""
    
    # Parameters to ablate
    epsilon_values: List[float] = field(default_factory=lambda: [0.01, 0.05, 0.1, 0.2, 0.5])
    n_perturbations_values: List[int] = field(default_factory=lambda: [10, 25, 50, 100, 200])
    
    # Phase classifiers to compare
    rl_classifiers: List[str] = field(default_factory=lambda: [
        "binary_success", "return_quantile", "survival_time"
    ])
    adv_classifiers: List[str] = field(default_factory=lambda: [
        "predicted_class", "confidence_bucket", "entropy_bucket", "binary_correct"
    ])
    game_classifiers: List[str] = field(default_factory=lambda: [
        "nearest_nash", "action_profile", "equilibrium_type"
    ])
    
    # Estimation methods
    estimation_methods: List[str] = field(default_factory=lambda: [
        "grid", "hierarchical", "pso"
    ])
    
    # Seeds for ablation (fewer than main experiments)
    ablation_n_seeds: int = 3
    
    # Output
    output_dir: str = "./wsb_results"


@dataclass
class FullExperimentConfig:
    """Full experiment suite configuration."""
    
    # What to run
    run_option_a: bool = True
    run_option_b: bool = True
    run_option_c: bool = True
    run_toy_system: bool = True
    run_compression: bool = True
    run_ablations: bool = True
    
    # Option A environments
    option_a_envs: List[str] = field(default_factory=lambda: [
        "CartPole-v1", "Acrobot-v1", "MountainCar-v0"
    ])
    option_a_algos: List[str] = field(default_factory=lambda: ["ppo"])
    
    # Option B datasets
    option_b_datasets: List[str] = field(default_factory=lambda: [
        "mnist", "cifar10", "cifar100", "svhn"
    ])
    option_b_training: List[str] = field(default_factory=lambda: [
        "none", "pgd", "trades"
    ])
    
    # Option C games
    option_c_games: List[str] = field(default_factory=lambda: [
        "stag_hunt", "battle_of_sexes", "prisoners_dilemma"
    ])
    option_c_dynamics: List[str] = field(default_factory=lambda: [
        "replicator", "fictitious_play", "logit_response"
    ])
    
    # Global settings
    n_seeds: int = 10
    output_dir: str = "./wsb_results"
    
    # Experiment naming
    experiment_name: str = "wsb_full_experiment"


# Environment-specific defaults
ENV_DEFAULTS = {
    "CartPole-v1": {
        "reward_threshold": 195.0,
        "total_timesteps": 100000,
        "checkpoint_interval": 2000,
    },
    "Acrobot-v1": {
        "reward_threshold": -100.0,
        "total_timesteps": 100000,
        "checkpoint_interval": 2000,
    },
    "MountainCar-v0": {
        "reward_threshold": -110.0,
        "total_timesteps": 200000,
        "checkpoint_interval": 5000,
    },
    "LunarLander-v3": {
        "reward_threshold": 200.0,
        "total_timesteps": 200000,
        "checkpoint_interval": 5000,
    },
}

# Dataset-specific defaults
DATASET_DEFAULTS = {
    "mnist": {
        "model_name": "simple_cnn",
        "train_epochs": 20,
        "attack_epsilon": 0.3,
        "attack_alpha": 0.01,
        "lr_milestones": (10, 15),
    },
    "cifar10": {
        "model_name": "cifar_cnn",
        "train_epochs": 100,
        "attack_epsilon": 8/255,
        "attack_alpha": 2/255,
        "lr_milestones": (50, 75, 90),
    },
    "cifar100": {
        "model_name": "cifar_cnn",
        "train_epochs": 100,
        "attack_epsilon": 8/255,
        "attack_alpha": 2/255,
        "lr_milestones": (50, 75, 90),
    },
    "svhn": {
        "model_name": "cifar_cnn",
        "train_epochs": 50,
        "attack_epsilon": 8/255,
        "attack_alpha": 2/255,
        "lr_milestones": (25, 40),
    },
}

# =============================================================================
# CONFIG FACTORIES - the ONLY place environment/dataset defaults are applied.
# Precedence: base dataclass defaults -> env/dataset defaults -> explicit
# user overrides. Analyzers/trainers never mutate the config they receive
# (previously they overwrote explicit user settings after construction, so a
# CLI request like --train_epochs 5 could silently run 100 epochs).
# =============================================================================

def resolve_option_a_config(env_name: str = "CartPole-v1", **overrides) -> "OptionAConfig":
    merged = dict(ENV_DEFAULTS.get(env_name, {}))
    merged.update(overrides)          # user overrides win
    merged["env_name"] = env_name
    valid = {f for f in OptionAConfig.__dataclass_fields__}
    unknown = set(merged) - valid
    if unknown:
        raise ValueError(f"Unknown OptionAConfig fields: {sorted(unknown)}")
    return OptionAConfig(**merged)


def resolve_option_b_config(dataset: str = "cifar10", **overrides) -> "OptionBConfig":
    merged = dict(DATASET_DEFAULTS.get(dataset, {}))
    merged.update(overrides)          # user overrides win
    merged["dataset"] = dataset
    valid = {f for f in OptionBConfig.__dataclass_fields__}
    unknown = set(merged) - valid
    if unknown:
        raise ValueError(f"Unknown OptionBConfig fields: {sorted(unknown)}")
    return OptionBConfig(**merged)
