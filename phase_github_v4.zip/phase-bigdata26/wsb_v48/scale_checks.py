"""
scale_checks: two reviewer-requested measurements, isolated from the
causal machinery so nothing in the running campaign is touched.

1. score_stability: is removal-set membership stable under the
   instrument's own sampling noise and radius choice? Trains ONE
   baseline (seed 0), scores the full trainset under
   n_perturbations x epsilon grid, reports top-10k rank overlap against
   the canonical cell (n=64, eps=0.10) and the LFR resampling SE.
   Scoring only: no retraining anywhere.

2. throughput_demo: scores a 1.28M-sample corpus (25 fresh augmentation
   views of the CIFAR-10 trainset; every view is a distinct tensor
   through the full pipeline) and reports wall clock, samples/second,
   score-distribution stability across blocks, and plateau-guard
   statistics at scale. This demonstrates measured throughput at the
   million-sample scale; the corpus construction is stated plainly.
"""
import time
import numpy as np
import torch
from torch.utils.data import DataLoader

from .adversarial import get_model, load_dataset, train_standard
from .reviewer_proof import _score_training_set
from .utils import save_results


def _train_baseline(dataset, model_name, train_epochs, data_dir, device,
                    logger, seed=0):
    torch.manual_seed(seed); np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    loader = DataLoader(train_ds, batch_size=128, shuffle=True,
                        num_workers=2, pin_memory=True)
    train_standard(model, loader, train_epochs, device, logger=None)
    score_ds, _, _ = load_dataset(dataset, data_dir, train=True, augment=False)
    return model, score_ds, n_classes


def run_score_stability(dataset='cifar10', model_name='cifar_cnn',
                        train_epochs=50, data_dir='./data',
                        output_dir='./wsb_results', device='cuda',
                        logger=None, seed=0):
    model, score_ds, n_classes = _train_baseline(
        dataset, model_name, train_epochs, data_dir, device, logger, seed)
    idx = np.arange(len(score_ds))
    grid_n = [32, 64, 128]
    grid_eps = [0.05, 0.10, 0.15]
    top_k = 10000
    cells = {}
    for n_p in grid_n:
        for eps in grid_eps:
            t0 = time.time()
            s = _score_training_set(model, score_ds, idx, eps, n_p,
                                    n_classes, device, None)
            lfr = s['lfr']
            order = np.argsort(np.nan_to_num(lfr, nan=-1.0))
            cells[(n_p, eps)] = {
                'top_set': set(order[-top_k:].tolist()),
                'lfr': lfr,
                'runtime_s': round(time.time() - t0, 1)}
            if logger:
                logger.info(f"  scored n={n_p} eps={eps} "
                            f"({cells[(n_p, eps)]['runtime_s']}s)")
    ref = cells[(64, 0.10)]
    report = {'dataset': dataset, 'seed': seed, 'top_k': top_k,
              'reference_cell': 'n64_eps0.10', 'overlap_with_reference': {},
              'runtime_s': {}}
    for (n_p, eps), c in cells.items():
        key = f"n{n_p}_eps{eps}"
        report['overlap_with_reference'][key] = round(
            len(c['top_set'] & ref['top_set']) / top_k, 4)
        report['runtime_s'][key] = c['runtime_s']
    # LFR resampling SE at the canonical cell: binomial se sqrt(p(1-p)/n)
    p = np.nan_to_num(ref['lfr'], nan=0.0)
    report['lfr_binomial_se_at_n64_mean'] = round(
        float(np.mean(np.sqrt(p * (1 - p) / 64))), 4)
    # independent-draw stability: n=64 vs n=128 overlap already covers
    # sampling noise; eps rows cover radius. Both against one reference.
    if logger:
        logger.info(f"  overlaps vs reference: "
                    f"{report['overlap_with_reference']}")
    save_results(report, output_dir, f"score_stability_{dataset}")
    return report


def run_throughput_demo(dataset='cifar10', model_name='cifar_cnn',
                        train_epochs=50, data_dir='./data',
                        output_dir='./wsb_results', device='cuda',
                        logger=None, seed=0, n_views=25,
                        n_perturbations=64):
    """1.28M-sample scoring pass: 25 augmentation views x 50k images.
    Views use the AUGMENTED loader so every pass sees distinct tensors."""
    model, _, n_classes = _train_baseline(
        dataset, model_name, train_epochs, data_dir, device, logger, seed)
    aug_ds, _, _ = load_dataset(dataset, data_dir, train=True, augment=True)
    idx = np.arange(len(aug_ds))
    block_means, block_fracs, total = [], [], 0
    t0 = time.time()
    for v in range(n_views):
        s = _score_training_set(model, aug_ds, idx, 0.10, n_perturbations,
                                n_classes, device, None)
        lfr = s['lfr']; valid = ~np.isnan(lfr)
        block_means.append(float(np.mean(lfr[valid])))
        block_fracs.append(float(np.mean(valid)))
        total += len(idx)
        if logger and (v + 1) % 5 == 0:
            el = time.time() - t0
            logger.info(f"  view {v+1}/{n_views}: {total:,} samples in "
                        f"{el:.0f}s ({total/el:,.0f} samples/s)")
    elapsed = time.time() - t0
    report = {'dataset': dataset, 'n_views': n_views,
              'total_samples_scored': int(total),
              'cloud_members_per_sample': n_perturbations,
              'total_forward_evaluations': int(total * n_perturbations),
              'wall_clock_s': round(elapsed, 1),
              'samples_per_second': round(total / elapsed, 1),
              'lfr_block_mean_range': [round(min(block_means), 4),
                                       round(max(block_means), 4)],
              'valid_fraction_range': [round(min(block_fracs), 4),
                                       round(max(block_fracs), 4)]}
    if logger:
        logger.info(f"  THROUGHPUT: {total:,} samples, "
                    f"{report['total_forward_evaluations']:,} cloud "
                    f"evaluations, {elapsed:.0f}s wall clock "
                    f"({report['samples_per_second']:,.0f} samples/s)")
    save_results(report, output_dir, f"throughput_{dataset}_1M")
    return report
