# Results and provenance

Each file below is the raw output of the run that produced the paper's
numbers. File names carry the run timestamp. Framework versions are noted
where they differ from the code in this repository (`wsb_v48`, `tabular`
v10, `tools` v2). Later versions reproduce the earlier causal runs bit for
bit: the CIFAR-10 control batteries (2026-08-18) match the ten-seed
follow-up exactly on every shared arm and seed, and the tabular v10 runs
with `--perturb all` match the v7 point estimates seed for seed.

Percentages in the paper are these files' fractions times 100.

## Exact-ground-truth validation (Sec. V, Table I, Figs. 1-2)
| File | Paper |
|---|---|
| `theory_validation/calibration_20260807_140147.json` | Double well (Fig. 2), parallel lines (Fig. 1), triple well, three-well H vs LFR pairs, Stag Hunt separatrix |
| `theory_validation/games_null_10seeds_20260809_223859.json` | Prisoner's Dilemma and Matching Pennies nulls |
| `theory_validation/toy_validation_20260809_223901.json` | Toy-system checks |

## Games and RL (Sec. VI)
| File | Paper |
|---|---|
| `games/option_c_stag_hunt_replicator_20260810_081117.json` | Stag Hunt, replicator: peak H, bistable-region agreement |
| `games/option_c_stag_hunt_logit_response_20260810_081159.json` | Stag Hunt, logit response |
| `games/option_c_battle_of_sexes_replicator_20260810_082301.json` | Battle of the Sexes |
| `games/option_c_prisoners_dilemma_replicator_20260810_082339.json` | Prisoner's Dilemma sweep null |
| `rl/option_a_CartPole-v1_ppo_20260811_075004.json` | CartPole PPO, five seeds (Fig. 3) |

## Vision regimes (Sec. VII-A, Table II)
These files do not store a config block; settings are listed here.
| File | Settings | Paper |
|---|---|---|
| `vision_regimes/option_b_cifar10_none_20260808_225833.json` | CIFAR-10, standard training, 5 seeds | Table II, Standard |
| `vision_regimes/option_b_cifar10_pgd_20260809_021936.json` | CIFAR-10, PGD-AT, 5 seeds | Table II, PGD-AT |
| `vision_regimes/option_b_cifar10_trades_20260809_060233.json` | CIFAR-10, TRADES, 5 seeds | Table II, TRADES |
| `vision_regimes/option_b_cifar100_pgd_20260818_113755.json` | CIFAR-100, PGD-AT, seeds 0-4 (seed 1 collapsed) | CIFAR-100 regime |
| `vision_regimes/option_b_cifar100_pgd_20260818_142757.json` | CIFAR-100, PGD-AT, seeds 5-6 | CIFAR-100 regime |
| `vision_regimes/option_b_cifar100_pgd_20260818_130847.json` | CIFAR-100, PGD-AT, seed 1 rerun (collapse reproduced) | deterministic collapse |
| `vision_regimes/option_b_mnist_pgd_20260818_122953.json` | MNIST, PGD-AT, seeds 0-4 (seeds 2, 3 collapsed) | MNIST regime |

## Causal removal (Sec. VII-B, Tables III and IV)
`0.00784` in a config is the 2/255 evaluation attack. "Eval" is the size of
the fixed test population.
| File | Seeds | Eval | Paper |
|---|---|---|---|
| `causal/causal_cifar10_cifar_cnn_5seeds_20260810_010139.json` | 0-4 | 1,000 | Table III, five-seed screen (framework v37) |
| `causal/causal_cifar10_cifar_cnn_5seeds_20260809_123751.json` | 0-4 | 1,000 | Saturated regime at 8/255 (v35) |
| `causal/causal_cifar10_cifar_cnn_10seeds_20260818_020036.json` | 0-9 | 10,000 | Ten-seed follow-up, p = 0.0088 (v37) |
| `causal/causal_cifar10_cifar_cnn_5seeds_20260818_185438.json` | 0-4 | 10,000 | CIFAR-10 controls (class-matched random, loss) |
| `causal/causal_cifar10_cifar_cnn_3seeds_20260818_234839.json` | 5-9 | 10,000 | CIFAR-10 controls (name says 3 seeds; run with an explicit 5-seed list) |
| `causal/causal_cifar100_cifar_cnn_5seeds_20260818_211053.json` | 0-4 | 10,000 | CIFAR-100 controls |
| `causal/causal_cifar100_cifar_cnn_3seeds_20260819_021118.json` | 5 seeds | 10,000 | CIFAR-100 controls, second block |
| `causal/causal_cifar10_cifar_cnn_3seeds_20261021_111050.json` | 10-19 | 10,000 | Independent replication, p = 0.0020 (v48; log in `causal/logs/`) |
| `causal/causal_cifar10_cifar_cnn_5seeds_20260819_152412.json` | 0-4 | 10,000 | Data-valuation battery (EL2N, GraNd, forgetting) |
| `causal/causal_cifar10_cifar_cnn_5seeds_20260819_170810.json` | 0-4 | 10,000 | Instrument radius 0.05 |
| `causal/causal_cifar10_cifar_cnn_5seeds_20260819_184914.json` | 0-4 | 10,000 | Instrument radius 0.15 |
| `causal/aa_reeval_cifar10_20260819_034918.json` | 0-4 | 1,000 | APGD re-evaluation |
| `causal/aa_reeval_cifar10_20260819_105540.json` | 5-9 | 1,000 | APGD re-evaluation |
| `causal/aa_reeval_cifar10_20260819_114929.json` | 0-1 | 1,000 | APGD, ResNet-18 transfer |
| `causal/score_stability_cifar10_20260819_023240.json` | | | Removal-set overlap across radii and cloud sizes |

Seed labels for files without a stored seed list follow the run commands in
the top-level README. In runs made before the seed-metadata fix, the log line
`Seed k` printed the training seed plus one, and `config.n_seeds` and the
file name kept the `--n_seeds` default when `--seed_list` was given. The
replication log shows the mapping directly: the run logged as `Seed 11`
saves `causal_scores_cifar10_seed10.npz`, and so on through `Seed 20` and
`seed19`. The code now logs the true seed and stores `config.seeds`.

Every PGD evaluation uses 20 steps with step size max(eps/4, 1/255): 2/255 at
eps = 8/255 and 1/255 at eps = 2/255, as recorded in each causal config. The second CIFAR-100 block does not record its seed
IDs; its tests pair arms within the file, so they do not depend on the labels,
and its baselines match no other block.

Derived tables (`tools/itt_tables.py`, `tools/hlfr_diagnostic.py`):
| File | Paper |
|---|---|
| `diagnostics/table4_controls_cifar10_cifar100.json` | Table IV, CIFAR-10 and CIFAR-100 rows |
| `diagnostics/table4_apgd.json` | Table IV, APGD row |
| `diagnostics/table4_cifar10_followup_seeds0-9.json` | Table IV, LFR vs random (follow-up arms) |
| `diagnostics/replication_cifar10_seeds10-19.json` | Seeds 10-19 replication |
| `diagnostics/hlfr_cifar10.json`, `diagnostics/hlfr_cifar100.json` | H vs LFR removal sets: flip rates above 1/2, multiway fractions, top-10k overlap, ties |

Not included: the adversarially trained causal battery (baseline robust
36.7%), which ran on a second machine.

## Compression and throughput (Sec. III-C, VII-C)
| File | Paper |
|---|---|
| `compression/compression_20260809_194615.json` | Margin-matched flip gaps under masking, low rank, quantization |
| `throughput/throughput_cifar10_1M_20260819_042640.json` | 1.25M-sample scoring pass |

## Tabular (Sec. VIII)
| File | Paper |
|---|---|
| `tabular/tabular_hunt_v7.json`, `_v7_s1` to `_v7_s4` | Calibration ladder, seeds 0-4 (cardia_phase v7) |
| `tabular/tabular_hunt_v8_tta.json` | Cloud-mean softmax then temperature (TTA comparison) |
| `tabular/tabular_hunt_v10_all_s0-4.json` | Same protocol rerun with the flexible softmax-only comparators |
| `tabular/tabular_hunt_v10_cont_s0-4.json` | Sensitivity: binary and one-hot columns held fixed |
| `tabular/cardia_phase_campaign*.json` | CARDIA forecast null (aggregates only) |
| `tabular/metsyn_check.json` | CARDIA label check: implemented label equals the threshold rule for every record; missing-value counts |
| `tabular/imputation_check.txt` | CARDIA: every imputation median lies on the 'component not met' side, and the label recomputed from imputed features matches for every record |
| `tabular/escape_test_v10_s0-2.json` | Exploratory escape-entropy test; not reported in the paper |

CARDIA per-record outputs are excluded under the data use agreement.
