# PHASE: Local Basin Entropy for Learning Dynamics at Scale

Code and per-seed results for the IEEE BigData 2026 paper by Matthew Fried,
Honggang Wang, and Julia Fang.

PHASE scores each probe point (a strategy profile, an environment state, an
image, a tabular record) by the outcome distribution of a perturbation cloud
around it: the local basin entropy H and the label-flip rate (LFR). The
identification result (Proposition 1) is H = h2(LFR) + LFR * H_escape, so for
two-outcome clouds H is a function of LFR.

## Layout

| Path | Contents |
|---|---|
| `wsb_v48/` | Main framework (`python -m wsb_v48 ...`): exact-ground-truth validation, games, RL, vision regimes, causal removal battery, AutoAttack (APGD) re-evaluation, compression, throughput. See `wsb_v48/README.md` for protocol details. |
| `tabular/` | Tabular studies: calibration ladder (`tabular_hunt.py`), flexible softmax-only calibrators (`flex_calib.py`), CARDIA pipeline, exploratory escape-entropy test. |
| `tools/` | Camera-ready analyses: all-seed vs gated paired tables (`itt_tables.py`), H vs LFR removal-set diagnostics (`hlfr_diagnostic.py`). |
| `results/` | The result files behind the paper's numbers, with a claim-to-file map in `results/README.md`. |

## Install

Python 3.10 or later.

```
pip install -r requirements.txt
pip install git+https://github.com/fra31/auto-attack   # only for aa_reeval
```

## Data

```
python -m wsb_v48 download --data_dir ./data
```

This downloads MNIST, CIFAR-10, CIFAR-100 and SVHN and writes a verified
manifest to `wsb_results/data_manifest.json`. Every data-consuming command
checks the manifest first. The tabular datasets (digits, letter, adult,
covertype) come from scikit-learn and OpenML on first use.

CARDIA data are restricted-access and are used under an institutional data
use agreement. No CARDIA records, per-subject outputs, or the CARDIA loader
are in this repository; `results/` holds aggregate CARDIA outputs only.

## Reproducing the paper

Causal and tabular result files store a `config` block (dataset, model,
seed count, radii, attack settings); `results/README.md` lists the settings
for files that do not. Match those settings when rerunning.
Training seeds are 0-indexed and set with `torch.manual_seed(seed)`, so a run
with `--seed_list` reproduces the corresponding seeds of an earlier run.

Exact-ground-truth validation (Sec. V, Table I, Figs. 1-2):
```
python -m wsb_v48 calibration
python -m wsb_v48 toy_validation
python -m wsb_v48 games_null
```

Games and RL (Sec. VI):
```
python -m wsb_v48 option_c --game stag_hunt --dynamics replicator
python -m wsb_v48 option_c --game stag_hunt --dynamics logit_response
python -m wsb_v48 option_c --game battle_of_sexes --dynamics replicator
python -m wsb_v48 option_c --game prisoners_dilemma --dynamics replicator
python -m wsb_v48 option_a --env CartPole-v1 --algo ppo --n_seeds 5
```

Vision regimes (Table II and the CIFAR-100 / MNIST text):
```
python -m wsb_v48 option_b --dataset cifar10 --adversarial_training none   --n_seeds 5
python -m wsb_v48 option_b --dataset cifar10 --adversarial_training pgd    --n_seeds 5
python -m wsb_v48 option_b --dataset cifar10 --adversarial_training trades --n_seeds 5
python -m wsb_v48 option_b --dataset cifar100 --adversarial_training pgd --seed_list 0,1,2,3,4
python -m wsb_v48 option_b --dataset cifar100 --adversarial_training pgd --seed_list 5,6
python -m wsb_v48 option_b --dataset cifar100 --adversarial_training pgd --seed_list 1   # collapse retest
python -m wsb_v48 option_b --dataset mnist    --adversarial_training pgd --n_seeds 5
```

Causal removal battery (Sec. VII-B, Tables III and IV). `0.00784` is 2/255.
```
# five-seed screen, all twelve arms, 1,000-image evaluation
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset full \
    --n_seeds 5 --n_test_samples 1000 --attack_epsilon 0.00784
# saturated regime: same, at the default 8/255 attack
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset full \
    --n_seeds 5 --n_test_samples 1000
# ten-seed follow-up (seeds 0-9), full test set
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset full \
    --n_seeds 10 --n_test_samples 10000 --attack_epsilon 0.00784
# control batteries (class-matched random, loss); repeat for cifar100
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset controls \
    --seed_list 0,1,2,3,4 --n_test_samples 10000 --attack_epsilon 0.00784
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset controls \
    --seed_list 5,6,7,8,9 --n_test_samples 10000 --attack_epsilon 0.00784
# independent replication on new seeds
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset controls \
    --seed_list 10,11,12,13,14,15,16,17,18,19 --n_test_samples 10000 --attack_epsilon 0.00784
# data-valuation battery (EL2N, GraNd, forgetting)
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset valuation \
    --n_seeds 5 --n_test_samples 10000 --attack_epsilon 0.00784
# instrument-radius robustness
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset minimal \
    --wsb_epsilon 0.05 --n_seeds 5 --n_test_samples 10000 --attack_epsilon 0.00784
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset minimal \
    --wsb_epsilon 0.15 --n_seeds 5 --n_test_samples 10000 --attack_epsilon 0.00784
# adversarially trained regime
python -m wsb_v48 causal_intervention --dataset cifar10 --arm_subset full \
    --train_mode pgd --n_seeds 5
# APGD re-evaluation (the two APGD attacks of AutoAttack), and ResNet-18
python -m wsb_v48 aa_reeval --seed_list 0,1,2,3,4
python -m wsb_v48 aa_reeval --seed_list 5,6,7,8,9
python -m wsb_v48 aa_reeval --model resnet18 --seed_list 0,1
# scoring stability and throughput
python -m wsb_v48 score_stability
python -m wsb_v48 throughput_demo
```

Table IV (all-seed and gated paired comparisons, joined by explicit seed ID):
```
R=results/causal
python tools/itt_tables.py \
  --pool c10  $R/causal_cifar10_cifar_cnn_5seeds_20260818_185438.json:0-4 \
              $R/causal_cifar10_cifar_cnn_3seeds_20260818_234839.json:5-9 \
  --pool c100 $R/causal_cifar100_cifar_cnn_5seeds_20260818_211053.json:0-4 \
              $R/causal_cifar100_cifar_cnn_3seeds_20260819_021118.json:5-9 \
  --cmp c10 remove_high_lfr remove_class_random --cmp c10 remove_high_lfr remove_random \
  --cmp c10 remove_high_lfr remove_high_loss    --cmp c10 remove_high_h_basin remove_class_random \
  --cmp c100 remove_high_lfr remove_class_random --cmp c100 remove_high_loss remove_class_random \
  --cmp c100 remove_high_lfr remove_random       --cmp c100 remove_high_h_basin remove_class_random \
  --out table4_controls.json
python tools/itt_tables.py \
  --pool aa $R/aa_reeval_cifar10_20260819_034918.json:auto $R/aa_reeval_cifar10_20260819_105540.json:auto \
  --cmp aa remove_high_lfr remove_random --out table4_apgd.json
python tools/itt_tables.py \
  --pool new $R/causal_cifar10_cifar_cnn_3seeds_20261021_111050.json:10-19 \
  --cmp new remove_high_lfr remove_random --cmp new remove_high_h_basin remove_random \
  --out replication.json
```
The gate drops a seed pair when either arm's clean accuracy is more than 20
points below that seed's baseline. The arm-level flag in Table III (mean drop
over 10 points or any seed over 20) is computed separately by the framework.

H vs LFR removal-set diagnostics (Sec. VII-B) read the per-sample score files
`causal_scores_<dataset>_seed<k>.npz` that every causal run writes to its
output directory (not included here because of size):
```
python tools/hlfr_diagnostic.py --files "wsb_results/causal_scores_cifar10_seed*.npz" --out hlfr_cifar10.json
```

Compression (Sec. VII-C):
```
python -m wsb_v48 compression --dataset cifar10
```

Calibration ladder (Sec. VIII). The paper's numbers use the original rule,
Gaussian noise on all standardized columns (`--perturb all`); the sensitivity
analysis holds binary and one-hot columns fixed (`--perturb continuous`).
```
for s in 0 1 2 3 4; do
  python tabular/tabular_hunt.py --datasets digits,letter,adult,covtype --seed $s --perturb all        --out tabular_hunt_all_s$s.json
  python tabular/tabular_hunt.py --datasets adult,covtype               --seed $s --perturb continuous --out tabular_hunt_cont_s$s.json
done
```

## Tests

```
python tools/run_tests.py
cd tabular && python run_tests.py && python smoke_synthetic.py
```

## Citation

See `CITATION.cff`.
