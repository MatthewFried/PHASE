"""
PHASE on CARDIA. Run from a directory containing cardia_loader.py (from
cardia_master) and cardia_imp1_long.csv, with cardia_phase files present.

STAGED PLAN (run in this order):
  Stage 0 (seconds):  python run_cardia_phase.py --csv ... --stage counts
      Class counts for all three labels. Confirms which targets are viable.
  Stage 1 (~1 min):   --stage metsyn_quick
      Known-boundary validation on metsyn: H must correlate NEGATIVELY
      with distance-to-nearest-clinical-threshold. This is the real-data
      analog of the double-well calibration. Also prints the Prop-1
      diagnostics; if frac_clouds_multiway is small, H is LFR here.
  Stage 2 (~2 min):   --stage alpha_sweep
      alpha in {0.25, 0.5, 1.0} x labels {metsyn, outcome}: where does
      multiway structure appear, if anywhere. DECISION GATE: pursue the
      entropy analysis only where frac_clouds_multiway is material.
  Stage 3:            --stage full --label outcome
      Full report on the honest external target.
"""
import argparse, json, time
import numpy as np
from phase_tabular import (TabularCloudConfig, analyze_measurement_error,
                           population_report)
from cardia_adapter import load_cardia_with_ids


def fit_model(Xtr, ytr, seed=0):
    from sklearn.neural_network import MLPClassifier
    m = MLPClassifier(hidden_layer_sizes=(64, 64), max_iter=3000,
                      early_stopping=True, n_iter_no_change=25,
                      random_state=seed)
    m.fit(Xtr, ytr)
    return lambda X: m.predict(np.asarray(X, dtype=np.float32))


def fit_logistic(Xtr, ytr, seed=0):
    from sklearn.linear_model import LogisticRegression
    m = LogisticRegression(max_iter=2000, random_state=seed)
    m.fit(Xtr, ytr)
    return lambda X: m.predict(np.asarray(X, dtype=np.float32))


def one_run(csv, label, alpha, seed, n_pert=64, width="bio_demo"):
    d = load_cardia_with_ids(csv=csv, label=label, width=width, seed=seed)
    predict = fit_model(d["Xtr"], d["ytr"], seed)
    acc = float((predict(d["Xte"]) == d["yte"]).mean())
    sigma = np.ones(d["Xte"].shape[1], dtype=np.float32)  # standardized scale
    cfg = TabularCloudConfig(alpha=alpha, n_perturbations=n_pert, seed=seed,
                             freeze_features=d["freeze"])
    t0 = time.time()
    recs = analyze_measurement_error(d["Xte"], predict, sigma, cfg,
                                     d["n_classes"])
    rep = population_report(recs, d["yte"], d["n_classes"])
    rep.update(label=label, alpha=alpha, seed=seed, width=width,
               test_accuracy=round(acc, 4),
               runtime_s=round(time.time() - t0, 1),
               frozen_features=[d["feature_names"][i] for i in d["freeze"]])
    # per-record dump for downstream analysis
    import csv as _csv
    dump = f"cardia_phase_records_{label}_a{alpha}_s{seed}_{width}.csv"
    with open(dump, "w", newline="") as fh:
        w = _csv.writer(fh)
        w.writerow(["row", "hm_id", "y", "base_phase", "h", "lfr",
                    "occupied", "thr_dist"])
        td_all = d.get("thr_dist_te")
        for r in recs:
            w.writerow([r.index, d["ids_te"][r.index], int(d["yte"][r.index]),
                        r.base_phase, round(r.h, 6), round(r.lfr, 6),
                        r.occupied,
                        (round(float(td_all[r.index]), 4)
                         if td_all is not None else "")])
    rep["records_csv"] = dump
    # matched-LFR / different-H pairs among multiway clouds (real data)
    occ = np.array([r.occupied for r in recs])
    hh = np.array([r.h for r in recs]); ll = np.array([r.lfr for r in recs])
    mw = np.flatnonzero(occ >= 3)
    pairs = 0
    if len(mw) >= 2:
        sub = mw[np.argsort(ll[mw])]
        for i in range(len(sub)):
            j = i + 1
            while j < len(sub) and ll[sub[j]] - ll[sub[i]] < 0.03:
                if abs(hh[sub[i]] - hh[sub[j]]) > 0.1:
                    pairs += 1
                j += 1
    rep["multiway_matched_lfr_diff_h_pairs"] = int(pairs)
    if d.get("thr_dist_te") is not None:
        h = np.array([r.h for r in recs])
        td = d["thr_dist_te"][np.array([r.index for r in recs])]
        try:
            from scipy.stats import spearmanr
            s = spearmanr(h, td)
            rep["spearman_h_vs_threshold_distance"] = round(float(s.statistic), 4)
            rep["spearman_h_thr_p"] = float(s.pvalue)
        except Exception:
            pass
    return rep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--stage", default="counts",
                    choices=["counts", "metsyn_quick", "alpha_sweep", "full",
                             "forecast", "campaign", "campaign_seeds"])
    ap.add_argument("--label", default="outcome")
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    if args.stage == "counts":
        for label in ("metsyn", "outcome", "kmeans"):
            try:
                d = load_cardia_with_ids(csv=args.csv, label=label)
                print(f"{label:8s} classes={d['n_classes']} "
                      f"train_counts={np.bincount(d['ytr']).tolist()} "
                      f"frozen={len(d['freeze'])} feats={len(d['feature_names'])}")
            except Exception as e:
                print(f"{label:8s} FAIL {type(e).__name__}: {e}")
        return

    if args.stage == "metsyn_quick":
        rep = one_run(args.csv, "metsyn", args.alpha, args.seed)
        print(json.dumps(rep, indent=2))
        s = rep.get("spearman_h_vs_threshold_distance")
        if s is not None:
            verdict = "PASS (H peaks near clinical thresholds)" if s < -0.2 \
                      else "WEAK/FAIL: inspect before proceeding"
            print(f"\nKnown-boundary validation: spearman(H, threshold "
                  f"distance) = {s} -> {verdict}")
        out = args.out or "cardia_phase_metsyn_quick.json"
        json.dump(rep, open(out, "w"), indent=2); print("saved", out)
        return

    if args.stage == "alpha_sweep":
        rows = []
        for label in ("metsyn", "outcome"):
            for alpha in (0.25, 0.5, 1.0):
                r = one_run(args.csv, label, alpha, args.seed)
                rows.append({k: r.get(k) for k in
                             ("label", "alpha", "test_accuracy", "h_mean",
                              "lfr_mean", "frac_clouds_multiway",
                              "frac_lfr_le_half", "spearman_h_lfr_all")})
                print(rows[-1])
        out = args.out or "cardia_phase_alpha_sweep.json"
        json.dump(rows, open(out, "w"), indent=2); print("saved", out)
        return

    if args.stage == "campaign":
        from cardia_campaign import run_campaign
        rep = run_campaign(args.csv, seed=args.seed)
        out = args.out or "cardia_phase_campaign.json"
        json.dump(rep, open(out, "w"), indent=2)
        print(json.dumps(rep, indent=2)); print("saved", out)
        return
    if args.stage == "campaign_seeds":
        from cardia_campaign import run_seeds
        rep = run_seeds(args.csv)
        out = args.out or "cardia_phase_campaign_seeds.json"
        json.dump(rep, open(out, "w"), indent=2)
        print(json.dumps(rep, indent=2)); print("saved", out)
        return
    if args.stage == "forecast":
        from cardia_forecast import run_forecast
        rep = run_forecast(args.csv, alpha=args.alpha, seed=args.seed)
        out = args.out or "cardia_phase_forecast.json"
        json.dump(rep, open(out, "w"), indent=2)
        print(json.dumps(rep, indent=2)); print("saved", out)
        return

    rep = one_run(args.csv, args.label, args.alpha, args.seed,
                  n_pert=128)
    out = args.out or f"cardia_phase_full_{args.label}.json"
    json.dump(rep, open(out, "w"), indent=2)
    print(json.dumps(rep, indent=2)); print("saved", out)


if __name__ == "__main__":
    main()
