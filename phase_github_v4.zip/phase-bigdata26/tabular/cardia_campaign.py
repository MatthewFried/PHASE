"""
cardia_campaign: the full battery. One command, every meaningful test,
one JSON verdict.

Tests, in order of decisiveness:
  T1 MIXTURE: forecast lambda*softmax + (1-lambda)*cloud, lambda chosen on
     a validation split. best_lambda < 1 with test improvement => the
     cloud geometry carries information the model's softmax lacks.
     Bootstrap CI on the improvement. THE decisive test.
  T2 SMOOTHING/COUNT: cloud forecast with pseudo-counts {0.5,2,8} and
     n_pert 256; is the tail miscalibration finite-sample or real.
  T3 ALPHA: forecast quality across alpha {0.25,0.5,1.0}.
  T4 COVERAGE: among misclassified subjects, how often the TRUE class is
     inside the cloud's occupied set, versus the model's own top-2.
     Cloud-recovers-truth is a meaningful clinical claim on its own.
  T5 ECE: calibration error of cloud vs softmax vs mixture.
  T6 MODEL: logistic variant of T1 (is the geometry MLP-specific).
  T7 SEEDS: T1 headline under seeds {0,1,2}.
All runs reuse the forecast target (future stratum 2*dep+diab at last
observed wave) and subject-level splits: train / val / test = 60/15/25.
"""
import numpy as np
import pandas as pd


def _prep(csv, seed, width="bio_demo"):
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from cardia_loader import _feature_cols
    from cardia_forecast import _future_strata
    df = pd.read_csv(csv)
    base = (df[df["wave"] == 0].copy()
            .drop_duplicates("hm_id").set_index("hm_id"))
    feats = [c for c in _feature_cols(width) if c in base.columns]
    strata = _future_strata(df)
    common = base.index.intersection(strata.index)
    base, y = base.loc[common], strata.loc[common]
    vc = y.value_counts(); keep = vc[vc >= 20].index
    m = y.isin(keep); base, y = base[m], y[m]
    classes = sorted(y.unique())
    y = y.map({c: i for i, c in enumerate(classes)}).values.astype(int)
    K = len(classes)
    X = base[feats].astype("float64")
    X = X.fillna(X.median()).values.astype("float32")
    freeze = [i for i, n in enumerate(feats) if n in ("race", "gender", "edu")]
    idx = np.arange(len(X))
    itr, itmp = train_test_split(idx, test_size=0.40, random_state=seed,
                                 stratify=y)
    ival, ite = train_test_split(itmp, test_size=0.625, random_state=seed,
                                 stratify=y[itmp])   # 15/25 of total
    sc = StandardScaler().fit(X[itr])
    return dict(K=K, freeze=freeze,
                Xtr=sc.transform(X[itr]), ytr=y[itr],
                Xva=sc.transform(X[ival]), yva=y[ival],
                Xte=sc.transform(X[ite]), yte=y[ite])


def _mlp(Xtr, ytr, seed):
    from sklearn.neural_network import MLPClassifier
    return MLPClassifier((64, 64), max_iter=3000, early_stopping=True,
                         n_iter_no_change=25, random_state=seed).fit(Xtr, ytr)


def _logistic(Xtr, ytr, seed):
    from sklearn.linear_model import LogisticRegression
    return LogisticRegression(max_iter=2000, random_state=seed).fit(Xtr, ytr)


def _cloud_dist(model, X, K, freeze, alpha, n_pert, pseudo, seed):
    rng = np.random.default_rng(seed + 1000)
    sig = np.ones(X.shape[1], dtype=np.float32); sig[freeze] = 0.0
    n, d = X.shape
    noise = rng.normal(0, 1, (n, n_pert, d)).astype(np.float32)
    preds = model.predict((X[:, None, :] + alpha * noise * sig).reshape(-1, d))
    preds = preds.reshape(n, n_pert)
    counts = np.stack([np.bincount(preds[i], minlength=K)
                       for i in range(n)]).astype(float)
    P = (counts + pseudo) / (n_pert + pseudo * K)
    occ = counts > 0
    return P, occ


def _ll(P, y):
    P = np.clip(P, 1e-12, 1); P = P / P.sum(1, keepdims=True)
    return -np.log(P[np.arange(len(y)), y])


def _ece(P, y, bins=10):
    conf = P.max(1); pred = P.argmax(1); acc = (pred == y).astype(float)
    edges = np.linspace(0, 1, bins + 1); e = 0.0
    for a, b in zip(edges[:-1], edges[1:]):
        m = (conf > a) & (conf <= b)
        if m.any():
            e += m.mean() * abs(acc[m].mean() - conf[m].mean())
    return float(e)


def _mixture(model, prep, alpha, n_pert, pseudo, seed):
    """Fit lambda on val, evaluate on test. Returns dict."""
    K, fz = prep["K"], prep["freeze"]
    out = {}
    Pc_va, _ = _cloud_dist(model, prep["Xva"], K, fz, alpha, n_pert, pseudo, seed)
    Ps_va = model.predict_proba(prep["Xva"])
    lams = np.linspace(0, 1, 21)
    va_ll = [ _ll(l * Ps_va + (1 - l) * Pc_va, prep["yva"]).mean() for l in lams ]
    best = float(lams[int(np.argmin(va_ll))])
    Pc_te, occ = _cloud_dist(model, prep["Xte"], K, fz, alpha, n_pert, pseudo, seed)
    Ps_te = model.predict_proba(prep["Xte"])
    Pm_te = best * Ps_te + (1 - best) * Pc_te
    ll_s, ll_c, ll_m = (_ll(P, prep["yte"]) for P in (Ps_te, Pc_te, Pm_te))
    imp = ll_s - ll_m
    B = 2000; rng = np.random.default_rng(seed)
    boots = np.array([imp[rng.integers(0, len(imp), len(imp))].mean()
                      for _ in range(B)])
    out.update(best_lambda=best,
               logloss_softmax=round(float(ll_s.mean()), 4),
               logloss_cloud=round(float(ll_c.mean()), 4),
               logloss_mixture=round(float(ll_m.mean()), 4),
               mixture_improvement=round(float(imp.mean()), 4),
               improvement_ci95=[round(float(np.percentile(boots, 2.5)), 4),
                                 round(float(np.percentile(boots, 97.5)), 4)],
               ece_softmax=round(_ece(Ps_te, prep["yte"]), 4),
               ece_cloud=round(_ece(Pc_te, prep["yte"]), 4),
               ece_mixture=round(_ece(Pm_te, prep["yte"]), 4))
    # T4 coverage among errors
    pred = Ps_te.argmax(1); err = pred != prep["yte"]
    if err.sum() >= 10:
        cov_cloud = float(occ[np.arange(len(err)), prep["yte"]][err].mean())
        top2 = np.argsort(-Ps_te, axis=1)[:, :2]
        cov_top2 = float((top2 == prep["yte"][:, None]).any(1)[err].mean())
        out.update(n_errors=int(err.sum()),
                   truth_in_cloud_given_error=round(cov_cloud, 4),
                   truth_in_top2_given_error=round(cov_top2, 4))
    return out


def run_campaign(csv, seed=0):
    rep = {"seed": seed}
    prep = _prep(csv, seed)
    rep["n_classes"] = prep["K"]
    rep["split_sizes"] = [len(prep["ytr"]), len(prep["yva"]), len(prep["yte"])]
    model = _mlp(prep["Xtr"], prep["ytr"], seed)
    rep["test_accuracy"] = round(float(model.score(prep["Xte"], prep["yte"])), 4)

    # T1 headline: alpha 0.5, n_pert 256, pseudo 2
    rep["T1_mixture"] = _mixture(model, prep, 0.5, 256, 2.0, seed)
    # T2 smoothing sweep at alpha 0.5
    rep["T2_smoothing"] = {str(p): _mixture(model, prep, 0.5, 256, p, seed)
                           ["logloss_cloud"] for p in (0.5, 2.0, 8.0)}
    # T3 alpha sweep (mixture summary per alpha)
    rep["T3_alpha"] = {str(a): {k: _mixture(model, prep, a, 256, 2.0, seed)[k]
                                for k in ("best_lambda", "logloss_mixture",
                                          "mixture_improvement")}
                       for a in (0.25, 0.5, 1.0)}
    # T6 logistic variant
    lmodel = _logistic(prep["Xtr"], prep["ytr"], seed)
    rep["T6_logistic"] = {"test_accuracy":
                          round(float(lmodel.score(prep["Xte"], prep["yte"])), 4),
                          **{k: _mixture(lmodel, prep, 0.5, 256, 2.0, seed)[k]
                             for k in ("best_lambda", "logloss_softmax",
                                       "logloss_mixture",
                                       "mixture_improvement",
                                       "improvement_ci95")}}
    return rep


def run_seeds(csv, seeds=(0, 1, 2)):
    """T7: headline under multiple seeds."""
    out = []
    for s in seeds:
        prep = _prep(csv, s)
        model = _mlp(prep["Xtr"], prep["ytr"], s)
        r = _mixture(model, prep, 0.5, 256, 2.0, s)
        r["seed"] = s
        r["test_accuracy"] = round(float(model.score(prep["Xte"], prep["yte"])), 4)
        out.append({k: r[k] for k in ("seed", "test_accuracy", "best_lambda",
                                      "logloss_softmax", "logloss_mixture",
                                      "mixture_improvement",
                                      "improvement_ci95",
                                      "truth_in_cloud_given_error",
                                      "truth_in_top2_given_error")
                    if k in r})
    return out
