"""
cardia_phase v1: PHASE (local basin entropy) for tabular clinical data.

Model-agnostic: the model is any predict_fn(X: [n,d] float32) -> int labels.
Two cloud constructions:

  1. measurement_error: per-feature Gaussian noise with sigma_j =
     alpha * (median within-subject across-wave SD of feature j), so the
     radius is the data's own measurement-plus-biological variability.
     Demographic / categorical / time-invariant features are FROZEN
     (perturbing race or a baseline constant is meaningless).

  2. longitudinal_replicate: the cloud of a subject-wave record is the
     subject's OTHER wave rows. No synthetic noise: H measures real
     within-patient classification instability. Radius-free.

Per-record outputs: H (nats), Miller-Madow H, LFR (flip rate vs the
unperturbed record's phase), occupied phase count, cloud size.
Population outputs: the Proposition-1 diagnostics (fraction of clouds
with >=3 occupied phases, fraction with LFR<=0.5, Spearman and top-k
overlap between H and LFR rankings) and validity gates (per-class
support, degenerate-target detection). Numbers without their
diagnostics are not interpretable; the report always carries both.
"""
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence
import numpy as np


# ----------------------------------------------------------------------
def entropy(counts: np.ndarray) -> float:
    c = np.asarray(counts, dtype=float)
    n = c.sum()
    if n <= 0:
        return float("nan")
    p = c[c > 0] / n
    return float(-(p * np.log(p)).sum())


def miller_madow(counts: np.ndarray) -> float:
    c = np.asarray(counts, dtype=float)
    n = c.sum()
    m = int((c > 0).sum())
    if n <= 0:
        return float("nan")
    return entropy(c) + (m - 1) / (2.0 * n)


# ----------------------------------------------------------------------
@dataclass
class TabularCloudConfig:
    mode: str = "measurement_error"      # or "longitudinal_replicate"
    n_perturbations: int = 64            # measurement_error only
    alpha: float = 1.0                   # sigma multiplier
    freeze_features: Sequence[int] = ()  # indices NEVER perturbed
    clip_low: Optional[np.ndarray] = None    # per-feature clip (optional)
    clip_high: Optional[np.ndarray] = None
    seed: int = 0
    min_cloud: int = 3                   # replicate mode: min other-wave rows


def within_subject_sigma(X: np.ndarray, subject_ids: np.ndarray) -> np.ndarray:
    """sigma_j = median over subjects of the subject's across-wave SD of
    feature j (subjects with >=2 rows). Zero-variance features get 0,
    which freezes them automatically."""
    X = np.asarray(X, dtype=float)
    sids = np.asarray(subject_ids)
    order = np.argsort(sids, kind="stable")
    Xs, ss = X[order], sids[order]
    bounds = np.flatnonzero(np.r_[True, ss[1:] != ss[:-1], True])
    per_subj = []
    for a, b in zip(bounds[:-1], bounds[1:]):
        if b - a >= 2:
            per_subj.append(Xs[a:b].std(axis=0, ddof=1))
    if not per_subj:
        raise ValueError("no subject has >=2 rows; cannot estimate "
                         "within-subject sigma")
    return np.median(np.stack(per_subj), axis=0)


# ----------------------------------------------------------------------
@dataclass
class PhaseRecord:
    index: int
    base_phase: int
    h: float
    h_mm: float
    lfr: float
    occupied: int
    cloud_size: int


def analyze_measurement_error(
    X: np.ndarray, predict_fn: Callable, sigma: np.ndarray,
    cfg: TabularCloudConfig, n_classes: int,
    batch_rows: int = 512,
) -> List[PhaseRecord]:
    """Batched: perturb `batch_rows` records at a time, one predict_fn call
    per batch over all their cloud members jointly."""
    rng = np.random.default_rng(cfg.seed)
    X = np.asarray(X, dtype=np.float32)
    n, d = X.shape
    sig = np.asarray(sigma, dtype=np.float32).copy()
    sig[list(cfg.freeze_features)] = 0.0
    base = np.asarray(predict_fn(X)).astype(int)
    out: List[PhaseRecord] = []
    P = cfg.n_perturbations
    for a in range(0, n, batch_rows):
        b = min(a + batch_rows, n)
        block = X[a:b]                                   # [B,d]
        noise = rng.normal(0.0, 1.0, size=(b - a, P, d)).astype(np.float32)
        cloud = block[:, None, :] + cfg.alpha * noise * sig[None, None, :]
        if cfg.clip_low is not None:
            np.maximum(cloud, cfg.clip_low[None, None, :], out=cloud)
        if cfg.clip_high is not None:
            np.minimum(cloud, cfg.clip_high[None, None, :], out=cloud)
        preds = np.asarray(predict_fn(cloud.reshape(-1, d))).astype(int)
        preds = preds.reshape(b - a, P)
        for i in range(b - a):
            counts = np.bincount(preds[i], minlength=n_classes)
            bp = int(base[a + i])
            out.append(PhaseRecord(
                index=a + i, base_phase=bp,
                h=entropy(counts), h_mm=miller_madow(counts),
                lfr=float((preds[i] != bp).mean()),
                occupied=int((counts > 0).sum()), cloud_size=P))
    return out


def analyze_longitudinal_replicate(
    X: np.ndarray, subject_ids: np.ndarray, predict_fn: Callable,
    cfg: TabularCloudConfig, n_classes: int,
) -> List[PhaseRecord]:
    """Cloud of record i = the same subject's OTHER rows. One predict_fn
    call for the whole matrix; entropies assembled per record."""
    X = np.asarray(X, dtype=np.float32)
    sids = np.asarray(subject_ids)
    preds = np.asarray(predict_fn(X)).astype(int)
    out: List[PhaseRecord] = []
    order = np.argsort(sids, kind="stable")
    inv_groups: Dict = {}
    for pos in order:
        inv_groups.setdefault(sids[pos], []).append(pos)
    for sid, rows in inv_groups.items():
        rows = np.asarray(rows)
        for r in rows:
            others = rows[rows != r]
            if len(others) < cfg.min_cloud:
                continue
            cloud_preds = preds[others]
            counts = np.bincount(cloud_preds, minlength=n_classes)
            bp = int(preds[r])
            out.append(PhaseRecord(
                index=int(r), base_phase=bp,
                h=entropy(counts), h_mm=miller_madow(counts),
                lfr=float((cloud_preds != bp).mean()),
                occupied=int((counts > 0).sum()),
                cloud_size=int(len(others))))
    return out


# ----------------------------------------------------------------------
def population_report(records: List[PhaseRecord], y: Optional[np.ndarray],
                      n_classes: int, top_k: int = 500) -> Dict:
    """The Proposition-1 diagnostics + validity gates. Every H claim must
    travel with this block."""
    if not records:
        return {"n_records": 0, "valid": False,
                "reason": "no records passed cloud-size gate"}
    h = np.array([r.h for r in records])
    lfr = np.array([r.lfr for r in records])
    occ = np.array([r.occupied for r in records])
    rep: Dict = {
        "n_records": len(records),
        "h_mean": float(np.nanmean(h)),
        "h_max": float(np.nanmax(h)),
        "lfr_mean": float(np.nanmean(lfr)),
        # ---- Proposition 1 diagnostics ----
        "frac_clouds_multiway": float((occ >= 3).mean()),
        "frac_clouds_binary_or_pure": float((occ <= 2).mean()),
        "frac_lfr_le_half": float((lfr <= 0.5).mean()),
    }
    # rank agreement between H and LFR (where Prop 1 predicts identity
    # for binary clouds, these should be ~1 on the binary subpopulation)
    def spearman(a, b):
        try:
            from scipy.stats import spearmanr
            r = spearmanr(a, b).statistic
            return float(r) if np.isfinite(r) else float("nan")
        except Exception:
            ra = np.argsort(np.argsort(a)); rb = np.argsort(np.argsort(b))
            ra = ra - ra.mean(); rb = rb - rb.mean()
            den = np.sqrt((ra**2).sum() * (rb**2).sum())
            return float((ra * rb).sum() / den) if den > 0 else float("nan")
    rep["spearman_h_lfr_all"] = spearman(h, lfr)
    binary = occ <= 2
    if binary.sum() >= 10:
        rep["spearman_h_lfr_binary_clouds"] = spearman(h[binary], lfr[binary])
    k = min(top_k, len(records))
    top_h = set(np.argsort(-h)[:k]); top_l = set(np.argsort(-lfr)[:k])
    rep["top_k"] = k
    rep["top_k_overlap_h_lfr"] = float(len(top_h & top_l) / k)
    # ---- validity gates ----
    if y is not None:
        y = np.asarray(y)
        counts = np.bincount(y, minlength=n_classes)
        rep["class_counts"] = counts.tolist()
        rep["sparse_classes_lt_50"] = [int(c) for c in np.flatnonzero(counts < 50)]
        rep["target_degenerate"] = bool((counts > 0).sum() < 2)
    pooled = np.zeros(n_classes)
    for r in records:
        pooled[r.base_phase] += 1
    rep["base_phase_distribution"] = (pooled / pooled.sum()).round(4).tolist()
    rep["valid"] = True
    return rep
