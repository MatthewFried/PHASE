"""
cardia_forecast: does the perturbation cloud's escape distribution carry
probabilistic information about a patient's REALIZED future stratum,
beyond the model's point prediction?

Design. Wave-varying components of the outcome (dep at waves 3+ and
cumulative diabetes) define a 4-class stratum s = 2*dep + diab. The
target for each subject is the stratum realized at their LAST observed
wave. A classifier is trained on wave-0 features to predict that future
stratum (subject-level split). On the test half, three probabilistic
forecasts are scored against the realized stratum with multiclass
log-loss and Brier score:

  onehot   the point prediction as a degenerate distribution
  softmax  the model's own predict_proba
  cloud    the empirical distribution of predicted strata over a
           perturbation cloud (alpha x SD, demographics frozen),
           Laplace-smoothed

If `cloud` beats `onehot`, the cloud's spread is information, not noise;
comparison with `softmax` shows whether that information is already in
the model's probabilities or is genuinely geometric. Results are
reported overall and stratified by cloud entropy tercile, since any
cloud advantage should concentrate where H is high.
"""
import numpy as np
import pandas as pd


def _future_strata(df):
    """Per subject: stratum 2*dep+diab at the last wave with a dep
    observation strictly after baseline. Returns Series indexed by hm_id."""
    d = df[df["wave"] > 0].copy()
    if "dep" not in d.columns:
        raise ValueError("no dep column; forecast target unavailable")
    d = d[d["dep"].notna()]
    d = d.sort_values(["hm_id", "wave"])
    last = d.groupby("hm_id").tail(1).set_index("hm_id")
    dep = last["dep"].fillna(0).clip(0, 1).astype(int)
    dcol = "diab_cumul" if "diab_cumul" in df.columns else (
        "diab" if "diab" in df.columns else None)
    if dcol:
        diab = (df.groupby("hm_id")[dcol].max().reindex(last.index)
                .fillna(0).clip(0, 1).astype(int))
    else:
        diab = pd.Series(0, index=last.index)
    return (2 * dep + diab).astype(int)


def _scores(P, y, k):
    """Multiclass log-loss and Brier for probability matrix P vs labels."""
    eps = 1e-12
    P = np.clip(P, eps, 1.0)
    P = P / P.sum(axis=1, keepdims=True)
    ll = -np.log(P[np.arange(len(y)), y])
    Y = np.zeros_like(P); Y[np.arange(len(y)), y] = 1.0
    br = ((P - Y) ** 2).sum(axis=1)
    return ll, br


def run_forecast(csv, alpha=0.5, seed=0, n_pert=128, width="bio_demo"):
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from sklearn.neural_network import MLPClassifier
    from cardia_loader import _feature_cols

    df = pd.read_csv(csv)
    base = (df[df["wave"] == 0].copy()
            .drop_duplicates("hm_id").set_index("hm_id"))
    feats = [c for c in _feature_cols(width) if c in base.columns]
    strata = _future_strata(df)
    common = base.index.intersection(strata.index)
    base, y = base.loc[common], strata.loc[common]
    # keep classes with enough mass for a stratified split
    vc = y.value_counts(); keep = vc[vc >= 20].index
    m = y.isin(keep)
    base, y = base[m], y[m]
    classes = sorted(y.unique())
    remap = {c: i for i, c in enumerate(classes)}
    y = y.map(remap).values.astype(int)
    K = len(classes)
    X = base[feats].astype("float64")
    X = X.fillna(X.median()).values.astype("float32")
    names = list(feats)
    freeze = [i for i, n in enumerate(names) if n in ("race", "gender", "edu")]

    idx = np.arange(len(X))
    itr, ite = train_test_split(idx, test_size=0.25, random_state=seed,
                                stratify=y)
    sc = StandardScaler().fit(X[itr])
    Xtr, Xte = sc.transform(X[itr]), sc.transform(X[ite])
    ytr, yte = y[itr], y[ite]

    model = MLPClassifier(hidden_layer_sizes=(64, 64), max_iter=3000,
                          early_stopping=True, n_iter_no_change=25,
                          random_state=seed).fit(Xtr, ytr)
    acc = float(model.score(Xte, yte))

    # cloud forecast
    rng = np.random.default_rng(seed)
    sig = np.ones(Xte.shape[1], dtype=np.float32)
    sig[freeze] = 0.0
    n, d = Xte.shape
    noise = rng.normal(0, 1, size=(n, n_pert, d)).astype(np.float32)
    cloud = Xte[:, None, :] + alpha * noise * sig[None, None, :]
    preds = model.predict(cloud.reshape(-1, d)).reshape(n, n_pert)
    counts = np.stack([np.bincount(preds[i], minlength=K)
                       for i in range(n)]).astype(float)
    P_cloud = (counts + 0.5) / (n_pert + 0.5 * K)      # Laplace smoothing
    # entropies for stratification
    pc = counts / counts.sum(axis=1, keepdims=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        H = -np.nansum(np.where(pc > 0, pc * np.log(pc), 0.0), axis=1)

    point = model.predict(Xte)
    P_onehot = np.zeros((n, K)); P_onehot[np.arange(n), point] = 1.0
    P_soft = model.predict_proba(Xte)

    rep = {"n_test": int(n), "n_classes": K,
           "class_counts_kept": vc[keep].to_dict(),
           "test_accuracy_future_stratum": round(acc, 4),
           "alpha": alpha, "seed": seed, "n_perturbations": n_pert}
    per = {}
    for name, P in (("onehot", P_onehot), ("softmax", P_soft),
                    ("cloud", P_cloud)):
        ll, br = _scores(P, yte, K)
        per[name] = (ll, br)
        rep[f"logloss_{name}"] = round(float(ll.mean()), 4)
        rep[f"brier_{name}"] = round(float(br.mean()), 4)
    # paired comparisons
    for a, b in (("cloud", "onehot"), ("cloud", "softmax")):
        diff = per[b][0] - per[a][0]          # positive => a better
        rep[f"logloss_win_frac_{a}_vs_{b}"] = round(float((diff > 0).mean()), 4)
        rep[f"logloss_mean_improvement_{a}_vs_{b}"] = round(float(diff.mean()), 4)
    # H-tercile stratification of the cloud-vs-onehot improvement
    terc = np.quantile(H, [1/3, 2/3])
    lab = np.digitize(H, terc)
    imp = per["onehot"][0] - per["cloud"][0]
    rep["h_terciles"] = [round(float(t), 4) for t in terc]
    rep["improvement_by_h_tercile"] = [
        round(float(imp[lab == t].mean()), 4) if (lab == t).any() else None
        for t in range(3)]
    return rep
