"""
escape_test: does escape entropy predict anything once flip rate and
margin are held fixed?

Proposition 1 gives H = h2(q) + q * H_escape, with q = LFR and
H_escape = H(q~) the entropy of WHERE the escaping cloud mass lands.
This test asks whether H_escape carries information about an outcome
that is independent of the cloud itself: disagreement among
independently trained models.

Per dataset and model condition:
  1. Split train/val/test exactly as tabular_hunt (val unused here).
  2. Train a reference model (seed s) and M further models (seeds
     s+1..s+M) on the same training data; with --bag each extra model
     also trains on a bootstrap resample.
  3. On the test split, from the REFERENCE model only: cloud counts
     (alpha, n_pert as in the hunt), LFR, H, H_escape = (H - h2(LFR))/LFR,
     softmax margin (top1 - top2).
  4. Targets, from the M other models only (never the reference):
       model_entropy : entropy of the M predicted labels at the test point
       disagree      : fraction of the M models whose label differs from
                       the reference model's label
  5. Analysis on test points with LFR > 0 (H_escape defined):
       a. partial Spearman of H_escape with each target, controlling for
          LFR and margin (OLS on ranks), with a bootstrap 95% CI
       b. stratified contrast: within LFR-quintile x margin-tercile cells,
          multiway clouds (H_escape > 0) minus binary clouds
          (H_escape = 0), cell-size weighted, bootstrap 95% CI
       c. the same partial correlation for LFR (controlling H_escape and
          margin) and margin (controlling LFR and H_escape), for scale.

Datasets: adult is binary (H_escape is always 0), so the default runs
digits, letter, covtype.

Status: exploratory. A positive association here is a candidate finding
that needs replication across --seed values (each seed changes the
split, the reference model and the comparison ensemble) before it is
reported as more than that.

Usage:
  python escape_test.py --datasets digits,letter,covtype --seed 0 \
      --n_models 8 --out escape_test_s0.json
"""
import argparse, json, time
import numpy as np


def _h2(q):
    q = np.asarray(q, float); out = np.zeros_like(q)
    m = (q > 0) & (q < 1)
    out[m] = -(q[m]*np.log(q[m]) + (1-q[m])*np.log(1-q[m]))
    return out


def _entropy_rows(C):
    C = np.asarray(C, float); T = C.sum(1, keepdims=True)
    P = np.where(C > 0, C / np.maximum(T, 1), 1.0)
    return -(np.where(C > 0, P * np.log(P), 0.0)).sum(1)


def _rank(x):
    from scipy.stats import rankdata
    return rankdata(x)


def _partial(y, x, Z, D=None):
    """Spearman partial correlation of x with y given the ranked columns
    of Z and (unranked) indicator columns D, e.g. predicted-class dummies."""
    ry, rx = _rank(y), _rank(x)
    cols = [np.ones(len(y))] + [_rank(z) for z in Z]
    if D is not None and D.shape[1] > 1:
        cols += [D[:, j] for j in range(1, D.shape[1])]   # drop one level
    A = np.column_stack(cols)
    by = np.linalg.lstsq(A, ry, rcond=None)[0]
    bx = np.linalg.lstsq(A, rx, rcond=None)[0]
    ey, ex = ry - A @ by, rx - A @ bx
    den = np.sqrt((ey**2).sum() * (ex**2).sum())
    return float((ey*ex).sum() / den) if den > 0 else 0.0


def _boot(fn, n, B, seed):
    rng = np.random.default_rng(seed)
    vals = [fn(rng.integers(0, n, n)) for _ in range(B)]
    vals = [v for v in vals if v is not None and np.isfinite(v)]
    return [round(float(np.percentile(vals, 2.5)), 4),
            round(float(np.percentile(vals, 97.5)), 4)]


def _strat_contrast(target, he, lfr, margin, idx=None, cls=None):
    """Multiway-minus-binary difference in target within LFR-quintile x
    margin-tercile cells (x predicted class when cls is given)."""
    if idx is not None:
        target, he, lfr, margin = target[idx], he[idx], lfr[idx], margin[idx]
        cls = cls[idx] if cls is not None else None
    qb = np.quantile(lfr, [0.2, 0.4, 0.6, 0.8])
    mb = np.quantile(margin, [1/3, 2/3])
    cl = np.digitize(lfr, qb); cm = np.digitize(margin, mb)
    cc = cls if cls is not None else np.zeros(len(lfr), int)
    num = 0.0; wsum = 0
    for a in np.unique(cl):
      for b in np.unique(cm):
        for c in np.unique(cc):
            s = (cl == a) & (cm == b) & (cc == c)
            multi = s & (he > 1e-9); binary = s & (he <= 1e-9)
            if multi.sum() >= 5 and binary.sum() >= 5:
                w = int(s.sum())
                num += w * (target[multi].mean() - target[binary].mean())
                wsum += w
    return num / wsum if wsum else None


def run_cell(X, y, cond, seed, n_models, alpha, n_pert, bag, B, freeze=()):
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from tabular_hunt import _fit
    from cardia_campaign import _cloud_dist
    K = int(y.max()) + 1
    idx = np.arange(len(X))
    itr, itmp = train_test_split(idx, test_size=0.4, random_state=seed,
                                 stratify=y)
    _, ite = train_test_split(itmp, test_size=0.625, random_state=seed,
                              stratify=y[itmp])
    sc = StandardScaler().fit(X[itr])
    Xtr, Xte = sc.transform(X[itr]), sc.transform(X[ite])
    ytr = y[itr]
    ref = _fit(Xtr, ytr, cond, seed)
    rng = np.random.default_rng(seed + 500)
    preds = []
    for j in range(1, n_models + 1):
        if bag:
            b = rng.integers(0, len(Xtr), len(Xtr))
            m = _fit(Xtr[b], ytr[b], cond, seed + j)
        else:
            m = _fit(Xtr, ytr, cond, seed + j)
        preds.append(m.predict(Xte))
    preds = np.stack(preds, 1)                      # n_test x M
    ref_pred = ref.predict(Xte)
    Ps = ref.predict_proba(Xte)
    srt = np.sort(Ps, 1)
    margin = srt[:, -1] - srt[:, -2]
    Pc, _ = _cloud_dist(ref, Xte, K, list(freeze), alpha, n_pert, 0.0, seed)
    counts = np.rint(Pc * n_pert).astype(int)       # pseudo=0 -> raw counts
    lfr = 1.0 - counts[np.arange(len(ref_pred)), ref_pred] / n_pert
    H = _entropy_rows(counts)
    mc = np.stack([np.bincount(r, minlength=K) for r in preds])
    model_entropy = _entropy_rows(mc)
    disagree = (preds != ref_pred[:, None]).mean(1)
    keep = lfr > 0
    he = np.zeros_like(lfr)
    he[keep] = (H[keep] - _h2(lfr[keep])) / lfr[keep]
    he = np.maximum(he, 0.0)
    n_all = len(lfr)
    lfr_k, he_k, mg_k = lfr[keep], he[keep], margin[keep]
    cls_k = ref_pred[keep]
    D_k = np.eye(K)[cls_k][:, np.unique(cls_k)]
    cell = dict(cond=cond, n_test=int(n_all), n_classes=K,
                ref_accuracy=round(float((ref_pred == y[ite]).mean()), 4),
                n_lfr_pos=int(keep.sum()),
                frac_multiway_among_lfr_pos=round(float((he_k > 1e-9).mean()), 4),
                mean_h_escape_multiway=(round(float(he_k[he_k > 1e-9].mean()), 4)
                                        if (he_k > 1e-9).any() else 0.0),
                mean_model_entropy=round(float(model_entropy.mean()), 4),
                mean_disagree=round(float(disagree.mean()), 4))
    if keep.sum() < 50 or (he_k > 1e-9).sum() < 20:
        cell["skipped"] = "too few LFR>0 or multiway test points"
        return cell
    n = int(keep.sum())
    for tname, t in (("model_entropy", model_entropy[keep]),
                     ("disagree", disagree[keep])):
        # primary: partial correlation controlling LFR, margin and the
        # reference model's predicted class (record-level bootstrap CI;
        # between-model variability enters through repeated --seed runs)
        r = dict(
            partial_h_escape=round(_partial(t, he_k, [lfr_k, mg_k], D_k), 4),
            partial_h_escape_ci95=_boot(
                lambda i: _partial(t[i], he_k[i], [lfr_k[i], mg_k[i]], D_k[i]),
                n, B, seed),
            partial_h_escape_no_class=round(_partial(t, he_k, [lfr_k, mg_k]), 4),
            partial_lfr=round(_partial(t, lfr_k, [he_k, mg_k], D_k), 4),
            partial_margin=round(_partial(t, mg_k, [lfr_k, he_k], D_k), 4))
        for key, cl_arg in (("strat_multi_minus_binary", None),
                            ("strat_within_class", cls_k)):
            v = _strat_contrast(t, he_k, lfr_k, mg_k, cls=cl_arg)
            r[key] = None if v is None else round(v, 4)
            if v is not None:
                r[key + "_ci95"] = _boot(
                    lambda i: _strat_contrast(t, he_k, lfr_k, mg_k, i,
                                              cls=cl_arg), n, B, seed + 1)
        cell[tname] = r
    return cell


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", default="digits,letter,covtype")
    ap.add_argument("--conds", default="calibrated,overfit")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n_models", type=int, default=8)
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--n_pert", type=int, default=128)
    ap.add_argument("--bag", action="store_true")
    ap.add_argument("--boot", type=int, default=500)
    ap.add_argument("--cache", default=None)
    ap.add_argument("--perturb", choices=["continuous", "all"],
                    default="continuous")
    ap.add_argument("--out", default="escape_test.json")
    a = ap.parse_args()
    from tabular_hunt import load_datasets
    data = load_datasets(tuple(a.datasets.split(",")), a.cache)
    rep = dict(config=vars(a))
    for name, val in data.items():
        if isinstance(val[0], str) and val[0] == "SKIP":
            rep[name] = {"skipped": val[1]}; continue
        X, y, fz = val
        fz = fz if a.perturb == "continuous" else []
        rep[name] = {"frozen_columns": len(fz)}
        for cond in a.conds.split(","):
            t0 = time.time()
            c = run_cell(X, y, cond, a.seed, a.n_models, a.alpha, a.n_pert,
                         a.bag, a.boot, freeze=fz)
            c["runtime_s"] = round(time.time() - t0, 1)
            rep[name][cond] = c
            me = c.get("model_entropy", {})
            print(f"{name}/{cond}: multiway={c['frac_multiway_among_lfr_pos']} "
                  f"partial(Hesc, model_entropy | LFR, margin)="
                  f"{me.get('partial_h_escape')} CI{me.get('partial_h_escape_ci95')} "
                  f"within-class strat={me.get('strat_within_class')} "
                  f"CI{me.get('strat_within_class_ci95')} [{c['runtime_s']}s]")
        json.dump(rep, open(a.out, "w"), indent=1)
    print("saved", a.out)


if __name__ == "__main__":
    main()
