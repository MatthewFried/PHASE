"""
check_metsyn_thresholds: the known-boundary validation is only valid if
the threshold distance uses exactly the rule that generates the metsyn
label. This script checks that on the real data.

  1. Recomputes the component count from cardia_adapter.METSYN_THRESH
     (same strict inequalities) and compares it with
     cardia_loader._metsyn_label for every subject.
  2. Reports missing values in the five threshold columns before
     imputation (the label treats a missing value as "below threshold",
     while the features are median-imputed; any such subject has a label
     and a feature vector that disagree).
  3. Confirms every threshold column is a perturbed (not frozen) feature.

Run from the cardia folder (needs cardia_loader.py and the CSV):
  python check_metsyn_thresholds.py --csv cardia_imp1_long.csv
Exit code 1 if any check fails.
"""
import argparse, json, sys
import numpy as np, pandas as pd
from cardia_loader import _metsyn_label, DEMO, _feature_cols
from cardia_adapter import METSYN_THRESH


def count_from_table(base):
    c = pd.Series(0, index=base.index)
    for col, (thr, side) in METSYN_THRESH.items():
        s = base.get(col)
        if s is None:
            continue
        c = c + ((s > thr) if side == "hi" else (s < thr)).astype(int)
    return c.clip(0, 5).astype(int)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="cardia_imp1_long.csv")
    ap.add_argument("--width", default="bio_demo")
    a = ap.parse_args()
    df = pd.read_csv(a.csv)
    base = df[df["wave"] == 0].copy().drop_duplicates("hm_id").set_index("hm_id")
    lab = _metsyn_label(base)
    tab = count_from_table(base)
    agree = float((lab == tab).mean())
    miss = {c: int(base[c].isna().sum()) for c in METSYN_THRESH if c in base}
    absent = [c for c in METSYN_THRESH if c not in base.columns]
    feats = _feature_cols(a.width)
    not_features = [c for c in METSYN_THRESH if c not in feats]
    frozen = [c for c in METSYN_THRESH if c in DEMO]
    rep = dict(n_subjects=int(len(base)), label_agreement=agree,
               n_disagree=int((lab != tab).sum()),
               missing_before_imputation=miss, columns_absent=absent,
               threshold_columns_not_features=not_features,
               threshold_columns_frozen=frozen,
               label_counts=lab.value_counts().sort_index().to_dict())
    print(json.dumps(rep, indent=1, default=int))
    ok = (agree == 1.0 and not absent and not not_features and not frozen)
    if sum(miss.values()):
        print("NOTE: missing threshold values present; those subjects are "
              "labelled 'below threshold' but carry median-imputed features.")
    print("PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
