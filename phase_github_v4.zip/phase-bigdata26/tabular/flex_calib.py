"""
flex_calib: flexible recalibrators that see ONLY the model's softmax.

Reviewer 2 asked whether the calibration-ladder residual survives a more
expressive function of the full softmax vector than temperature,
isotonic, or vector scaling. Two such families are provided:

  dirichlet : full matrix scaling on log-probabilities, z = W log p + b,
              with ODIR regularization (off-diagonal and bias L2;
              Kull et al., NeurIPS 2019). Lambda chosen by inner 2-fold
              CV on the validation split.
  gbm       : gradient-boosted trees on the full log-softmax vector
              (sklearn HistGradientBoostingClassifier), a nonparametric
              softmax-only recalibrator.

fit_best_flex() cross-fits these together with temperature and
vector/isotonic scaling on the validation split, picks the softmax-only
map with the lowest out-of-fold NLL over the whole family, returns out-of-fold validation
probabilities (used to choose the cloud-mixture weight without in-sample
leakage) and a predictor refit on the full validation split for test.
Nothing here touches the test split.
"""
import numpy as np
from scipy.optimize import minimize


def _logp(P):
    return np.log(np.clip(P, 1e-12, 1.0))


def _softmax(Z):
    Z = Z - Z.max(1, keepdims=True)
    E = np.exp(Z)
    return E / E.sum(1, keepdims=True)


def _nll(P, y):
    P = np.clip(P, 1e-12, 1.0)
    P = P / P.sum(1, keepdims=True)
    return float(-np.log(P[np.arange(len(y)), y]).mean())


class Dirichlet:
    def __init__(self, K, lam):
        self.K, self.lam = K, lam

    def fit(self, P, y):
        K, n = self.K, len(y)
        L = _logp(P)
        Y = np.zeros((n, K)); Y[np.arange(n), y] = 1.0
        off = ~np.eye(K, dtype=bool)
        c = self.lam / max(K * (K - 1), 1)

        def f(theta):
            W = theta[:K * K].reshape(K, K); b = theta[K * K:]
            Q = _softmax(L @ W.T + b)
            nll = -np.sum(Y * np.log(np.clip(Q, 1e-12, 1))) / n
            reg = c * (np.sum(W[off] ** 2) + np.sum(b ** 2))
            G = (Q - Y) / n
            gW = G.T @ L + 2 * c * W * off
            gb = G.sum(0) + 2 * c * b
            return nll + reg, np.concatenate([gW.ravel(), gb])

        theta0 = np.concatenate([np.eye(K).ravel(), np.zeros(K)])
        r = minimize(f, theta0, jac=True, method="L-BFGS-B",
                     options={"maxiter": 500})
        self.W = r.x[:K * K].reshape(K, K); self.b = r.x[K * K:]
        return self

    def predict_proba(self, P):
        return _softmax(_logp(P) @ self.W.T + self.b)


class GBM:
    def __init__(self, K, seed=0):
        self.K, self.seed = K, seed

    def fit(self, P, y):
        from sklearn.ensemble import HistGradientBoostingClassifier
        self.m = HistGradientBoostingClassifier(
            max_iter=300, learning_rate=0.05, max_leaf_nodes=15,
            l2_regularization=1.0, early_stopping=True,
            validation_fraction=0.2, n_iter_no_change=20,
            random_state=self.seed).fit(_logp(P), y)
        return self

    def predict_proba(self, P):
        Q = np.full((len(P), self.K), 1e-6)
        Q[:, self.m.classes_] = self.m.predict_proba(_logp(P))
        return Q / Q.sum(1, keepdims=True)


class Temperature:
    def __init__(self, K):
        self.K = K

    def fit(self, P, y):
        from scipy.optimize import minimize_scalar
        L = _logp(P)
        r = minimize_scalar(lambda lt: _nll(_softmax(L / np.exp(lt)), y),
                            bounds=(-3, 3), method="bounded")
        self.T = float(np.exp(r.x))
        return self

    def predict_proba(self, P):
        return _softmax(_logp(P) / self.T)


class Vector:
    """One temperature per class (log-parametrized, L-BFGS)."""
    def __init__(self, K):
        self.K = K

    def fit(self, P, y):
        L = _logp(P); n = len(y)
        Y = np.zeros((n, self.K)); Y[np.arange(n), y] = 1.0

        def f(lw):
            w = np.exp(lw); Q = _softmax(L * w)
            nll = -np.sum(Y * np.log(np.clip(Q, 1e-12, 1))) / n
            g = ((Q - Y) / n * L).sum(0) * w
            return nll, g
        r = minimize(f, np.zeros(self.K), jac=True, method="L-BFGS-B")
        self.w = np.exp(r.x)
        return self

    def predict_proba(self, P):
        return _softmax(_logp(P) * self.w)


class Isotonic:
    def __init__(self, K):
        self.K = K

    def fit(self, P, y):
        from sklearn.isotonic import IsotonicRegression
        self.iso = IsotonicRegression(y_min=1e-6, y_max=1 - 1e-6,
                                      out_of_bounds="clip").fit(P[:, 1], y == 1)
        return self

    def predict_proba(self, P):
        p1 = self.iso.predict(P[:, 1])
        return np.stack([1 - p1, p1], 1)


def _folds(n, seed, k=2):
    rng = np.random.default_rng(seed + 77)
    perm = rng.permutation(n)
    return [perm[i::k] for i in range(k)]


def _oof(make, P, y, folds):
    out = np.zeros((len(y), P.shape[1]))
    for i, te in enumerate(folds):
        tr = np.concatenate([f for j, f in enumerate(folds) if j != i])
        out[te] = make().fit(P[tr], y[tr]).predict_proba(P[te])
    return out


def fit_best_flex(P_val, y_val, K, seed=0, lams=(1e-3, 1e-2, 1e-1, 1.0, 10.0)):
    folds = _folds(len(y_val), seed)
    cands = {}
    for lam in lams:
        oof = _oof(lambda: Dirichlet(K, lam), P_val, y_val, folds)
        cands[f"dirichlet_lam{lam:g}"] = (oof, lambda lam=lam: Dirichlet(K, lam))
    oof = _oof(lambda: GBM(K, seed), P_val, y_val, folds)
    cands["gbm"] = (oof, lambda: GBM(K, seed))
    cands["temperature"] = (_oof(lambda: Temperature(K), P_val, y_val, folds),
                            lambda: Temperature(K))
    simple = (lambda: Isotonic(K)) if K == 2 else (lambda: Vector(K))
    sname = "isotonic" if K == 2 else "vector"
    cands[sname] = (_oof(simple, P_val, y_val, folds), simple)
    scores = {k: _nll(v[0], y_val) for k, v in cands.items()}
    best_d = min((k for k in scores if k.startswith("dirichlet")),
                 key=scores.get)
    # the comparator is the best softmax-only map by out-of-fold NLL over
    # the whole family, so a weak flexible fit cannot inflate the residual
    winner = min((best_d, "gbm", "temperature", sname), key=scores.get)
    oof_win, make_win = cands[winner]
    final = make_win().fit(P_val, y_val)
    return dict(name=winner, oof_val=oof_win, model=final,
                oof_nll=dict(dirichlet=round(scores[best_d], 4),
                             dirichlet_lambda=best_d,
                             gbm=round(scores["gbm"], 4),
                             temperature=round(scores["temperature"], 4),
                             **{sname: round(scores[sname], 4)}))
