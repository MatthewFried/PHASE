"""
Check that median imputation preserves every CARDIA metsyn component flag.
Run in the cardia folder (needs cardia_loader.py, cardia_adapter.py, the CSV):
    python check_imputation_flags.py --csv cardia_imp1_long.csv
Prints each biomarker's imputation median, whether that median is on the
'component not met' side, and whether the label recomputed from the
IMPUTED features equals the implemented label for every record.
"""
import argparse
import pandas as pd
from cardia_loader import _metsyn_label
from cardia_adapter import METSYN_THRESH

ap = argparse.ArgumentParser()
ap.add_argument("--csv", default="cardia_imp1_long.csv")
a = ap.parse_args()
df = pd.read_csv(a.csv)
base = df[df["wave"] == 0].copy().drop_duplicates("hm_id").set_index("hm_id")
lab = _metsyn_label(base)

ok = True
imputed_count = pd.Series(0, index=base.index)
for col, (thr, side) in METSYN_THRESH.items():
    x = base[col]
    med = x.median()                      # same rule as cardia_adapter: fillna(median)
    met = (med > thr) if side == "hi" else (med < thr)
    n_miss = int(x.isna().sum())
    print(f"{col:18s} missing={n_miss:4d} median={med:8.2f} "
          f"threshold={'>' if side == 'hi' else '<'}{thr}  median meets component: {met}")
    ok &= not met
    xi = x.fillna(med)
    imputed_count += ((xi > thr) if side == "hi" else (xi < thr)).astype(int)

agree = (imputed_count.clip(0, 5) == lab).mean()
print(f"label from imputed features == implemented label: {agree:.4f} "
      f"({int((imputed_count.clip(0, 5) != lab).sum())} disagreements)")
print("PASS" if ok and agree == 1.0 else "FAIL")
