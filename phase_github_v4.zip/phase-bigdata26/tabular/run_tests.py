"""Regression tests for cardia_phase v10. Run: python run_tests.py
(check_metsyn_thresholds.py is the separate real-data check; it needs
cardia_loader.py and the CSV.)"""
import numpy as np


class Recorder:
    """Fake model that records every input it is asked to predict."""
    def __init__(self, K):
        self.K, self.seen = K, []

    def predict(self, Z):
        Z = np.asarray(Z); self.seen.append(Z.copy())
        return (Z[:, 0] > 0).astype(int) % self.K

    def predict_proba(self, Z):
        p = (np.asarray(Z)[:, 0] > 0).astype(float)
        return np.stack([1 - p, p], 1)


def test_binary_detection():
    from tabular_hunt import binary_columns
    X = np.column_stack([np.random.randn(100), np.random.randint(0, 2, 100),
                         np.zeros(100), np.random.randint(0, 5, 100)]).astype("float32")
    assert binary_columns(X) == [1, 2], binary_columns(X)
    print("binary_columns: ok")


def test_freeze_in_clouds():
    from cardia_campaign import _cloud_dist
    rng = np.random.default_rng(0)
    X = np.column_stack([rng.normal(size=50), rng.integers(0, 2, 50),
                         rng.normal(size=50)]).astype("float32")
    m = Recorder(2)
    _cloud_dist(m, X, 2, [1], 0.5, 16, 0.0, 0)
    Z = m.seen[-1].reshape(50, 16, 3)
    assert np.all(Z[:, :, 1] == X[:, None, 1]), "frozen column was perturbed"
    assert not np.all(Z[:, :, 0] == X[:, None, 0]), "continuous column not perturbed"
    print("freeze in _cloud_dist: ok")


def test_freeze_in_hunt_slice():
    from phase_tabular import TabularCloudConfig, analyze_measurement_error
    rng = np.random.default_rng(1)
    X = np.column_stack([rng.normal(size=40), rng.integers(0, 2, 40)]).astype("float32")
    m = Recorder(2)
    cfg = TabularCloudConfig(alpha=0.5, n_perturbations=8, seed=0,
                             freeze_features=(1,))
    analyze_measurement_error(X, m.predict, np.ones(2, np.float32), cfg, 2)
    Z = np.concatenate([s for s in m.seen if len(s) == 40 * 8])
    assert set(np.unique(Z[:, 1])) <= {0.0, 1.0}, "binary column left {0,1}"
    print("freeze in analyze_measurement_error: ok")


def test_partial_class_control():
    from escape_test import _partial
    rng = np.random.default_rng(2); n = 4000
    cls = rng.integers(0, 4, n)
    lfr = rng.random(n); mg = rng.random(n)
    he = cls + 0.3 * rng.normal(size=n)          # escape tracks class
    tgt = cls + 0.3 * rng.normal(size=n)         # target tracks class only
    D = np.eye(4)[cls]
    with_cls = _partial(tgt, he, [lfr, mg], D)
    without = _partial(tgt, he, [lfr, mg])
    assert without > 0.5 and abs(with_cls) < 0.1, (without, with_cls)
    print(f"partial with class control: ok ({without:.2f} -> {with_cls:.2f})")


def test_flex_never_worse_than_family_oof():
    from flex_calib import fit_best_flex, _nll
    rng = np.random.default_rng(3); n, K = 600, 3
    y = rng.integers(0, K, n)
    logits = np.eye(K)[y] * 2 + rng.normal(size=(n, K))
    P = np.exp(logits * 3); P /= P.sum(1, keepdims=True)     # overconfident
    fx = fit_best_flex(P, y, K, 0)
    best = min(v for k, v in fx["oof_nll"].items() if isinstance(v, float))
    assert abs(_nll(fx["oof_val"], y) - best) < 1e-3, fx["oof_nll"]
    print("flex selects the family's best out-of-fold map: ok", fx["name"])


if __name__ == "__main__":
    test_binary_detection(); test_freeze_in_clouds(); test_freeze_in_hunt_slice()
    test_partial_class_control(); test_flex_never_worse_than_family_oof()
    print("ALL PASS")
