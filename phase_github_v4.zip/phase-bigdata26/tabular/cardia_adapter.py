"""
Adapter around the project's cardia_loader: identical pipeline (same
features, labels, filters, split, scaler) but additionally returns
subject ids, feature names, a freeze mask for non-perturbable features
(demographics, fips one-hots), and, for metsyn, each subject's distance
to the nearest clinical threshold in standardized units. Requires
cardia_loader.py on the path (ships with cardia_master).
"""
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from cardia_loader import (_feature_cols, _metsyn_label, _subject_outcomes,
                           _outcome_label_subject, BIO, DEMO)

METSYN_THRESH = {"waist_baseline": (100, "hi"), "sys_baseline": (130, "hi"),
                 "glucose_baseline": (100, "hi"), "hdl_baseline": (40, "lo"),
                 "ldl_baseline": (160, "hi")}


def load_cardia_with_ids(csv="cardia_imp1_long.csv", label="outcome",
                         width="bio_demo", seed=0, min_class=15):
    df = pd.read_csv(csv)
    base = df[df["wave"] == 0].copy().drop_duplicates("hm_id").set_index("hm_id")
    feats = [c for c in _feature_cols(width) if c in base.columns]
    sub = _subject_outcomes(df).reindex(base.index)
    if label == "outcome":
        y = _outcome_label_subject(sub)
        if (y.value_counts() >= min_class).sum() < 3:
            y = (sub["dep"] * 2 + sub["diab"]).astype(int)
        if (y.value_counts() >= min_class).sum() < 2:
            y = sub["dep"].astype(int)
    elif label == "metsyn":
        y = _metsyn_label(base)
    elif label == "kmeans":
        from sklearn.cluster import KMeans
        Xtmp = StandardScaler().fit_transform(
            base[feats].fillna(base[feats].median()))
        y = pd.Series(KMeans(n_clusters=6, n_init=10,
                             random_state=seed).fit_predict(Xtmp),
                      index=base.index)
    else:
        raise ValueError(label)
    X = base[feats].astype("float64").copy()
    X = X.fillna(X.median())
    names = list(X.columns)
    if width == "bio_demo_fips" and "fips" in base.columns:
        fips = pd.get_dummies(base["fips"].astype("category"),
                              prefix="fips").astype("float64")
        X = pd.concat([X, fips], axis=1)
        names = list(X.columns)
    vc = y.value_counts(); keep = vc[vc >= min_class].index
    m = y.isin(keep).values
    X, y = X[m], y[m]
    ids = X.index.to_numpy()
    if y.nunique() < 2:
        raise ValueError(f"degenerate label: counts={vc.to_dict()}")
    y = y.map({c: i for i, c in enumerate(sorted(y.unique()))}).astype("int64")
    nc = int(y.max()) + 1
    counts = y.value_counts()
    strat = y.values if counts.min() >= 2 and (counts.min() * 0.25) >= 1 else None
    idx = np.arange(len(X))
    itr, ite = train_test_split(idx, test_size=0.25, random_state=seed,
                                stratify=strat)
    Xv = X.values.astype("float32"); yv = y.values
    sc = StandardScaler().fit(Xv[itr])
    Xtr, Xte = sc.transform(Xv[itr]).astype("float32"), sc.transform(Xv[ite]).astype("float32")
    # freeze mask: demographics and fips one-hots are not perturbable
    freeze = [i for i, n in enumerate(names)
              if n in DEMO or n.startswith("fips_")]
    # metsyn: standardized distance to nearest clinical threshold per subject
    thr_dist = None
    if label == "metsyn":
        dists = []
        for col, (thr, _) in METSYN_THRESH.items():
            if col in names:
                j = names.index(col)
                z_thr = (thr - sc.mean_[j]) / sc.scale_[j]
                dists.append(np.abs(Xte[:, j] - z_thr))
        if dists:
            thr_dist = np.min(np.stack(dists), axis=0)
    return dict(Xtr=Xtr, ytr=yv[itr], Xte=Xte, yte=yv[ite],
                n_classes=nc, ids_tr=ids[itr], ids_te=ids[ite],
                feature_names=names, freeze=freeze, thr_dist_te=thr_dist)
