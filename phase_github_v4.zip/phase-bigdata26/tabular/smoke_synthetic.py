"""Synthetic smoke: verifies both cloud modes end to end, including the
Prop-1 diagnostics, on data with a KNOWN multiway boundary structure.
Runs in seconds on CPU."""
import numpy as np
from sklearn.neural_network import MLPClassifier
from phase_tabular import (TabularCloudConfig, within_subject_sigma,
                           analyze_measurement_error,
                           analyze_longitudinal_replicate,
                           population_report)

rng = np.random.default_rng(0)
# 3-class problem: radial shells -> records near shell boundaries have
# genuinely multiway clouds; deep-shell records have pure clouds.
n_sub, waves, d = 400, 6, 8
centers = rng.normal(0, 1, (n_sub, d))
X, sid = [], []
for i in range(n_sub):
    for w in range(waves):
        X.append(centers[i] + 0.15 * rng.normal(0, 1, d))
        sid.append(i)
X = np.array(X, dtype=np.float32); sid = np.array(sid)
r = np.linalg.norm(X[:, :2], axis=1)
y = np.digitize(r, [0.9, 1.15]).astype(int)         # 3 shells, NARROW middle

m = MLPClassifier((64, 64), max_iter=500, random_state=0).fit(X, y)
predict = lambda Z: m.predict(np.asarray(Z, dtype=np.float32))
print("train acc:", (predict(X) == y).mean().round(3))

sigma = within_subject_sigma(X, sid)
print("within-subject sigma (first 4):", sigma[:4].round(3))

cfg = TabularCloudConfig(alpha=1.0, n_perturbations=64, seed=1)
recs = analyze_measurement_error(X[:600], predict, sigma, cfg, 3)
rep = population_report(recs, y[:600], 3)
print("\nMEASUREMENT-ERROR mode:")
for k in ("n_records", "h_mean", "lfr_mean", "frac_clouds_multiway",
          "frac_lfr_le_half", "spearman_h_lfr_all",
          "spearman_h_lfr_binary_clouds", "top_k_overlap_h_lfr"):
    print(f"  {k}: {rep.get(k)}")
assert rep["frac_clouds_multiway"] > 0.02, rep["frac_clouds_multiway"]
assert rep.get("spearman_h_lfr_binary_clouds", 1.0) > 0.95  # Prop 1 identity
# On the multiway subpopulation H must NOT be a function of LFR:
import numpy as np
occ = np.array([r.occupied for r in recs])
h = np.array([r.h for r in recs]); l = np.array([r.lfr for r in recs])
mw = occ >= 3
if mw.sum() >= 10:
    # matched-LFR pairs with different H exist among multiway clouds
    pairs = 0
    idx = np.flatnonzero(mw)
    for i in range(len(idx)):
        for j in range(i+1, len(idx)):
            if abs(l[idx[i]]-l[idx[j]]) < 0.03 and abs(h[idx[i]]-h[idx[j]]) > 0.1:
                pairs += 1
    print(f"  multiway clouds: {mw.sum()}, matched-LFR/different-H pairs: {pairs}")
    assert pairs > 0

cfg2 = TabularCloudConfig(mode="longitudinal_replicate", min_cloud=3)
recs2 = analyze_longitudinal_replicate(X, sid, predict, cfg2, 3)
rep2 = population_report(recs2, y, 3)
print("\nLONGITUDINAL-REPLICATE mode:")
for k in ("n_records", "h_mean", "lfr_mean", "frac_clouds_multiway"):
    print(f"  {k}: {rep2.get(k)}")
assert rep2["n_records"] > 0
print("\nSMOKE PASS: both modes, diagnostics, gates")
