"""
tabular_hunt: the mixture test across many tabular datasets under TWO
model conditions, testing one hypothesis:

  H: the perturbation cloud adds probabilistic information over the
     model's softmax exactly when the softmax is miscalibrated.

Conditions per dataset:
  calibrated : early-stopped MLP (the CARDIA-null condition)
  overfit    : wide MLP, no early stopping, long budget (degraded ECE)

Per cell: T1 mixture (lambda on val, bootstrap CI on test improvement),
ECE softmax/cloud/mixture, truth-in-cloud coverage vs top-2, and the
Prop-1 diagnostics (multiway fraction, H-LFR spearman). Freeze mask is
empty (generic tabular; all features standardized and perturbable).

Datasets resolve via sklearn/openml with local caching; any that fail to
load are skipped and reported.
"""
import numpy as np, json, time


def binary_columns(X):
    """Indices of columns taking at most two distinct values (one-hot
    dummies, binary indicators). Gaussian noise on these leaves the data
    domain, so clouds hold them fixed ("continuous" perturbation rule)."""
    return [j for j in range(X.shape[1]) if len(np.unique(X[:, j])) <= 2]


def load_datasets(which=("digits", "letter", "adult", "covtype"), cache=None):
    out = {}
    from sklearn import datasets as skd
    if "digits" in which:
        d = skd.load_digits()
        Xd = d.data.astype("float32")
        out["digits"] = (Xd, d.target.astype(int), binary_columns(Xd))
    for name, oml, target in (("letter", "letter", "class"),
                              ("adult", "adult", "class"),
                              ("covtype", "covertype", "class")):
        if name not in which:
            continue
        try:
            d = skd.fetch_openml(oml, version=1 if name != "covtype" else 3,
                                 as_frame=True, data_home=cache, parser="auto")
            X = d.data.select_dtypes(include=[np.number])
            import pandas as pd
            cat = d.data.select_dtypes(exclude=[np.number])
            if cat.shape[1]:
                X = pd.concat([X, pd.get_dummies(cat, drop_first=True)], axis=1)
            y = d.target.astype("category").cat.codes.values.astype(int)
            Xv = X.values.astype("float32")
            m = np.isfinite(Xv).all(axis=1)
            Xv, y = Xv[m], y[m]
            if len(Xv) > 20000:            # covtype etc: subsample
                rng = np.random.default_rng(0)
                idx = rng.choice(len(Xv), 20000, replace=False)
                Xv, y = Xv[idx], y[idx]
            out[name] = (Xv, y, binary_columns(Xv))
        except Exception as e:
            out[name] = ("SKIP", str(e)[:80])
    return out


def _fit(Xtr, ytr, cond, seed):
    from sklearn.neural_network import MLPClassifier
    if cond == "calibrated":
        m = MLPClassifier((64, 64), max_iter=3000, early_stopping=True,
                          n_iter_no_change=25, random_state=seed)
    else:                                   # overfit
        m = MLPClassifier((512, 512), max_iter=1500, early_stopping=False,
                          alpha=1e-7, random_state=seed)
    return m.fit(Xtr, ytr)


def hunt_one(X, y, cond, seed=0, alpha=0.5, n_pert=128, pseudo=2.0,
             label_noise=0.0, freeze=()):
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from cardia_campaign import _cloud_dist, _ll, _ece
    from phase_tabular import (TabularCloudConfig, analyze_measurement_error,
                               population_report)
    K = int(y.max()) + 1
    idx = np.arange(len(X))
    itr, itmp = train_test_split(idx, test_size=0.4, random_state=seed,
                                 stratify=y)
    iva, ite = train_test_split(itmp, test_size=0.625, random_state=seed,
                                stratify=y[itmp])
    sc = StandardScaler().fit(X[itr])
    Xtr, Xva, Xte = (sc.transform(X[i]) for i in (itr, iva, ite))
    ytr, yva, yte = y[itr].copy(), y[iva], y[ite]
    if label_noise > 0:  # TRAIN-only symmetric noise -> miscalibration
        rng0 = np.random.default_rng(seed)
        flip = rng0.random(len(ytr)) < label_noise
        ytr[flip] = rng0.integers(0, K, int(flip.sum()))
    model = _fit(Xtr, ytr, cond, seed)
    acc = float(model.score(Xte, yte))
    # mixture
    freeze = list(freeze)
    Pc_va, _ = _cloud_dist(model, Xva, K, freeze, alpha, n_pert, pseudo, seed)
    Ps_va = model.predict_proba(Xva)
    lams = np.linspace(0, 1, 21)
    best = float(lams[int(np.argmin([_ll(l*Ps_va+(1-l)*Pc_va, yva).mean()
                                     for l in lams]))])
    # TEMPERATURE-SCALING CONTROL: fit T on val logits by NLL, then ask
    # whether the cloud still adds anything over the temperature-scaled
    # softmax (the standard one-parameter recalibration).
    def _temp_probs(P_raw, T):
        L = np.log(np.clip(P_raw, 1e-12, 1))
        Z = L / T
        Z = Z - Z.max(1, keepdims=True)
        E = np.exp(Z)
        return E / E.sum(1, keepdims=True)
    Ts = np.linspace(0.25, 8.0, 60)
    T_best = float(Ts[int(np.argmin([_ll(_temp_probs(Ps_va, t), yva).mean()
                                     for t in Ts]))])
    Pt_va = _temp_probs(Ps_va, T_best)
    best_t = float(lams[int(np.argmin([_ll(l*Pt_va+(1-l)*Pc_va, yva).mean()
                                       for l in lams]))])
    Pc, occ = _cloud_dist(model, Xte, K, freeze, alpha, n_pert, pseudo, seed)
    # TTA-THEN-CALIBRATE baseline (reviewer-suggested, Hekler-style):
    # mean softmax over the SAME cloud members, then temperature-scaled.
    def _cloud_mean_proba(X):
        rng2 = np.random.default_rng(seed + 2000)
        sig = np.ones(X.shape[1], dtype=np.float32); sig[freeze] = 0.0
        noise = rng2.normal(0, 1, (X.shape[0], n_pert, X.shape[1])
                            ).astype(np.float32)
        pts = (X[:, None, :] + alpha * noise * sig).reshape(-1, X.shape[1])
        P = model.predict_proba(pts).reshape(X.shape[0], n_pert, K)
        return P.mean(axis=1)
    Ptta_va = _cloud_mean_proba(Xva)
    T_tta = float(np.linspace(0.25, 8.0, 60)[int(np.argmin(
        [_ll(_temp_probs(Ptta_va, t), yva).mean()
         for t in np.linspace(0.25, 8.0, 60)]))])
    Ps = model.predict_proba(Xte)
    Pm = best*Ps + (1-best)*Pc
    ll_s, ll_m = _ll(Ps, yte), _ll(Pm, yte)
    # INPUT-DEPENDENT CALIBRATION BASELINES (the decisive control):
    # K=2 -> isotonic regression on P(class 1); K>2 -> vector scaling
    # (one temperature per class), both fit on the validation split.
    def _vector_probs(P_raw, w):
        L = np.log(np.clip(P_raw, 1e-12, 1)) * w[None, :]
        L = L - L.max(1, keepdims=True)
        E = np.exp(L)
        return E / E.sum(1, keepdims=True)
    if K == 2:
        from sklearn.isotonic import IsotonicRegression
        iso = IsotonicRegression(y_min=1e-6, y_max=1-1e-6,
                                 out_of_bounds="clip")
        iso.fit(Ps_va[:, 1], (yva == 1).astype(float))
        def _adv_probs(P_raw):
            p1 = iso.predict(P_raw[:, 1])
            return np.stack([1 - p1, p1], axis=1)
        adv_name = "isotonic"
    else:
        from scipy.optimize import minimize
        def _nll(w):
            return _ll(_vector_probs(Ps_va, np.abs(w) + 1e-3), yva).mean()
        w0 = np.ones(K) / T_best
        w_best = np.abs(minimize(_nll, w0, method="Nelder-Mead",
                                 options={"maxiter": 400, "xatol": 1e-3,
                                          "fatol": 1e-4}).x) + 1e-3
        def _adv_probs(P_raw):
            return _vector_probs(P_raw, w_best)
        adv_name = "vector_scaling"
    Pa_va = _adv_probs(Ps_va)
    best_a = float(lams[int(np.argmin([_ll(l*Pa_va+(1-l)*Pc_va, yva).mean()
                                       for l in lams]))])
    Pt = _temp_probs(Ps, T_best)
    Pmt = best_t*Pt + (1-best_t)*Pc
    ll_t, ll_mt = _ll(Pt, yte), _ll(Pmt, yte)
    imp = ll_s - ll_m
    imp_t = ll_t - ll_mt
    Pa = _adv_probs(Ps)
    Pma = best_a*Pa + (1-best_a)*Pc
    ll_a, ll_ma = _ll(Pa, yte), _ll(Pma, yte)
    imp_a = ll_a - ll_ma
    Ptta = _temp_probs(_cloud_mean_proba(Xte), T_tta)
    ll_tta = _ll(Ptta, yte)
    imp_m_vs_tta = ll_tta - ll_ma          # positive => adv-mixture better
    # FLEXIBLE SOFTMAX-ONLY RECALIBRATOR (v9, Reviewer 2): Dirichlet
    # calibration or gradient boosting on the full log-softmax vector,
    # cross-fit on val; the mixture weight is chosen on out-of-fold val
    # predictions, so no in-sample fit leaks into the choice of lambda.
    from flex_calib import fit_best_flex
    fx = fit_best_flex(Ps_va, yva, K, seed)
    best_f = float(lams[int(np.argmin(
        [_ll(l*fx["oof_val"]+(1-l)*Pc_va, yva).mean() for l in lams]))])
    Pf = fx["model"].predict_proba(Ps)
    ll_f = _ll(Pf, yte)
    ll_mf = _ll(best_f*Pf + (1-best_f)*Pc, yte)
    imp_f = ll_f - ll_mf
    rng = np.random.default_rng(seed)
    boots = np.array([imp[rng.integers(0, len(imp), len(imp))].mean()
                      for _ in range(1000)])
    pred = Ps.argmax(1); err = pred != yte
    cell = dict(cond=cond, n_test=len(yte), n_classes=K,
                n_features=int(X.shape[1]), n_frozen=len(freeze),
                test_accuracy=round(acc, 4), best_lambda=best,
                logloss_softmax=round(float(ll_s.mean()), 4),
                logloss_mixture=round(float(ll_m.mean()), 4),
                improvement=round(float(imp.mean()), 4),
                ci95=[round(float(np.percentile(boots, 2.5)), 4),
                      round(float(np.percentile(boots, 97.5)), 4)],
                ece_softmax=round(_ece(Ps, yte), 4),
                ece_cloud=round(_ece(Pc, yte), 4),
                temperature=round(T_best, 3),
                logloss_tempscaled=round(float(ll_t.mean()), 4),
                best_lambda_over_temp=best_t,
                logloss_mixture_over_temp=round(float(ll_mt.mean()), 4),
                improvement_over_temp=round(float(imp_t.mean()), 4),
                logloss_tta_calibrated=round(float(ll_tta.mean()), 4),
                tta_temperature=round(T_tta, 3),
                mixture_minus_ttacal=round(float(imp_m_vs_tta.mean()), 4),
                ci95_mixture_vs_ttacal=[
                    round(float(np.percentile(
                        np.array([imp_m_vs_tta[rng.integers(0,
                                  len(imp_m_vs_tta), len(imp_m_vs_tta))
                                  ].mean() for _ in range(1000)]), q)), 4)
                    for q in (2.5, 97.5)],
                flex_calibrator=fx["name"],
                flex_oof_val_nll=fx["oof_nll"],
                logloss_flex=round(float(ll_f.mean()), 4),
                best_lambda_over_flex=best_f,
                improvement_over_flex=round(float(imp_f.mean()), 4),
                ci95_over_flex=[
                    round(float(np.percentile(
                        np.array([imp_f[rng.integers(0, len(imp_f),
                                  len(imp_f))].mean()
                                  for _ in range(1000)]), q)), 4)
                    for q in (2.5, 97.5)],
                adv_calibrator=adv_name,
                logloss_adv=round(float(ll_a.mean()), 4),
                best_lambda_over_adv=best_a,
                improvement_over_adv=round(float(imp_a.mean()), 4),
                ci95_over_adv=[
                    round(float(np.percentile(
                        np.array([imp_a[rng.integers(0, len(imp_a),
                                  len(imp_a))].mean()
                                  for _ in range(1000)]), q)), 4)
                    for q in (2.5, 97.5)],
                ci95_over_temp=[
                    round(float(np.percentile(
                        np.array([imp_t[rng.integers(0, len(imp_t),
                                  len(imp_t))].mean()
                                  for _ in range(1000)]), q)), 4)
                    for q in (2.5, 97.5)])
    if err.sum() >= 10:
        cell["truth_in_cloud_given_error"] = round(
            float(occ[np.arange(len(err)), yte][err].mean()), 4)
        top2 = np.argsort(-Ps, axis=1)[:, :2]
        cell["truth_in_top2_given_error"] = round(
            float((top2 == yte[:, None]).any(1)[err].mean()), 4)
    # Prop-1 diagnostics on a slice (cheap)
    sl = slice(0, min(600, len(Xte)))
    cfg = TabularCloudConfig(alpha=alpha, n_perturbations=64, seed=seed,
                             freeze_features=tuple(freeze))
    recs = analyze_measurement_error(
        Xte[sl], lambda Z: model.predict(np.asarray(Z, dtype=np.float32)),
        np.ones(Xte.shape[1], dtype=np.float32), cfg, K)
    diag = population_report(recs, yte[sl], K)
    for k in ("frac_clouds_multiway", "spearman_h_lfr_all"):
        cell[k] = round(diag[k], 4)
    return cell


def run_hunt(which=("digits", "letter", "adult", "covtype"), seed=0,
             cache=None, perturb="continuous"):
    data = load_datasets(which, cache)
    rep = {"perturb_rule": perturb}
    for name, val in data.items():
        if isinstance(val[0], str) and val[0] == "SKIP":
            rep[name] = {"skipped": val[1]}
            continue
        X, y, fz = val
        fz = fz if perturb == "continuous" else []
        t0 = time.time()
        rep[name] = {c: hunt_one(X, y, c, seed, freeze=fz) for c in
                     ("calibrated", "overfit")}
        rep[name]["overfit_noisy"] = hunt_one(X, y, "overfit", seed,
                                              label_noise=0.2, freeze=fz)
        rep[name]["frozen_columns"] = len(fz)
        rep[name]["runtime_s"] = round(time.time() - t0, 1)
        print(name, "done:", {c: dict(
            over_adv=(rep[name][c]["improvement_over_adv"],
                      rep[name][c]["ci95_over_adv"]),
            over_flex=(rep[name][c]["improvement_over_flex"],
                       rep[name][c]["ci95_over_flex"],
                       rep[name][c]["flex_calibrator"]))
            for c in ("calibrated", "overfit", "overfit_noisy")})
    return rep


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", default="digits,letter,adult,covtype")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--cache", default=None)
    ap.add_argument("--out", default="tabular_hunt.json")
    ap.add_argument("--perturb", choices=["continuous", "all"],
                    default="continuous",
                    help="continuous: hold binary/one-hot columns fixed "
                         "(default, valid data domain); all: v8 behaviour")
    a = ap.parse_args()
    rep = run_hunt(tuple(a.datasets.split(",")), a.seed, a.cache, a.perturb)
    json.dump(rep, open(a.out, "w"), indent=2)
    print("saved", a.out)
