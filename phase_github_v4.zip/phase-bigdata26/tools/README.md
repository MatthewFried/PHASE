# tools: camera-ready analyses

| File | Purpose |
|---|---|
| `itt_tables.py` | All-seed and gated paired comparisons between causal arms. Inputs are `FILE:SEEDS` (a range like `0-4`, a list, or `auto` to read `config.seeds`). Results are joined by seed ID; mismatched counts, conflicting values for a seed, and identical baselines under different seed IDs stop the script. Default gate: drop a seed pair when either arm's clean accuracy is more than 20 points below that seed's baseline (`--gate`); `--sens` adds other gates. Reports exact one-sided sign-flip p, bootstrap 95% CI over seeds, collapse counts, and dropped seed IDs. |
| `hlfr_diagnostic.py` | Why high-H and high-LFR removal differ: fraction of clouds with LFR above 1/2, multiway fraction, H - h2(LFR), top-k overlap of the two removal sets (same selection rule as the causal battery), ties at the cut and overlap under random tie-breaking, and a plug-in entropy check. Reads the `causal_scores_*.npz` files written by causal runs. |
| `run_tests.py` | Regression tests for both scripts. |
