"""
itt_tables (v2): all-seed vs non-collapsed paired comparisons, joined by
explicit seed ID.

Each input is FILE:SEEDS, where SEEDS is a range ("0-4"), a list
("5,6,7,8,9"), or "auto" (read config.seeds from the JSON; aa_reeval
files store it). Training seeds are 0-indexed. Results are joined by
(pool, arm, seed):
  - the number of seed IDs must equal the length of every arm array
  - a seed appearing in two files is accepted only if every shared arm
    has identical values there (a deterministic rerun; deduplicated and
    reported); otherwise the script stops with an error
  - two different seed IDs with identical baseline (robust, clean) values
    are reported as a suspected relabeled duplicate and stop the script

Collapse gate (per seed, per arm): clean accuracy more than GATE below the
same seed's baseline. The default GATE = 0.20 is the rule the manuscript
used for the ten-seed paired tests. --sens adds the same tests under other
gates as a sensitivity analysis. The arm table also shows the manuscript's
arm-level ranking flag (mean clean drop > 10 points or any seed > 20).

For every comparison A vs B: ALL-SEED and NON-COLLAPSED mean difference
(points), exact one-sided sign-flip p, n, bootstrap 95% CI over seeds, and
the seed IDs dropped.

Usage:
  python itt_tables.py \
    --pool c10 causal_A.json:0-4 causal_B.json:5-9 \
    --cmp c10 remove_high_lfr remove_class_random --sens 0.10 --out itt.json
"""
import argparse, json, sys
from itertools import product
import numpy as np


def parse_seeds(spec, d):
    if spec == "auto":
        s = d.get("config", {}).get("seeds")
        if s is None:
            sys.exit("seeds=auto but the JSON has no config.seeds; give them explicitly")
        return [int(x) for x in s]
    out = []
    for part in spec.split(","):
        if "-" in part:
            a, b = part.split("-"); out += list(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out


def load_pool(name, items):
    rob, cln, notes = {}, {}, []
    for it in items:
        if ":" not in it:
            sys.exit(f"[{name}] '{it}': give seeds as FILE:SEEDS")
        f, spec = it.rsplit(":", 1)
        d = json.load(open(f))
        seeds = parse_seeds(spec, d)
        if len(set(seeds)) != len(seeds):
            sys.exit(f"[{name}] duplicate seed IDs inside {f}")
        rk = "robust_acc" if "robust_acc" in d else "aa_robust_acc"
        for key, store in ((rk, rob), ("clean_acc", cln)):
            for arm, v in d[key].items():
                if len(v) != len(seeds):
                    sys.exit(f"[{name}] {f}: arm {arm} has {len(v)} values "
                             f"but {len(seeds)} seed IDs were given")
                for s, x in zip(seeds, v):
                    prev = store.setdefault(arm, {}).get(s)
                    if prev is not None and prev != x:
                        sys.exit(f"[{name}] seed {s} arm {arm}: conflicting "
                                 f"values {prev} vs {x} across files")
                    if prev is not None:
                        notes.append(f"seed {s} {arm} repeated identically "
                                     f"(deterministic rerun), kept once")
                    store[arm][s] = x
    b = rob["baseline"]; bc = cln["baseline"]
    seen = {}
    for s in b:
        key = (b[s], bc[s])
        if key in seen:
            sys.exit(f"[{name}] seeds {seen[key]} and {s} have identical "
                     f"baseline values {key}: suspected relabeled duplicate")
        seen[key] = s
    return rob, cln, sorted(set(notes))


def signflip(d):
    d = np.asarray(d, float); n = len(d); o = d.mean()
    if n > 16:
        rng = np.random.default_rng(0)
        s = rng.choice([-1, 1], size=(200000, n))
        return o, float(np.mean((d * s).mean(1) >= o - 1e-12)), n
    st = [np.mean(d * np.array(s)) for s in product([1, -1], repeat=n)]
    return o, float(np.mean([s >= o - 1e-12 for s in st])), n


def boot_ci(d, B=20000, seed=0):
    d = np.asarray(d, float)
    if len(d) < 2:
        return [None, None]
    rng = np.random.default_rng(seed)
    m = d[rng.integers(0, len(d), (B, len(d)))].mean(1)
    return [round(float(np.percentile(m, 2.5)) * 100, 2),
            round(float(np.percentile(m, 97.5)) * 100, 2)]


def test(rob, cln, A, B, gate):
    seeds = sorted(set(rob[A]) & set(rob[B]) & set(rob["baseline"]))
    a = np.array([rob[A][s] for s in seeds]); b = np.array([rob[B][s] for s in seeds])
    cb = np.array([cln["baseline"][s] for s in seeds])
    ca = np.array([cln[A][s] for s in seeds]); cbb = np.array([cln[B][s] for s in seeds])
    d = a - b
    coll = ((cb - ca) > gate) | ((cb - cbb) > gate)
    o, p, n = signflip(d)
    rec = dict(A=A, B=B, seeds=seeds,
               all_seed=dict(diff=round(o * 100, 2), p=round(p, 4), n=n,
                             ci95=boot_ci(d)),
               gate=gate, dropped_seeds=[s for s, c in zip(seeds, coll) if c])
    if (~coll).sum() >= 2:
        og, pg, ng = signflip(d[~coll])
        rec["noncollapsed"] = dict(diff=round(og * 100, 2), p=round(pg, 4),
                                   n=ng, ci95=boot_ci(d[~coll]))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pool", nargs="+", action="append", required=True,
                    help="NAME file1.json:SEEDS [file2.json:SEEDS ...]")
    ap.add_argument("--cmp", nargs=3, action="append", default=[],
                    help="NAME armA armB")
    ap.add_argument("--gate", type=float, default=0.20)
    ap.add_argument("--sens", type=float, nargs="*", default=[0.10])
    ap.add_argument("--out", default="itt_tables.json")
    a = ap.parse_args()
    pools = {p[0]: load_pool(p[0], p[1:]) for p in a.pool}
    out = {}
    for name, (rob, cln, notes) in pools.items():
        seeds = sorted(rob["baseline"])
        cb = np.array([cln["baseline"][s] for s in seeds])
        arms = {}
        for arm in rob:
            ss = sorted(rob[arm])
            c = np.array([cln[arm][s] for s in ss]); r = np.array([rob[arm][s] for s in ss])
            drop = np.array([cln["baseline"][s] for s in ss]) - c
            arms[arm] = dict(n_seeds=len(ss),
                             collapsed=int((drop > a.gate).sum()),
                             collapsed_seeds=[s for s, x in zip(ss, drop) if x > a.gate],
                             manuscript_arm_flag=bool(drop.mean() > 0.10 or (drop > 0.20).any()),
                             clean_mean=round(float(c.mean()) * 100, 2),
                             robust_mean=round(float(r.mean()) * 100, 2))
        out[name] = dict(seeds=seeds, notes=notes, arms=arms, comparisons=[])
        print(f"\n=== {name}: seeds {seeds}")
        for nt in notes[:5]:
            print("   note:", nt)
        print(f"  {'arm':24s} {'collapsed':>10s} {'clean':>7s} {'robust':>7s}  arm-flag")
        for arm, r in arms.items():
            print(f"  {arm:24s} {r['collapsed']:>4d}/{r['n_seeds']:<5d} "
                  f"{r['clean_mean']:7.2f} {r['robust_mean']:7.2f}  "
                  f"{'yes' if r['manuscript_arm_flag'] else ''}")
    for name, A, B in a.cmp:
        rob, cln, _ = pools[name]
        for g in [a.gate] + list(a.sens):
            rec = test(rob, cln, A, B, g)
            out[name]["comparisons"].append(rec)
            nc = rec.get("noncollapsed", {})
            tag = "" if g == a.gate else f" [sensitivity gate {g*100:.0f}]"
            print(f"  [{name}] {A} vs {B}{tag}: ALL {rec['all_seed']['diff']:+.2f} "
                  f"CI{rec['all_seed']['ci95']} p={rec['all_seed']['p']} "
                  f"n={rec['all_seed']['n']} | NON-COLLAPSED {nc.get('diff')} "
                  f"CI{nc.get('ci95')} p={nc.get('p')} n={nc.get('n')} "
                  f"dropped={rec['dropped_seeds']}")
    json.dump(out, open(a.out, "w"), indent=1)
    print("\nsaved", a.out)


if __name__ == "__main__":
    main()
