"""Regression tests for phase_tools. Run: python run_tests.py"""
import json, os, subprocess, sys, tempfile
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable


def run(args):
    return subprocess.run([PY, os.path.join(HERE, args[0])] + args[1:],
                          capture_output=True, text=True)


def causal_json(path, base_r, lfr_r, base_c, lfr_c):
    json.dump(dict(robust_acc=dict(baseline=base_r, remove_high_lfr=lfr_r),
                   clean_acc=dict(baseline=base_c, remove_high_lfr=lfr_c)),
              open(path, "w"))


def test_itt(tmp):
    a = os.path.join(tmp, "a.json"); b = os.path.join(tmp, "b.json")
    causal_json(a, [.10, .11], [.13, .15], [.90, .91], [.89, .50])
    causal_json(b, [.12, .13], [.16, .14], [.92, .93], [.90, .92])
    # 1. join by seed: file order must not matter
    o1, o2 = os.path.join(tmp, "o1.json"), os.path.join(tmp, "o2.json")
    r1 = run(["itt_tables.py", "--pool", "p", f"{a}:0-1", f"{b}:2-3",
              "--cmp", "p", "remove_high_lfr", "baseline", "--out", o1])
    r2 = run(["itt_tables.py", "--pool", "p", f"{b}:2-3", f"{a}:0-1",
              "--cmp", "p", "remove_high_lfr", "baseline", "--out", o2])
    assert r1.returncode == 0 and r2.returncode == 0, r1.stderr + r2.stderr
    c1 = json.load(open(o1))["p"]["comparisons"][0]
    c2 = json.load(open(o2))["p"]["comparisons"][0]
    assert c1["all_seed"] == c2["all_seed"], (c1, c2)
    # seed 1 has a 41-point clean drop -> dropped under the 20-point gate
    assert c1["dropped_seeds"] == [1], c1["dropped_seeds"]
    assert c1["noncollapsed"]["n"] == 3
    # 2. missing seed spec is refused
    assert run(["itt_tables.py", "--pool", "p", a]).returncode != 0
    # 3. wrong number of seed IDs is refused
    assert run(["itt_tables.py", "--pool", "p", f"{a}:0-2"]).returncode != 0
    # 4. same seed in two files with different values is refused
    assert run(["itt_tables.py", "--pool", "p", f"{a}:0-1", f"{b}:1-2"]).returncode != 0
    # 5. identical rerun of the same seeds is deduplicated, not double-counted
    r = run(["itt_tables.py", "--pool", "p", f"{a}:0-1", f"{a}:0-1",
             "--cmp", "p", "remove_high_lfr", "baseline", "--out", o1])
    assert r.returncode == 0, r.stderr
    assert json.load(open(o1))["p"]["comparisons"][0]["all_seed"]["n"] == 2
    # 6. same data under two different seed labels is refused
    assert run(["itt_tables.py", "--pool", "p", f"{a}:0-1", f"{a}:5-6"]).returncode != 0
    print("itt_tables: ok")


def h2(q):
    q = np.asarray(q, float); o = np.zeros_like(q); m = (q > 0) & (q < 1)
    o[m] = -(q[m]*np.log(q[m]) + (1-q[m])*np.log(1-q[m])); return o


def test_hlfr(tmp):
    rng = np.random.default_rng(0); n = 3000; m = 64
    lfr = rng.integers(0, 40, n) / m
    H = h2(lfr)                              # all-binary plug-in clouds
    multi = rng.random(n) < 0.3              # add multiway mass
    H[multi] += lfr[multi] * 0.4
    H[:200] = np.nan; lfr[:200] = np.nan
    p = os.path.join(tmp, "causal_scores_toy_seed0.npz")
    np.savez(p, indices=rng.permutation(n), h_basin=H, lfr=lfr)
    out = os.path.join(tmp, "h.json")
    r = run(["hlfr_diagnostic.py", "--files", p, "--n_rm", "500", "--out", out])
    assert r.returncode == 0, r.stderr
    rec = json.load(open(out))["per_file"][0]
    assert rec["entropy_estimator"] == "plug-in"
    assert abs(rec["frac_multiway"] - np.mean(multi[200:] & (lfr[200:] > 0))) < 1e-9
    assert rec["tie_LFR_set"]["n_tied_at_cut"] > 0
    # Miller-Madow-shifted entropies must NOT be reported as plug-in
    np.savez(p, indices=np.arange(n), h_basin=h2(np.nan_to_num(lfr)) + 1/128,
             lfr=np.nan_to_num(lfr))
    r = run(["hlfr_diagnostic.py", "--files", p, "--n_rm", "500", "--out", out])
    assert json.load(open(out))["per_file"][0]["entropy_estimator"] == "UNVERIFIED"
    # constant scores: correlations are null and the JSON stays valid
    np.savez(p, indices=np.arange(n), h_basin=np.zeros(n), lfr=np.zeros(n))
    r = run(["hlfr_diagnostic.py", "--files", p, "--n_rm", "500", "--out", out])
    assert r.returncode == 0, r.stderr
    txt = open(out).read(); assert "NaN" not in txt
    rec = json.loads(txt)["per_file"][0]
    assert rec["spearman_h_lfr_all"] is None and rec["degenerate_scores"]
    print("hlfr_diagnostic: ok")


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as t:
        test_itt(t); test_hlfr(t)
    print("ALL PASS")
