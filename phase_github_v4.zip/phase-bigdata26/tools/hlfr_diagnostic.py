"""
hlfr_diagnostic: why does high-H removal differ from high-LFR removal?

Reads the per-seed score dumps written by the causal battery
(causal_scores_<dataset>_seed<k>.npz: indices, h_basin, lfr, ...) and
reports, per file and pooled per dataset:

  - n_valid: clean-correct scored samples (non-NaN)
  - frac_lfr_gt_half: fraction with LFR > 1/2. Above 1/2 the binary
    entropy h2(LFR) decreases while LFR increases, so H and LFR stop
    ranking samples the same way even for purely binary clouds.
  - frac_multiway: fraction whose cloud escaped to >= 2 classes, detected
    exactly as H - h2(LFR) > 1e-9 (Proposition 1: H = h2(q) + q*H(q~)).
  - excess = H - h2(LFR): the multiway contribution, summarized overall
    and among multiway clouds (mean, quantiles).
  - top-k overlap between the H-selected and LFR-selected removal sets,
    reproduced with the same rule as run_causal_intervention
    (np.argsort over the valid scores, last n_rm indices).
  - what the two removal sets contain (mean LFR, frac LFR > 1/2, frac
    multiway) and why samples are in one set but not the other.
  - Spearman(H, LFR) overall and restricted to LFR <= 1/2.

Usage:
  python hlfr_diagnostic.py --files "path/to/causal_scores_cifar10_seed*.npz" \
      --n_rm 10000 --out hlfr_cifar10.json
"""
import argparse, glob, json, os, re
import numpy as np


def h2(q):
    q = np.asarray(q, dtype=np.float64)
    out = np.zeros_like(q)
    m = (q > 0) & (q < 1)
    out[m] = -(q[m] * np.log(q[m]) + (1 - q[m]) * np.log(1 - q[m]))
    return out


def spearman(a, b):
    """None (JSON null) when undefined: too few points or a constant input."""
    from scipy.stats import spearmanr
    if len(a) < 3 or np.ptp(a) == 0 or np.ptp(b) == 0:
        return None
    r = float(spearmanr(a, b).statistic)
    return r if np.isfinite(r) else None


def tie_stability(score, valid, n_rm, other_set, vid, reps=20, seed=0):
    """Overlap of a top-n_rm set with other_set when ties at the cut are
    broken at random instead of by argsort position."""
    sv = score[valid]
    cut = np.sort(sv)[-n_rm]
    above = vid[sv > cut]; at = vid[sv == cut]
    need = n_rm - len(above)
    rng = np.random.default_rng(seed); ov = []
    for _ in range(reps):
        pick = rng.choice(at, need, replace=False)
        sel = set(above.tolist()) | set(pick.tolist())
        ov.append(len(sel & other_set) / n_rm)
    return dict(n_above_cut=int(len(above)), n_tied_at_cut=int(len(at)),
                n_taken_from_tie=int(need),
                overlap_min=round(float(min(ov)), 4),
                overlap_max=round(float(max(ov)), 4))


def removal_set(score, indices, valid, n_rm):
    # identical to reviewer_proof.run_causal_intervention:
    # order = np.argsort(scores[mn][valid]); valid_idx[order[-n_rm:]]
    valid_idx = indices[valid]
    order = np.argsort(score[valid])
    return valid_idx[order[-n_rm:]]


def describe(mask_sel, lfr, excess):
    return dict(n=int(mask_sel.sum()),
                mean_lfr=round(float(lfr[mask_sel].mean()), 4),
                frac_lfr_gt_half=round(float((lfr[mask_sel] > 0.5).mean()), 4),
                frac_multiway=round(float((excess[mask_sel] > 1e-9).mean()), 4))


def analyze(path, n_rm):
    d = np.load(path)
    idx, H, L = d["indices"], d["h_basin"], d["lfr"]
    valid = ~np.isnan(H)
    n_valid = int(valid.sum())
    k = min(n_rm, n_valid)
    Hv, Lv = H[valid], L[valid]
    ex = Hv - h2(Lv)
    multi = ex > 1e-9
    rec = dict(file=os.path.basename(path), n_valid=n_valid, n_rm=k,
               frac_lfr_zero=round(float((Lv == 0).mean()), 4),
               frac_lfr_gt_half=round(float((Lv > 0.5).mean()), 4),
               frac_multiway=round(float(multi.mean()), 4),
               min_excess=float(ex.min()),
               excess_mean_all=round(float(ex.mean()), 5),
               excess_mean_multiway=(round(float(ex[multi].mean()), 4)
                                     if multi.any() else 0.0),
               excess_quantiles_multiway=(
                   [round(float(x), 4) for x in
                    np.quantile(ex[multi], [0.1, 0.25, 0.5, 0.75, 0.9])]
                   if multi.any() else []),
               spearman_h_lfr_all=spearman(Hv, Lv),
               spearman_h_lfr_le_half=spearman(Hv[Lv <= 0.5], Lv[Lv <= 0.5]))
    setH = set(removal_set(H, idx, valid, k).tolist())
    setL = set(removal_set(L, idx, valid, k).tolist())
    rec["topk_overlap_h_lfr"] = round(len(setH & setL) / k, 4)
    # entropy estimator check: plug-in entropy gives H == h2(LFR) exactly
    # on binary clouds; a Miller-Madow offset would push every LFR>0
    # sample above zero excess.
    pos = (Lv > 0) & (Lv < 1)
    rec["frac_lfr_pos_with_zero_excess"] = (
        round(float((np.abs(ex[pos]) < 1e-9).mean()), 4) if pos.any() else None)
    rec["entropy_estimator"] = ("plug-in" if pos.any() and
                                (np.abs(ex[pos]) < 1e-9).any() else "UNVERIFIED")
    rec["degenerate_scores"] = bool(np.ptp(Hv) == 0 or np.ptp(Lv) == 0)
    vid_all = idx[valid]
    rec["tie_LFR_set"] = tie_stability(L, valid, k, setH, vid_all, seed=1)
    rec["tie_H_set"] = tie_stability(H, valid, k, setL, vid_all, seed=2)
    # per-sample lookup aligned with the valid arrays
    vid = idx[valid]
    inH = np.isin(vid, list(setH)); inL = np.isin(vid, list(setL))
    rec["H_set"] = describe(inH, Lv, ex)
    rec["LFR_set"] = describe(inL, Lv, ex)
    rec["only_LFR"] = describe(inL & ~inH, Lv, ex) if (inL & ~inH).any() else {}
    rec["only_H"] = describe(inH & ~inL, Lv, ex) if (inH & ~inL).any() else {}
    # LFR threshold of the LFR set (ties at the cut matter: LFR is k/n)
    rec["lfr_cut"] = round(float(Lv[inL].min()), 4)
    rec["frac_valid_at_lfr_cut"] = round(float((Lv == Lv[inL].min()).mean()), 4)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--files", required=True,
                    help="glob for causal_scores_*.npz (quote it)")
    ap.add_argument("--n_rm", type=int, default=10000)
    ap.add_argument("--out", default="hlfr_diagnostic.json")
    a = ap.parse_args()
    files = sorted(glob.glob(a.files))
    if not files:
        raise SystemExit(f"no files match {a.files}")
    recs = [analyze(f, a.n_rm) for f in files]
    by_ds = {}
    for r in recs:
        m = re.search(r"causal_scores_(\w+?)_seed", r["file"])
        by_ds.setdefault(m.group(1) if m else "unknown", []).append(r)
    summary = {}
    for ds, rs in by_ds.items():
        keys = ("frac_lfr_gt_half", "frac_multiway", "excess_mean_multiway",
                "topk_overlap_h_lfr", "spearman_h_lfr_all",
                "spearman_h_lfr_le_half")
        def _agg(k):
            v = [r[k] for r in rs if r[k] is not None]
            return ([round(float(np.mean(v)), 4), round(float(np.min(v)), 4),
                     round(float(np.max(v)), 4)] if v else None)
        summary[ds] = {k: _agg(k) for k in keys}
        summary[ds]["n_files"] = len(rs)
        summary[ds]["H_set_frac_lfr_gt_half"] = round(float(np.mean(
            [r["H_set"]["frac_lfr_gt_half"] for r in rs])), 4)
        summary[ds]["LFR_set_frac_lfr_gt_half"] = round(float(np.mean(
            [r["LFR_set"]["frac_lfr_gt_half"] for r in rs])), 4)
        summary[ds]["H_set_frac_multiway"] = round(float(np.mean(
            [r["H_set"]["frac_multiway"] for r in rs])), 4)
        summary[ds]["LFR_set_frac_multiway"] = round(float(np.mean(
            [r["LFR_set"]["frac_multiway"] for r in rs])), 4)
    for r in recs:
        print(f"{r['file']}: valid={r['n_valid']} LFR>1/2={r['frac_lfr_gt_half']} "
              f"multiway={r['frac_multiway']} overlap={r['topk_overlap_h_lfr']} "
              f"| H-set LFR>1/2={r['H_set']['frac_lfr_gt_half']} "
              f"LFR-set LFR>1/2={r['LFR_set']['frac_lfr_gt_half']} "
              f"| min(H-h2)={r['min_excess']:.2e} estimator={r['entropy_estimator']} "
              f"| LFR-set ties at cut: {r['tie_LFR_set']['n_tied_at_cut']} "
              f"(took {r['tie_LFR_set']['n_taken_from_tie']}), overlap under "
              f"random tie-break {r['tie_LFR_set']['overlap_min']}-"
              f"{r['tie_LFR_set']['overlap_max']}")
    print("\nSUMMARY [mean, min, max] over seeds:")
    print(json.dumps(summary, indent=1))
    json.dump(dict(per_file=recs, summary=summary), open(a.out, "w"), indent=1)
    print("saved", a.out)


if __name__ == "__main__":
    main()
