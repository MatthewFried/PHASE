"""
WSB Framework - Main Entry Point
==================================
Command-line interface for running experiments.
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

from .config import (
    OptionAConfig, OptionBConfig, OptionCConfig,
    ToySystemConfig, CompressionConfig, AblationConfig,
)
from .utils import setup_logger, ResultsTracker, save_results


def download_datasets(args, logger):
    """STAGE 0: download BOTH splits of every dataset and verify (writes manifest)."""
    from .data import download_and_verify
    return download_and_verify(args.datasets.split(','), args.data_dir,
                               getattr(args, 'output_dir', './wsb_results'), logger)


def _require_data(args, logger, dataset=None):
    """Gate: refuse to run a data-consuming stage without a passing manifest
    for the SAME resolved data_dir the stage will read."""
    from .data import assert_manifest
    ds = dataset or getattr(args, 'dataset', 'cifar10')
    assert_manifest(getattr(args, 'output_dir', './wsb_results'), ds,
                    data_dir=getattr(args, 'data_dir', None))
    logger.info(f"Data manifest OK for '{ds}'.")


# Every vision-data-consuming command must pass the gate (reviewer: "most
# secondary commands don't call _require_data at all").
DATA_COMMANDS = {
    "option_b", "baselines", "baselines_all", "naive_baselines",
    "naive_baselines_split", "naive_baselines_suite", "naive_fails_suite",
    "table4", "table4_suite", "table5", "compression", "compression_split",
    "causal_intervention", "reviewer_proof", "bulletproof_suite",
    "hbasin_wins", "ablation_attack", "ablation_epsilon",
    "ablation_difficulty", "attack_transfer", "epsilon_stability",
    "model_transfer", "sample_complexity", "full"}


def _user_overrides(args, mapping):
    """Collect only the CLI arguments the user actually supplied (argparse
    defaults are None sentinels), so factory precedence is base defaults ->
    env/dataset defaults -> explicit user overrides."""
    out = {}
    for arg_name, field in mapping.items():
        v = getattr(args, arg_name, None)
        if v is not None:
            out[field] = v
    return out


def run_option_a_cmd(args, logger, tracker):
    """Run Option A from command line."""
    from .config import resolve_option_a_config
    config = resolve_option_a_config(
        env_name=args.env,
        **_user_overrides(args, {
            'algo': 'algo', 'total_timesteps': 'total_timesteps',
            'n_seeds': 'n_seeds', 'epsilon': 'epsilon',
            'n_perturbations': 'n_perturbations',
            'checkpoint_interval': 'checkpoint_interval'}),
        output_dir=args.output_dir,
    )
    
    from .rl import run_option_a
    results = run_option_a(config, logger, tracker)
    
    filepath = save_results(results, args.output_dir, f"option_a_{args.env}_{args.algo}")
    logger.info(f"Results saved to {filepath}")
    
    return results


def run_option_b_cmd(args, logger, tracker):
    """Run Option B from command line. --wsb_epsilon sets the PHASE
    perturbation radius (field wsb_epsilon) and --attack_epsilon the PGD
    budget; the old --epsilon flag was wired to OptionBConfig.epsilon, which
    the Option B analysis never reads (review point 3)."""
    from .config import resolve_option_b_config
    if getattr(args, 'seed_list', None):
        args.seed_list = [int(x) for x in args.seed_list.split(',')]
    config = resolve_option_b_config(
        dataset=args.dataset,
        **_user_overrides(args, {
            'model': 'model_name',
            'adversarial_training': 'adversarial_training',
            'seed_list': 'seed_list',
            'train_epochs': 'train_epochs', 'n_seeds': 'n_seeds',
            'wsb_epsilon': 'wsb_epsilon', 'attack_epsilon': 'attack_epsilon',
            'n_perturbations': 'n_perturbations',
            'n_test_samples': 'n_test_samples'}),
        data_dir=args.data_dir,
        output_dir=args.output_dir,
    )
    
    from .adversarial import run_option_b
    results = run_option_b(config, logger, tracker)
    
    filepath = save_results(results, args.output_dir, f"option_b_{args.dataset}_{args.adversarial_training}")
    logger.info(f"Results saved to {filepath}")
    
    return results


GAME_SWEEP_VARS = {"stag_hunt": "stag_payoff",
                   "battle_of_sexes": "bos_high",
                   "prisoners_dilemma": "pd_temptation"}

GAME_SWEEP_RANGES = {"bos_high": (1.5, 6.0), "pd_temptation": (3.5, 8.0)}


def run_option_c_cmd(args, logger, tracker):
    """Run Option C from command line. The sweep variable defaults to one
    that actually affects the requested game (previously the config default
    'stag_payoff' reached BoS/PD and the no-op guard correctly refused it,
    so those games never ran from this entry point)."""
    sweep_var = getattr(args, 'param_sweep_var', None) or GAME_SWEEP_VARS.get(args.game)
    if sweep_var is None:
        raise ValueError(f"No default sweep variable for game '{args.game}'; "
                         f"pass --param_sweep_var explicitly.")
    kw = dict(
        game_type=args.game,
        dynamics=args.dynamics,
        n_seeds=args.n_seeds,
        epsilon=getattr(args, 'epsilon', 0.1),
        n_perturbations=getattr(args, 'n_perturbations', 50),
        param_sweep_steps=args.param_sweep_steps,
        param_sweep_var=sweep_var,
        output_dir=args.output_dir,
    )
    if sweep_var in GAME_SWEEP_RANGES:
        kw['param_sweep_range'] = GAME_SWEEP_RANGES[sweep_var]
    logger.info(f"Sweep variable: {sweep_var}, range: "
                f"{kw.get('param_sweep_range', 'config default')}")
    config = OptionCConfig(**kw)
    
    from .games import run_option_c
    results = run_option_c(config, logger, tracker)
    
    filepath = save_results(results, args.output_dir, f"option_c_{args.game}_{args.dynamics}")
    logger.info(f"Results saved to {filepath}")
    
    return results


def run_toy_system_cmd(args, logger, tracker):
    """Run toy system validation."""
    config = ToySystemConfig(
        system_type=getattr(args, 'system_type', 'double_well'),
        epsilon=getattr(args, 'epsilon', 0.1),
        n_perturbations=getattr(args, 'n_perturbations', 100),
        output_dir=args.output_dir,
    )
    
    from .ablations import run_toy_system
    results = run_toy_system(config, logger)
    
    filepath = save_results(results, args.output_dir, "toy_system")
    logger.info(f"Results saved to {filepath}")
    
    return results


def run_compression_cmd(args, logger, tracker):
    """Run compression experiment."""
    from .config import DATASET_DEFAULTS as _DD
    ds = getattr(args, 'dataset', 'cifar10')
    kw = dict(
        dataset=ds,
        model_name=args.model or _DD.get(ds, {}).get('model_name', 'cifar_cnn'),
        n_test_samples=getattr(args, 'n_test_samples', 500),
        data_dir=getattr(args, 'data_dir', './data'),
        output_dir=args.output_dir,
    )
    te = getattr(args, 'train_epochs', None)
    if te is None:
        te = _DD.get(ds, {}).get('train_epochs', None)
    if te is not None:
        kw['train_epochs'] = te
    config = CompressionConfig(**kw)
    
    from .compression import run_compression
    results = run_compression(config, logger, tracker)
    
    filepath = save_results(results, args.output_dir, "compression")
    logger.info(f"Results saved to {filepath}")
    
    return results


def run_ablations_cmd(args, logger, tracker):
    """Run ablation studies."""
    config = AblationConfig(
        ablation_n_seeds=getattr(args, 'n_seeds', 3),
        output_dir=args.output_dir,
    )
    
    from .ablations import run_ablations
    results = run_ablations(config, logger)
    
    filepath = save_results(results, args.output_dir, "ablations")
    logger.info(f"Results saved to {filepath}")
    
    return results


def run_full_experiment(args, logger):
    """Run complete experiment suite."""
    logger.info("=" * 60)
    logger.info("WSB FRAMEWORK - FULL EXPERIMENT SUITE")
    logger.info("=" * 60)
    
    all_results = {}

    # STAGE 0: data download + verification (always first)
    class _DL: pass
    dl = _DL(); dl.datasets = "mnist,cifar10,cifar100,svhn"; dl.data_dir = args.data_dir; dl.output_dir = args.output_dir
    all_results["data_manifest"] = download_datasets(dl, logger)

    # STAGE 1: exact-system calibration
    from .calibration import run_all_calibration
    all_results["calibration"] = run_all_calibration(args.output_dir, logger)
    save_results(all_results["calibration"], args.output_dir, "calibration")

    # Toy system validation
    logger.info("\n" + "=" * 40 + "\n TOY SYSTEM VALIDATION\n" + "=" * 40)
    toy_config = ToySystemConfig(output_dir=args.output_dir)
    from .ablations import run_toy_system
    all_results["toy_system"] = run_toy_system(toy_config, logger)
    
    # Option A: RL
    for env in ["CartPole-v1", "Acrobot-v1"]:
        logger.info(f"\n{'=' * 40}\n OPTION A: {env}\n{'=' * 40}")
        a_config = OptionAConfig(env_name=env, n_seeds=args.n_seeds, output_dir=args.output_dir)
        from .rl import run_option_a
        tracker = ResultsTracker(f"option_a_{env}", args.output_dir)
        all_results[f"option_a_{env}"] = run_option_a(a_config, logger, tracker)
        tracker.save()
    
    # Option B: Adversarial
    for dataset in ["mnist", "cifar10"]:
        for at in ["none", "pgd"]:
            logger.info(f"\n{'=' * 40}\n OPTION B: {dataset} ({at})\n{'=' * 40}")
            b_config = OptionBConfig(
                dataset=dataset, adversarial_training=at,
                n_seeds=args.n_seeds, data_dir=args.data_dir, output_dir=args.output_dir
            )
            from .adversarial import run_option_b
            tracker = ResultsTracker(f"option_b_{dataset}_{at}", args.output_dir)
            all_results[f"option_b_{dataset}_{at}"] = run_option_b(b_config, logger, tracker)
            tracker.save()
    
    # Option C: Games. Each game gets a sweep variable that actually affects
    # it; the previous default swept stag_payoff for every game, which is a
    # silent no-op for Prisoner's Dilemma (compute_h_basin now raises on
    # unsupported combinations, so this mapping is load-bearing).
    game_sweep_vars = {"stag_hunt": "stag_payoff",
                       "battle_of_sexes": "bos_high",
                       "prisoners_dilemma": "pd_temptation"}
    for game in ["stag_hunt", "battle_of_sexes", "prisoners_dilemma"]:
        logger.info(f"\n{'=' * 40}\n OPTION C: {game}\n{'=' * 40}")
        c_config = OptionCConfig(game_type=game, n_seeds=args.n_seeds,
                                 param_sweep_var=game_sweep_vars[game],
                                 output_dir=args.output_dir)
        from .games import run_option_c
        tracker = ResultsTracker(f"option_c_{game}", args.output_dir)
        all_results[f"option_c_{game}"] = run_option_c(c_config, logger, tracker)
        tracker.save()
    
    # Save combined results
    filepath = save_results(all_results, args.output_dir, "full_experiment")
    logger.info(f"\n{'=' * 60}")
    logger.info(f"FULL EXPERIMENT COMPLETE")
    logger.info(f"Results saved to {filepath}")
    
    return all_results


def main():
    parser = argparse.ArgumentParser(description="WSB Framework")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Download datasets
    dl_parser = subparsers.add_parser("download", help="STAGE 0: download + verify datasets (run FIRST)")
    dl_parser.add_argument("--datasets", type=str, default="mnist,cifar10,cifar100,svhn", help="Datasets to download")
    dl_parser.add_argument("--data_dir", type=str, default="./data", help="Data directory")
    dl_parser.add_argument("--output_dir", type=str, default="./wsb_results", help="Where the manifest is written")

    # Calibration (exact ground-truth systems; no data needed)
    cal_parser = subparsers.add_parser("calibration", help="Exact-system calibration: double-well, triple-well, parallel lines")
    cal_parser.add_argument("--quick", action="store_true", help="Smaller grids for a fast pass")
    cal_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Option A
    a_parser = subparsers.add_parser("option_a", help="Run Option A (RL)")
    a_parser.add_argument("--env", type=str, default="CartPole-v1", help="Environment")
    a_parser.add_argument("--algo", type=str, default="ppo", choices=["ppo", "dqn"])
    a_parser.add_argument("--total_timesteps", type=int, default=None)
    a_parser.add_argument("--n_seeds", type=int, default=5)
    a_parser.add_argument("--epsilon", type=float, default=None)
    a_parser.add_argument("--n_perturbations", type=int, default=None)
    a_parser.add_argument("--checkpoint_interval", type=int, default=None)
    a_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Option B
    b_parser = subparsers.add_parser("option_b", help="Run Option B (Adversarial)")
    b_parser.add_argument("--dataset", type=str, default="cifar10", choices=["mnist", "cifar10", "cifar100", "svhn"])
    b_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    b_parser.add_argument("--adversarial_training", type=str, default="none", choices=["none", "pgd", "trades"])
    b_parser.add_argument("--seed_list", type=str, default=None,
                          help="comma-separated explicit seeds, e.g. '2' or '6,7'")
    b_parser.add_argument("--train_epochs", type=int, default=None)
    b_parser.add_argument("--n_seeds", type=int, default=3)
    b_parser.add_argument("--wsb_epsilon", type=float, default=None,
                          help="PHASE perturbation radius (dataset default if omitted)")
    b_parser.add_argument("--attack_epsilon", type=float, default=None,
                          help="PGD attack budget (dataset default if omitted)")
    b_parser.add_argument("--n_perturbations", type=int, default=None)
    b_parser.add_argument("--n_test_samples", type=int, default=None)
    b_parser.add_argument("--data_dir", type=str, default="./data")
    b_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Option C
    c_parser = subparsers.add_parser("option_c", help="Run Option C (Games)")
    c_parser.add_argument("--game", type=str, default="stag_hunt", choices=["stag_hunt", "battle_of_sexes", "prisoners_dilemma", "matching_pennies"])
    c_parser.add_argument("--dynamics", type=str, default="replicator", choices=["replicator", "fictitious_play", "logit_response", "gradient_play"])
    c_parser.add_argument("--n_seeds", type=int, default=5)
    c_parser.add_argument("--epsilon", type=float, default=0.1)
    c_parser.add_argument("--n_perturbations", type=int, default=50)
    c_parser.add_argument("--param_sweep_steps", type=int, default=50)
    c_parser.add_argument("--param_sweep_var", type=str, default=None,
                          help="default: per-game (stag_payoff / bos_high / pd_temptation)")
    c_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Toy system
    toy_parser = subparsers.add_parser("toy", help="Run toy system validation")
    toy_parser.add_argument("--system_type", type=str, default="double_well")
    toy_parser.add_argument("--epsilon", type=float, default=0.1)
    toy_parser.add_argument("--n_perturbations", type=int, default=100)
    toy_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Compression
    comp_parser = subparsers.add_parser("compression", help="Run compression experiment")
    comp_parser.add_argument("--dataset", type=str, default="cifar10")
    comp_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    comp_parser.add_argument("--n_test_samples", type=int, default=500)
    comp_parser.add_argument("--train_epochs", type=int, default=None,
                             help="default: the dataset's train_epochs")
    comp_parser.add_argument("--data_dir", type=str, default="./data")
    comp_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Ablations
    abl_parser = subparsers.add_parser("ablations", help="Run ablation studies")
    abl_parser.add_argument("--n_seeds", type=int, default=3)
    abl_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Full experiment
    full_parser = subparsers.add_parser("full", help="Run full experiment suite")
    full_parser.add_argument("--n_seeds", type=int, default=10)
    full_parser.add_argument("--data_dir", type=str, default="./data")
    full_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Reviewer-proof experiments
    review_parser = subparsers.add_parser("reviewer_proof", help="Run reviewer-proof additions")
    review_parser.add_argument("--dataset", type=str, default="cifar10")
    review_parser.add_argument("--n_seeds", type=int, default=3)
    review_parser.add_argument("--data_dir", type=str, default="./data")
    review_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Sample complexity study
    sample_parser = subparsers.add_parser("sample_complexity", help="Run sample complexity study")
    sample_parser.add_argument("--dataset", type=str, default="cifar10")
    sample_parser.add_argument("--n_samples", type=int, default=100)
    sample_parser.add_argument("--data_dir", type=str, default="./data")
    sample_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Baseline comparison
    baseline_parser = subparsers.add_parser("baselines", help="Compare H_basin to baselines")
    baseline_parser.add_argument("--dataset", type=str, default="cifar10")
    baseline_parser.add_argument("--n_samples", type=int, default=500)
    baseline_parser.add_argument("--n_seeds", type=int, default=3, help="Number of seeds for CI")
    baseline_parser.add_argument("--data_dir", type=str, default="./data")
    baseline_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # Multi-dataset baselines
    baseline_all_parser = subparsers.add_parser("baselines_all", help="Run baselines on all datasets")
    baseline_all_parser.add_argument("--n_samples", type=int, default=500)
    baseline_all_parser.add_argument("--n_seeds", type=int, default=3)
    baseline_all_parser.add_argument("--data_dir", type=str, default="./data")
    baseline_all_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW: Naive perturbation baselines (addresses reviewer concern)
    naive_parser = subparsers.add_parser("naive_baselines", help="Compare PHASE to naive perturbation baselines")
    naive_parser.add_argument("--dataset", type=str, default="cifar10", choices=["mnist", "cifar10", "cifar100", "svhn"])
    naive_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    naive_parser.add_argument("--n_seeds", type=int, default=5)
    naive_parser.add_argument("--n_test_samples", type=int, default=1000)
    naive_parser.add_argument("--n_perturbations", type=int, default=64)
    naive_parser.add_argument("--train_epochs", type=int, default=100)
    naive_parser.add_argument("--data_dir", type=str, default="./data")
    naive_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW: Naive baselines suite (multiple datasets/models)
    naive_suite_parser = subparsers.add_parser("naive_baselines_suite", help="Run naive baselines on multiple configs")
    naive_suite_parser.add_argument("--datasets", type=str, default="cifar10,cifar100")
    naive_suite_parser.add_argument("--models", type=str, default="cifar_cnn,resnet18")
    naive_suite_parser.add_argument("--n_seeds", type=int, default=5)
    naive_suite_parser.add_argument("--n_test_samples", type=int, default=1000)
    naive_suite_parser.add_argument("--train_epochs", type=int, default=100)
    naive_suite_parser.add_argument("--data_dir", type=str, default="./data")
    naive_suite_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW: Table 4 expansion (CIFAR-100, ResNet-18)
    table4_parser = subparsers.add_parser("table4", help="Run Table 4 experiment")
    table4_parser.add_argument("--dataset", type=str, default="cifar10", choices=["mnist", "cifar10", "cifar100", "svhn"])
    table4_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    table4_parser.add_argument("--training", type=str, default="standard", choices=["standard", "pgd", "trades"])
    table4_parser.add_argument("--n_seeds", type=int, default=5)
    table4_parser.add_argument("--n_test_samples", type=int, default=1000)
    table4_parser.add_argument("--train_epochs", type=int, default=100)
    table4_parser.add_argument("--data_dir", type=str, default="./data")
    table4_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW: Table 4 suite (multiple experiments)
    table4_suite_parser = subparsers.add_parser("table4_suite", help="Run full Table 4 expansion")
    table4_suite_parser.add_argument("--n_seeds", type=int, default=5)
    table4_suite_parser.add_argument("--n_test_samples", type=int, default=1000)
    table4_suite_parser.add_argument("--train_epochs", type=int, default=100)
    table4_suite_parser.add_argument("--data_dir", type=str, default="./data")
    table4_suite_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW: Table 5 verification
    table5_parser = subparsers.add_parser("table5", help="Run Table 5 baseline comparison")
    table5_parser.add_argument("--dataset", type=str, default="cifar10", choices=["mnist", "cifar10", "cifar100", "svhn"])
    table5_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    table5_parser.add_argument("--n_seeds", type=int, default=10)
    table5_parser.add_argument("--n_test_samples", type=int, default=1000)
    table5_parser.add_argument("--train_epochs", type=int, default=100)
    table5_parser.add_argument("--data_dir", type=str, default="./data")
    table5_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V27: Compression split comparison
    comp_split_parser = subparsers.add_parser("compression_split", help="Compare metrics for compression fragility prediction")
    comp_split_parser.add_argument("--dataset", type=str, default="cifar10", choices=["mnist", "cifar10", "cifar100", "svhn"])
    comp_split_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    comp_split_parser.add_argument("--n_test_samples", type=int, default=1000)
    comp_split_parser.add_argument("--train_epochs", type=int, default=100)
    comp_split_parser.add_argument("--data_dir", type=str, default="./data")
    comp_split_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V27: Games null test (Prisoner's Dilemma)
    games_null_parser = subparsers.add_parser("games_null", help="Games null test - PD should have H_basin~0")
    games_null_parser.add_argument("--n_perturbations", type=int, default=100)
    games_null_parser.add_argument("--n_seeds", type=int, default=10)
    games_null_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V27: Causal intervention
    causal_parser = subparsers.add_parser("causal_intervention", help="Remove high-metric samples, measure ASR reduction")
    causal_parser.add_argument("--score_fraction", type=float, default=1.0, help="Fraction of trainset to score (1.0 = full trainset; anything else must be reported)")
    causal_parser.add_argument("--arm_subset", type=str, default="full", choices=["full", "controls", "valuation", "minimal"], help="controls: 6 trainings/seed; valuation: adds EL2N/GraNd/forgetting arms (9/seed); minimal: baseline+LFR+random+class-random for radius robustness")
    causal_parser.add_argument("--wsb_epsilon", type=float, default=None, help="instrument cloud radius for scoring (default 0.1)")
    causal_parser.add_argument("--seed_list", type=str, default=None, help="comma-separated explicit seeds, e.g. '5,6,7,8,9' (0-indexed, fresh seeds extend prior runs)")
    causal_parser.add_argument("--dataset", type=str, default="cifar10", choices=["mnist", "cifar10", "cifar100", "svhn"])
    causal_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    causal_parser.add_argument("--n_test_samples", type=int, default=500)
    causal_parser.add_argument("--train_epochs", type=int, default=50)
    causal_parser.add_argument("--n_seeds", type=int, default=3)
    causal_parser.add_argument("--data_dir", type=str, default="./data")
    causal_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    causal_parser.add_argument("--train_mode", type=str, default="standard",
                               choices=["standard", "pgd", "trades"],
                               help="arm training: pgd/trades give the primary outcome headroom")
    causal_parser.add_argument("--attack_epsilon", type=float, default=None,
                               help="eval attack budget (default: dataset attack_epsilon)")
    causal_parser.add_argument("--attack_steps", type=int, default=20)
    
    # NEW V27: Bulletproof suite (all new experiments)
    bullet_parser = subparsers.add_parser("bulletproof_suite", help="Run all bulletproof experiments")
    bullet_parser.add_argument("--data_dir", type=str, default="./data")
    bullet_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V28: Attack strength ablation
    attack_abl_parser = subparsers.add_parser("ablation_attack", help="Attack strength ablation (PGD-7/20/50/100)")
    attack_abl_parser.add_argument("--dataset", type=str, default="cifar10")
    attack_abl_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    attack_abl_parser.add_argument("--n_test_samples", type=int, default=1000)
    attack_abl_parser.add_argument("--train_epochs", type=int, default=100)
    attack_abl_parser.add_argument("--data_dir", type=str, default="./data")
    attack_abl_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V28: PHASE epsilon ablation
    eps_abl_parser = subparsers.add_parser("ablation_epsilon", help="PHASE epsilon ablation (0.05/0.1/0.15/0.2)")
    eps_abl_parser.add_argument("--dataset", type=str, default="cifar10")
    eps_abl_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    eps_abl_parser.add_argument("--n_test_samples", type=int, default=1000)
    eps_abl_parser.add_argument("--train_epochs", type=int, default=100)
    eps_abl_parser.add_argument("--data_dir", type=str, default="./data")
    eps_abl_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V28: Sample difficulty ablation
    diff_abl_parser = subparsers.add_parser("ablation_difficulty", help="Sample difficulty split (easy/hard)")
    diff_abl_parser.add_argument("--dataset", type=str, default="cifar10")
    diff_abl_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    diff_abl_parser.add_argument("--n_test_samples", type=int, default=2000)
    diff_abl_parser.add_argument("--train_epochs", type=int, default=100)
    diff_abl_parser.add_argument("--data_dir", type=str, default="./data")
    diff_abl_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V28: H_basin wins suite (all ablations)
    hbasin_wins_parser = subparsers.add_parser("hbasin_wins", help="Run all ablations to find when H_basin wins")
    hbasin_wins_parser.add_argument("--dataset", type=str, default="cifar10")
    hbasin_wins_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    hbasin_wins_parser.add_argument("--n_test_samples", type=int, default=1000)
    hbasin_wins_parser.add_argument("--train_epochs", type=int, default=100)
    hbasin_wins_parser.add_argument("--data_dir", type=str, default="./data")
    hbasin_wins_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # NEW V29: Naive baselines with sample difficulty split
    naive_split_parser = subparsers.add_parser("naive_baselines_split", help="Compare H_basin vs naive baselines on ALL splits")
    naive_split_parser.add_argument("--dataset", type=str, default="cifar10")
    naive_split_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    naive_split_parser.add_argument("--n_test_samples", type=int, default=2000)
    naive_split_parser.add_argument("--n_perturbations", type=int, default=64)
    naive_split_parser.add_argument("--train_epochs", type=int, default=100)
    naive_split_parser.add_argument("--data_dir", type=str, default="./data")
    naive_split_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # V30: Attack Transfer
    atk_transfer_parser = subparsers.add_parser("attack_transfer", help="V30: Test metric transfer across attack types")
    atk_transfer_parser.add_argument("--dataset", type=str, default="cifar10")
    atk_transfer_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    atk_transfer_parser.add_argument("--n_test_samples", type=int, default=1000)
    atk_transfer_parser.add_argument("--train_epochs", type=int, default=100)
    atk_transfer_parser.add_argument("--data_dir", type=str, default="./data")
    atk_transfer_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # V30: Epsilon Stability
    eps_stab_parser = subparsers.add_parser("epsilon_stability", help="V30: Test metric stability across epsilon values")
    eps_stab_parser.add_argument("--dataset", type=str, default="cifar10")
    eps_stab_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    eps_stab_parser.add_argument("--n_test_samples", type=int, default=None)
    eps_stab_parser.add_argument("--train_epochs", type=int, default=None)
    eps_stab_parser.add_argument("--data_dir", type=str, default="./data")
    eps_stab_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # V30: Model Transfer
    model_transfer_parser = subparsers.add_parser("model_transfer", help="V30: Test metric transfer across models")
    model_transfer_parser.add_argument("--dataset", type=str, default="cifar10")
    model_transfer_parser.add_argument("--n_test_samples", type=int, default=500)
    model_transfer_parser.add_argument("--train_epochs", type=int, default=100)
    model_transfer_parser.add_argument("--data_dir", type=str, default="./data")
    model_transfer_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # V30: Toy Validation
    toy_val_parser = subparsers.add_parser("toy_validation", help="V30: Toy system validation")
    toy_val_parser.add_argument("--n_samples", type=int, default=1000)
    toy_val_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    
    # V30: Naive Fails Suite (all experiments)
    naive_fails_parser = subparsers.add_parser("naive_fails_suite", help="V30: Run ALL naive metrics fail experiments")
    naive_fails_parser.add_argument("--dataset", type=str, default="cifar10")
    naive_fails_parser.add_argument("--model", type=str, default=None, choices=["simple_cnn", "cifar_cnn", "resnet18"], help="default: the dataset's model (mnist->simple_cnn, cifar*->cifar_cnn)")
    naive_fails_parser.add_argument("--n_test_samples", type=int, default=500)
    naive_fails_parser.add_argument("--train_epochs", type=int, default=100)
    naive_fails_parser.add_argument("--data_dir", type=str, default="./data")
    naive_fails_parser.add_argument("--output_dir", type=str, default="./wsb_results")
    ss_parser = subparsers.add_parser("score_stability")
    tp_parser = subparsers.add_parser("throughput_demo")
    aa_parser = subparsers.add_parser("aa_reeval")
    for p in (ss_parser, tp_parser, aa_parser):
        p.add_argument("--dataset", type=str, default="cifar10")
        p.add_argument("--model", type=str, default="cifar_cnn")
        p.add_argument("--train_epochs", type=int, default=50)
        p.add_argument("--data_dir", type=str, default="./data")
        p.add_argument("--output_dir", type=str, default="./wsb_results")
        p.add_argument("--seed", type=int, default=0)
    aa_parser.add_argument("--seed_list", type=str, default=None)
    aa_parser.add_argument("--n_seeds", type=int, default=5)
    aa_parser.add_argument("--attack_epsilon", type=float, default=0.00784)
    aa_parser.add_argument("--n_eval", type=int, default=1000)
    aa_parser.add_argument("--aa_version", type=str, default="apgd", choices=["apgd", "standard"])

    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Setup
    output_dir = getattr(args, 'output_dir', './wsb_results')
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    logger = setup_logger("wsb", output_dir)
    tracker = ResultsTracker(args.command, output_dir)
    
    logger.info(f"WSB Framework | Command: {args.command}")
    logger.info(f"Arguments: {vars(args)}")
    
    # Run command
    import time
    start = time.time()
    
    try:
        if args.command in DATA_COMMANDS:
            _require_data(args, logger)
            # Resolve the model from the dataset default when not given
            # explicitly (v32 bug: the argparse default 'cifar_cnn'
            # overrode the mnist default and crashed on 28x28 inputs).
            if hasattr(args, 'dataset'):
                from .config import DATASET_DEFAULTS as _DD
                dd = _DD.get(args.dataset, {})
                # Resolve every None-sentinel numeric the reviewer_proof
                # dispatchers pass straight through (v36 bug: epsilon_stability
                # crashed on train_epochs=None // 2; factories resolve these
                # for option_a/b but the direct-dispatch commands do not).
                if getattr(args, 'model', None) is None:
                    args.model = dd.get('model_name', 'cifar_cnn')
                    logger.info(f"Model resolved from dataset default: {args.model}")
                if getattr(args, 'train_epochs', 0) is None:
                    args.train_epochs = dd.get('train_epochs', 100)
                    logger.info(f"train_epochs resolved from dataset default: "
                                f"{args.train_epochs}")
                if getattr(args, 'n_test_samples', 0) is None:
                    args.n_test_samples = 1000
                    logger.info("n_test_samples resolved to 1000")
        if args.command == "download":
            download_datasets(args, logger)
        elif args.command == "calibration":
            from .calibration import run_all_calibration
            results = run_all_calibration(args.output_dir, logger, quick=args.quick)
            fp = save_results(results, args.output_dir, "calibration")
            logger.info(f"Calibration results saved to {fp}")
        elif args.command == "option_a":
            run_option_a_cmd(args, logger, tracker)
        elif args.command == "option_b":
            _require_data(args, logger)
            run_option_b_cmd(args, logger, tracker)
        elif args.command == "option_c":
            run_option_c_cmd(args, logger, tracker)
        elif args.command == "toy":
            run_toy_system_cmd(args, logger, tracker)
        elif args.command == "compression":
            _require_data(args, logger)
            run_compression_cmd(args, logger, tracker)
        elif args.command == "ablations":
            run_ablations_cmd(args, logger, tracker)
        elif args.command == "full":
            run_full_experiment(args, logger)
        elif args.command == "reviewer_proof":
            from .reviewer_proof import run_reviewer_proof_experiments
            config = OptionBConfig(
                dataset=args.dataset,
                n_seeds=args.n_seeds,
                data_dir=args.data_dir,
                output_dir=args.output_dir,
            )
            results = run_reviewer_proof_experiments(config, logger)
            save_results(results, args.output_dir, f"reviewer_proof_{args.dataset}")
        elif args.command == "sample_complexity":
            from .reviewer_proof import run_sample_complexity_study
            from .adversarial import get_model, load_dataset
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            train_ds, n_classes, in_ch = load_dataset(args.dataset, args.data_dir, train=True)
            test_ds, _, _ = load_dataset(args.dataset, args.data_dir, train=False)
            model = get_model('cifar_cnn' if args.dataset != 'mnist' else 'simple_cnn', n_classes, in_ch, dataset=args.dataset).to(device)
            # Quick train
            loader = torch.utils.data.DataLoader(train_ds, batch_size=128, shuffle=True)
            opt = torch.optim.Adam(model.parameters(), lr=0.001)
            model.train()
            for epoch in range(10):
                for x, y in loader:
                    x, y = x.to(device), y.to(device)
                    opt.zero_grad()
                    torch.nn.functional.cross_entropy(model(x), y).backward()
                    opt.step()
            results = run_sample_complexity_study(model, test_ds, args.n_samples, logger=logger, device=device)
            save_results(results, args.output_dir, f"sample_complexity_{args.dataset}")
        elif args.command == "baselines":
            from .reviewer_proof import run_baseline_comparison
            from .adversarial import AdversarialAnalyzer
            from scipy import stats as scipy_stats
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            
            all_seed_results = []
            for seed in range(args.n_seeds):
                logger.info(f"\n=== Seed {seed+1}/{args.n_seeds} ===")
                torch.manual_seed(seed)
                np.random.seed(seed)
                
                config = OptionBConfig(dataset=args.dataset, data_dir=args.data_dir, n_seeds=1, n_test_samples=args.n_samples)
                analyzer = AdversarialAnalyzer(config, logger)
                analyzer.train_model()
                analysis_results = analyzer.run_analysis()
                
                # Store per-seed metrics
                seed_metrics = {
                    'seed': seed,
                    'h_basin_auc': analysis_results.get('h_basin_roc_auc', 0),
                    'baseline_aucs': {k: v.get('roc_auc', 0.5) for k, v in analysis_results.get('baseline_comparison', {}).items() if isinstance(v, dict) and 'roc_auc' in v},
                }
                all_seed_results.append(seed_metrics)
            
            # Aggregate across seeds
            metrics = ['h_basin', 'gradient_norm', 'margin', 'confidence', 'entropy', 'local_lipschitz']
            aggregated = {'dataset': args.dataset, 'n_seeds': args.n_seeds, 'metrics': {}}
            
            for m in metrics:
                if m == 'h_basin':
                    values = [r['h_basin_auc'] for r in all_seed_results]
                else:
                    values = [r['baseline_aucs'].get(m, 0.5) for r in all_seed_results]
                
                mean_val = np.mean(values)
                std_val = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
                ci = scipy_stats.t.interval(0.95, len(values)-1, loc=mean_val, scale=std_val/np.sqrt(len(values))) if len(values) > 1 else (mean_val, mean_val)
                
                aggregated['metrics'][m] = {
                    'mean': float(mean_val),
                    'std': float(std_val),
                    'ci_lower': float(ci[0]) if not np.isnan(ci[0]) else float(mean_val),
                    'ci_upper': float(ci[1]) if not np.isnan(ci[1]) else float(mean_val),
                    'values': [float(v) for v in values]
                }
            
            # Compute ranking
            ranking = sorted(aggregated['metrics'].items(), key=lambda x: x[1]['mean'], reverse=True)
            aggregated['ranking'] = [(name, data['mean']) for name, data in ranking]
            h_basin_rank = [i for i, (n, _) in enumerate(ranking) if n == 'h_basin'][0] + 1
            aggregated['h_basin_rank'] = h_basin_rank
            
            logger.info(f"\n=== Aggregated Results ({args.n_seeds} seeds) ===")
            for name, data in ranking:
                logger.info(f"  {name}: {data['mean']:.4f} ± {data['std']:.4f} (CI: [{data['ci_lower']:.4f}, {data['ci_upper']:.4f}])")
            logger.info(f"H_basin rank: {h_basin_rank}/{len(metrics)}")
            
            save_results(aggregated, args.output_dir, f"baseline_comparison_{args.dataset}_{args.n_seeds}seeds")
            
        elif args.command == "baselines_all":
            from .reviewer_proof import run_baseline_comparison
            from .adversarial import AdversarialAnalyzer
            from scipy import stats as scipy_stats
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            
            datasets = ['mnist', 'cifar10', 'cifar100', 'svhn']
            all_dataset_results = {}
            
            for dataset in datasets:
                logger.info(f"\n{'='*60}\nDataset: {dataset}\n{'='*60}")
                
                dataset_seed_results = []
                for seed in range(args.n_seeds):
                    logger.info(f"\n--- Seed {seed+1}/{args.n_seeds} ---")
                    torch.manual_seed(seed)
                    np.random.seed(seed)
                    
                    config = OptionBConfig(dataset=dataset, data_dir=args.data_dir, n_seeds=1, n_test_samples=args.n_samples)
                    try:
                        analyzer = AdversarialAnalyzer(config, logger)
                        analyzer.train_model()
                        analysis_results = analyzer.run_analysis()
                        
                        seed_metrics = {
                            'seed': seed,
                            'h_basin_auc': analysis_results.get('h_basin_roc_auc', 0),
                            'baseline_aucs': {k: v.get('roc_auc', 0.5) for k, v in analysis_results.get('baseline_comparison', {}).items() if isinstance(v, dict) and 'roc_auc' in v},
                        }
                        dataset_seed_results.append(seed_metrics)
                    except Exception as e:
                        logger.error(f"Failed on {dataset} seed {seed}: {e}")
                
                # Aggregate for this dataset
                metrics = ['h_basin', 'gradient_norm', 'margin', 'confidence', 'entropy', 'local_lipschitz']
                dataset_agg = {'n_seeds': len(dataset_seed_results), 'metrics': {}}
                
                for m in metrics:
                    if m == 'h_basin':
                        values = [r['h_basin_auc'] for r in dataset_seed_results]
                    else:
                        values = [r['baseline_aucs'].get(m, 0.5) for r in dataset_seed_results]
                    
                    if values:
                        mean_val = np.mean(values)
                        std_val = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
                        dataset_agg['metrics'][m] = {'mean': float(mean_val), 'std': float(std_val)}
                
                # Ranking
                if dataset_agg['metrics']:
                    ranking = sorted(dataset_agg['metrics'].items(), key=lambda x: x[1]['mean'], reverse=True)
                    dataset_agg['ranking'] = [(n, d['mean']) for n, d in ranking]
                    h_rank = [i for i, (n, _) in enumerate(ranking) if n == 'h_basin'][0] + 1
                    dataset_agg['h_basin_rank'] = h_rank
                    
                    logger.info(f"\n{dataset} Results:")
                    for name, data in ranking:
                        logger.info(f"  {name}: {data['mean']:.4f} ± {data['std']:.4f}")
                    logger.info(f"H_basin rank: {h_rank}/{len(metrics)}")
                
                all_dataset_results[dataset] = dataset_agg
            
            # Summary table
            logger.info(f"\n{'='*60}\nSUMMARY TABLE\n{'='*60}")
            logger.info(f"{'Dataset':<12} | {'H_basin':<12} | {'Best Baseline':<15} | {'H Rank':<8}")
            logger.info("-" * 55)
            for ds, res in all_dataset_results.items():
                if res.get('metrics'):
                    h_auc = res['metrics'].get('h_basin', {}).get('mean', 0)
                    best = res.get('ranking', [('none', 0)])[0]
                    h_rank = res.get('h_basin_rank', '?')
                    logger.info(f"{ds:<12} | {h_auc:<12.4f} | {best[0]:<15} | {h_rank}/6")
            
            save_results(all_dataset_results, args.output_dir, f"baseline_comparison_all_datasets_{args.n_seeds}seeds")
        
        # NEW COMMANDS FOR REVIEWER-PROOF EXPERIMENTS
        elif args.command == "naive_baselines":
            from .reviewer_proof import run_naive_baselines_experiment
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            result = run_naive_baselines_experiment(
                dataset=args.dataset,
                model_name=args.model,
                n_seeds=args.n_seeds,
                n_test_samples=args.n_test_samples,
                n_perturbations=args.n_perturbations,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(result.to_dict(), args.output_dir, f"naive_baselines_{args.dataset}_{args.model}")
        
        elif args.command == "naive_baselines_suite":
            from .reviewer_proof import run_naive_baselines_suite
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            datasets = [d.strip() for d in args.datasets.split(',')]
            models = [m.strip() for m in args.models.split(',')]
            results = run_naive_baselines_suite(
                datasets=datasets,
                models=models,
                n_seeds=args.n_seeds,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"naive_baselines_suite_{args.n_seeds}seeds")
        
        elif args.command == "table4":
            from .reviewer_proof import run_table4_experiment
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            result = run_table4_experiment(
                dataset=args.dataset,
                model_name=args.model,
                training=args.training,
                n_seeds=args.n_seeds,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(result.to_dict(), args.output_dir, f"table4_{args.dataset}_{args.model}_{args.training}")
        
        elif args.command == "table4_suite":
            from .reviewer_proof import run_table4_suite
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_table4_suite(
                n_seeds=args.n_seeds,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"table4_suite_{args.n_seeds}seeds")
        
        elif args.command == "table5":
            from .reviewer_proof import run_table5_experiment
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_table5_experiment(
                dataset=args.dataset,
                model_name=args.model,
                n_seeds=args.n_seeds,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"table5_{args.dataset}_{args.model}_{args.n_seeds}seeds")
        
        elif args.command == "compression_split":
            from .reviewer_proof import run_compression_split_comparison
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_compression_split_comparison(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"compression_split_{args.dataset}_{args.model}")
        
        elif args.command == "games_null":
            from .reviewer_proof import run_games_null_test
            results = run_games_null_test(
                n_perturbations=args.n_perturbations,
                n_seeds=args.n_seeds,
                logger=logger
            )
            save_results(results, args.output_dir, f"games_null_{args.n_seeds}seeds")
        
        elif args.command == "causal_intervention":
            _require_data(args, logger)
            from .reviewer_proof import run_causal_intervention
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_causal_intervention(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                n_seeds=args.n_seeds,
                score_fraction=getattr(args, 'score_fraction', 1.0),
                arm_subset=getattr(args, 'arm_subset', 'full'),
                **({'epsilon': args.wsb_epsilon}
                   if getattr(args, 'wsb_epsilon', None) is not None else {}),
                seed_list=([int(x) for x in args.seed_list.split(',')] if getattr(args, 'seed_list', None) else None),
                train_mode=getattr(args, 'train_mode', 'standard'),
                attack_epsilon=getattr(args, 'attack_epsilon', None),
                attack_steps=getattr(args, 'attack_steps', 20),
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"causal_{args.dataset}_{args.model}_{args.n_seeds}seeds")

        elif args.command == "score_stability":
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            from .scale_checks import run_score_stability
            run_score_stability(dataset=args.dataset, model_name=args.model,
                                train_epochs=args.train_epochs,
                                data_dir=args.data_dir,
                                output_dir=args.output_dir, device=device,
                                logger=logger, seed=args.seed)

        elif args.command == "throughput_demo":
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            from .scale_checks import run_throughput_demo
            run_throughput_demo(dataset=args.dataset, model_name=args.model,
                                train_epochs=args.train_epochs,
                                data_dir=args.data_dir,
                                output_dir=args.output_dir, device=device,
                                logger=logger, seed=args.seed)

        elif args.command == "aa_reeval":
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            from .aa_reeval import run_aa_reeval
            run_aa_reeval(dataset=args.dataset, model_name=args.model,
                          train_epochs=args.train_epochs,
                          data_dir=args.data_dir,
                          output_dir=args.output_dir, device=device,
                          logger=logger,
                          seed_list=([int(x) for x in args.seed_list.split(',')]
                                     if args.seed_list else None),
                          n_seeds=args.n_seeds,
                          attack_epsilon=args.attack_epsilon,
                          n_eval=args.n_eval, aa_version=args.aa_version)
        
        elif args.command == "bulletproof_suite":
            from .reviewer_proof import run_bulletproof_suite
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_bulletproof_suite(
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"bulletproof_suite")
        
        elif args.command == "ablation_attack":
            from .reviewer_proof import run_attack_strength_ablation
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_attack_strength_ablation(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"ablation_attack_{args.dataset}_{args.model}")
        
        elif args.command == "ablation_epsilon":
            from .reviewer_proof import run_phase_epsilon_ablation
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_phase_epsilon_ablation(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"ablation_epsilon_{args.dataset}_{args.model}")
        
        elif args.command == "ablation_difficulty":
            from .reviewer_proof import run_sample_difficulty_ablation
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_sample_difficulty_ablation(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"ablation_difficulty_{args.dataset}_{args.model}")
        
        elif args.command == "hbasin_wins":
            from .reviewer_proof import run_hbasin_wins_ablation
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_hbasin_wins_ablation(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"hbasin_wins_{args.dataset}_{args.model}")
        
        elif args.command == "naive_baselines_split":
            from .reviewer_proof import run_naive_baselines_split
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_naive_baselines_split(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                n_perturbations=args.n_perturbations,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"naive_split_{args.dataset}_{args.model}")
        
        elif args.command == "attack_transfer":
            from .reviewer_proof import run_attack_transfer_experiment
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_attack_transfer_experiment(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"attack_transfer_{args.dataset}_{args.model}")
        
        elif args.command == "epsilon_stability":
            from .reviewer_proof import run_epsilon_stability_experiment
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_epsilon_stability_experiment(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"epsilon_stability_{args.dataset}_{args.model}")
        
        elif args.command == "model_transfer":
            from .reviewer_proof import run_model_transfer_experiment
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_model_transfer_experiment(
                dataset=args.dataset,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"model_transfer_{args.dataset}")
        
        elif args.command == "toy_validation":
            from .reviewer_proof import run_toy_validation_experiment
            results = run_toy_validation_experiment(
                n_samples=args.n_samples,
                logger=logger
            )
            save_results(results, args.output_dir, "toy_validation")
        
        elif args.command == "naive_fails_suite":
            from .reviewer_proof import run_naive_fails_suite
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            results = run_naive_fails_suite(
                dataset=args.dataset,
                model_name=args.model,
                n_test_samples=args.n_test_samples,
                train_epochs=args.train_epochs,
                data_dir=args.data_dir,
                device=device,
                logger=logger
            )
            save_results(results, args.output_dir, f"naive_fails_{args.dataset}_{args.model}")
        
        logger.info(f"\nWSB Framework completed successfully!")
        logger.info(f"Total execution time: {time.time() - start:.2f}s")
        
    except Exception as e:
        logger.error(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
