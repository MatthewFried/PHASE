"""
WSB Framework - Reviewer-Proof V30
==================================
BULLETPROOF experiments for ICML 2026.

V29:
- naive_baselines_split: Compare H_basin vs LFR/LOGVAR/MCENT/MARGDROP on ALL splits

V30 NEW - "NAIVE METRICS FAIL" EXPERIMENTS:
1. Attack Transfer: Metrics trained on PGD, tested on FGSM/CW/AutoAttack
2. Epsilon Stability: How metrics change with perturbation budget (0.05-0.3)
3. Model Transfer: Metrics from Model A predict attack on Model B
4. Toy System Validation: Correlation with TRUE phase boundaries
5. Temporal Stability (RL): Metrics over training, predict collapse

H_basin should WIN on all transfer/stability experiments even when losing on raw AUC.
"""

import numpy as np
from typing import Dict, List, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset
from dataclasses import dataclass, asdict
from scipy import stats

from .config import OptionBConfig, DATASET_DEFAULTS
from .core import compute_basin_entropy, StatisticalTests
from .adversarial import (get_model, load_dataset, PGDAttack,
                          FGSMAttack, train_standard, train_pgd, train_trades)


@dataclass
class NaivePerturbationMetrics:
    h_basin: float
    lfr: float
    logvar: float
    mcent: float
    margdrop: float
    phase_counts: List[int]
    def to_dict(self): return asdict(self)


def compute_naive_perturbation_metrics(
    model: nn.Module, x: torch.Tensor, y: int,
    epsilon: float, n_perturbations: int, n_classes: int, device: str = 'cuda'
) -> NaivePerturbationMetrics:
    model.eval()
    x = x.to(device)
    if x.dim() == 3: x = x.unsqueeze(0)
    
    with torch.no_grad():
        clean_logits = model(x)
        clean_probs = F.softmax(clean_logits, dim=1)
        clean_pred = clean_logits.argmax(1).item()
        clean_prob_at_pred = clean_probs[0, clean_pred].item()
        probs_copy = clean_probs[0].clone()
        probs_copy[clean_pred] = -float('inf')
        clean_margin = clean_prob_at_pred - probs_copy.max().item()
    
    phase_counts = np.zeros(n_classes, dtype=np.int64)
    flips, pred_class_probs, softmax_ents, pert_margins = 0, [], [], []
    x_sq = x.squeeze(0)
    
    for _ in range(n_perturbations):
        delta = torch.empty_like(x_sq).uniform_(-epsilon, epsilon)
        x_pert = torch.clamp(x_sq + delta, 0, 1).unsqueeze(0)
        with torch.no_grad():
            logits_p = model(x_pert)
            probs_p = F.softmax(logits_p, dim=1)
            pred_p = logits_p.argmax(1).item()
        phase_counts[pred_p] += 1
        if pred_p != clean_pred: flips += 1
        pred_class_probs.append(probs_p[0, clean_pred].item())
        softmax_ents.append(-torch.sum(probs_p * torch.log(probs_p + 1e-10)).item())
        pc = probs_p[0].clone(); pc[pred_p] = -float('inf')
        pert_margins.append(probs_p[0, pred_p].item() - pc.max().item())
    
    return NaivePerturbationMetrics(
        h_basin=compute_basin_entropy(phase_counts), lfr=flips/n_perturbations,
        logvar=float(np.var(pred_class_probs)), mcent=float(np.mean(softmax_ents)),
        margdrop=clean_margin - float(np.mean(pert_margins)), phase_counts=phase_counts.tolist()
    )


# =============================================================================
# EXPERIMENT 1: NAIVE BASELINES (VERBOSE)
# =============================================================================

@dataclass
class NaiveBaselineResults:
    dataset: str
    model_name: str
    n_samples: int
    n_seeds: int
    attack_success_rate: float
    h_basin_auc: Tuple[float, float]
    lfr_auc: Tuple[float, float]
    logvar_auc: Tuple[float, float]
    mcent_auc: Tuple[float, float]
    margdrop_auc: Tuple[float, float]
    h_basin_ci: Tuple[float, float]
    ranking: List[Tuple[str, float]]
    h_basin_rank: int
    def to_dict(self):
        return {'dataset': self.dataset, 'model_name': self.model_name,
            'n_samples': self.n_samples, 'n_seeds': self.n_seeds,
            'attack_success_rate': self.attack_success_rate,
            'metrics': {
                'h_basin': {'mean': self.h_basin_auc[0], 'std': self.h_basin_auc[1], 'ci': self.h_basin_ci},
                'lfr': {'mean': self.lfr_auc[0], 'std': self.lfr_auc[1]},
                'logvar': {'mean': self.logvar_auc[0], 'std': self.logvar_auc[1]},
                'mcent': {'mean': self.mcent_auc[0], 'std': self.mcent_auc[1]},
                'margdrop': {'mean': self.margdrop_auc[0], 'std': self.margdrop_auc[1]},
            }, 'ranking': self.ranking, 'h_basin_rank': self.h_basin_rank}


def run_naive_baselines_experiment(
    dataset: str, model_name: str, n_seeds: int = 5, n_test_samples: int = 1000,
    n_perturbations: int = 64, epsilon: float = 0.1, train_epochs: int = 100,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> NaiveBaselineResults:
    from sklearn.metrics import roc_auc_score
    if logger: logger.info(f"Naive baselines: {dataset}/{model_name}, {n_seeds} seeds")
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    all_aucs = {k: [] for k in ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop']}
    all_asr = []
    
    for seed in range(n_seeds):
        if logger: logger.info(f"  Seed {seed+1}/{n_seeds}")
        torch.manual_seed(seed); np.random.seed(seed)
        if torch.cuda.is_available(): torch.cuda.manual_seed(seed)
        
        model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
        train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
        train_standard(model, train_loader, train_epochs, device, logger=None)
        model.eval()
        
        test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
        sample_metrics, attack_results = [], []
        attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
        attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
        pgd = PGDAttack(model, attack_eps, attack_alpha, steps=20, device=device)
        
        for idx in test_idx:
            x, y = test_ds[idx]
            x_b, y_b = x.unsqueeze(0).to(device), torch.tensor([y]).to(device)
            with torch.no_grad():
                if model(x_b).argmax(1).item() != y: continue
            metrics = compute_naive_perturbation_metrics(model, x, y, epsilon, n_perturbations, n_classes, device)
            _, success = pgd.attack(x_b, y_b)
            sample_metrics.append(metrics); attack_results.append(success.item())
        
        if not attack_results: continue
        y_true = np.array(attack_results).astype(int)
        all_asr.append(y_true.mean())
        
        for m in all_aucs:
            vals = np.array([getattr(met, m) for met in sample_metrics])
            try:
                all_aucs[m].append(roc_auc_score(y_true, vals) if len(np.unique(y_true))>=2 and np.std(vals)>1e-10 else 0.5)
            except: all_aucs[m].append(0.5)
        
        if logger:
            logger.info(f"    AUC: H={all_aucs['h_basin'][-1]:.4f} LFR={all_aucs['lfr'][-1]:.4f} "
                       f"LOGVAR={all_aucs['logvar'][-1]:.4f} MCENT={all_aucs['mcent'][-1]:.4f} "
                       f"MARGDROP={all_aucs['margdrop'][-1]:.4f} | ASR={y_true.mean():.1%}")
    
    def sf(v): return (float(np.mean(v)),
                       float(np.std(v, ddof=1)) if len(v) > 1 else 0.0) if v else (0.5, 0.0)
    h_stats = sf(all_aucs['h_basin'])
    h_ci = stats.t.interval(0.95, len(all_aucs['h_basin'])-1, loc=h_stats[0], scale=h_stats[1]/np.sqrt(len(all_aucs['h_basin']))) if len(all_aucs['h_basin'])>=2 else (h_stats[0], h_stats[0])
    all_means = {k: sf(all_aucs[k])[0] for k in all_aucs}
    ranking = sorted(all_means.items(), key=lambda x: x[1], reverse=True)
    h_rank = [i for i,(n,_) in enumerate(ranking) if n=='h_basin'][0]+1
    
    if logger:
        logger.info(f"  === FINAL RANKING ===")
        for i,(n,a) in enumerate(ranking):
            logger.info(f"    {i+1}. {n}: {a:.4f} ± {sf(all_aucs[n])[1]:.4f}{' <-- H_basin' if n=='h_basin' else ''}")
    
    return NaiveBaselineResults(dataset=dataset, model_name=model_name, n_samples=n_test_samples, n_seeds=n_seeds,
        attack_success_rate=float(np.mean(all_asr)) if all_asr else 0.0, h_basin_auc=h_stats,
        lfr_auc=sf(all_aucs['lfr']), logvar_auc=sf(all_aucs['logvar']), mcent_auc=sf(all_aucs['mcent']),
        margdrop_auc=sf(all_aucs['margdrop']), h_basin_ci=(float(h_ci[0]), float(h_ci[1])),
        ranking=ranking, h_basin_rank=h_rank)


# =============================================================================
# V29: NAIVE BASELINES WITH SAMPLE DIFFICULTY SPLIT
# =============================================================================

def run_naive_baselines_split(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 2000, n_perturbations: int = 64, epsilon: float = 0.1,
    train_epochs: int = 100, data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    V29: Compare H_basin vs ALL naive perturbation baselines (LFR, LOGVAR, MCENT, MARGDROP)
    on ALL sample splits (all, easy, hard, high-margin, low-margin).
    
    This directly addresses reviewer concern: "Is PHASE just repackaging naive statistics?"
    Answer: No - naive metrics collapse on hard samples, H_basin dominates.
    """
    from sklearn.metrics import roc_auc_score
    
    if logger:
        logger.info("=" * 60)
        logger.info("V29: NAIVE BASELINES WITH SAMPLE DIFFICULTY SPLIT")
        logger.info("=" * 60)
        logger.info(f"Dataset: {dataset}, Model: {model_name}")
        logger.info(f"Metrics: H_basin, LFR, LOGVAR, MCENT, MARGDROP")
        logger.info("=" * 60)
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    # Train model
    torch.manual_seed(42); np.random.seed(42)
    if torch.cuda.is_available(): torch.cuda.manual_seed(42)
    
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    
    if logger: logger.info("Training model...")
    train_standard(model, train_loader, train_epochs, device, logger=None)
    model.eval()
    
    # Collect samples with all metrics
    if logger: logger.info("Computing metrics for all samples...")
    
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
    attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
    pgd = PGDAttack(model, attack_eps, attack_alpha, steps=20, device=device)
    
    sample_data = []
    for i, idx in enumerate(test_idx):
        if i % 500 == 0 and logger:
            logger.info(f"  Processing sample {i}/{len(test_idx)}...")
        
        x, y = test_ds[idx]
        x_b = x.unsqueeze(0).to(device)
        y_b = torch.tensor([y]).to(device)
        
        with torch.no_grad():
            logits = model(x_b)
            pred = logits.argmax(1).item()
            probs = F.softmax(logits, dim=1)
            conf = probs.max().item()
            sorted_logits = torch.sort(logits, dim=1, descending=True)[0]
            margin = (sorted_logits[0, 0] - sorted_logits[0, 1]).item()
        
        if pred != y:
            continue
        
        # Compute naive perturbation metrics
        metrics = compute_naive_perturbation_metrics(model, x, y, epsilon, n_perturbations, n_classes, device)
        
        # PGD attack
        _, success = pgd.attack(x_b, y_b)
        
        sample_data.append({
            'conf': conf,
            'margin': margin,
            'h_basin': metrics.h_basin,
            'lfr': metrics.lfr,
            'logvar': metrics.logvar,
            'mcent': metrics.mcent,
            'margdrop': metrics.margdrop,
            'attack_success': success.item()
        })
    
    if logger: logger.info(f"  Collected {len(sample_data)} correctly classified samples")
    
    # Define splits
    confs = np.array([s['conf'] for s in sample_data])
    margins = np.array([s['margin'] for s in sample_data])
    conf_median = np.percentile(confs, 50)
    margin_median = np.percentile(margins, 50)
    
    splits = {
        'all': list(range(len(sample_data))),
        'easy (high conf)': [i for i, s in enumerate(sample_data) if s['conf'] >= conf_median],
        'hard (low conf)': [i for i, s in enumerate(sample_data) if s['conf'] < conf_median],
        'high margin': [i for i, s in enumerate(sample_data) if s['margin'] >= margin_median],
        'low margin': [i for i, s in enumerate(sample_data) if s['margin'] < margin_median],
    }
    
    metric_names = ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop']
    results = {'dataset': dataset, 'model': model_name, 'n_samples': len(sample_data), 'splits': {}}
    
    for split_name, indices in splits.items():
        if len(indices) < 50:
            continue
        
        y_true = np.array([sample_data[i]['attack_success'] for i in indices]).astype(int)
        asr = y_true.mean()
        
        if len(np.unique(y_true)) < 2:
            if logger: logger.info(f"\n  {split_name}: Skipped (no variance in labels)")
            continue
        
        aucs = {}
        for mn in metric_names:
            vals = np.array([sample_data[i][mn] for i in indices])
            if np.std(vals) > 1e-10:
                try:
                    aucs[mn] = roc_auc_score(y_true, vals)
                except Exception:
                    aucs[mn] = 0.5
            else:
                aucs[mn] = 0.5
        
        ranking = sorted(aucs.items(), key=lambda x: x[1], reverse=True)
        h_rank = [i for i, (n, _) in enumerate(ranking) if n == 'h_basin'][0] + 1
        
        results['splits'][split_name] = {
            'n_samples': len(indices),
            'asr': float(asr),
            'aucs': {k: float(v) for k, v in aucs.items()},
            'ranking': ranking,
            'h_basin_rank': h_rank
        }
        
        if logger:
            logger.info(f"\n  {split_name} (n={len(indices)}, ASR={asr:.1%}):")
            for i, (n, a) in enumerate(ranking):
                marker = " <-- H_basin" if n == 'h_basin' else ""
                logger.info(f"    {i+1}. {n}: {a:.4f}{marker}")
    
    # Summary table
    if logger:
        logger.info("\n" + "=" * 60)
        logger.info("SUMMARY TABLE: H_basin vs Naive Perturbation Baselines")
        logger.info("=" * 60)
        logger.info(f"{'Split':<20} {'H_basin':<10} {'LFR':<10} {'LOGVAR':<10} {'MCENT':<10} {'MARGDROP':<10} {'H_rank':<8}")
        logger.info("-" * 78)
        for split_name, data in results['splits'].items():
            aucs = data['aucs']
            logger.info(f"{split_name:<20} {aucs.get('h_basin', 0):<10.4f} {aucs.get('lfr', 0):<10.4f} "
                       f"{aucs.get('logvar', 0):<10.4f} {aucs.get('mcent', 0):<10.4f} "
                       f"{aucs.get('margdrop', 0):<10.4f} {data['h_basin_rank']:<8}")
        
        # Highlight key finding
        logger.info("\n" + "=" * 60)
        logger.info("KEY FINDING:")
        if 'hard (low conf)' in results['splits']:
            hard_data = results['splits']['hard (low conf)']
            all_data = results['splits'].get('all', {})
            
            h_all = all_data.get('aucs', {}).get('h_basin', 0)
            h_hard = hard_data['aucs'].get('h_basin', 0)
            
            best_naive_all = max(all_data.get('aucs', {}).get(m, 0) for m in ['lfr', 'logvar', 'mcent', 'margdrop'])
            best_naive_hard = max(hard_data['aucs'].get(m, 0) for m in ['lfr', 'logvar', 'mcent', 'margdrop'])
            
            logger.info(f"  All samples:  H_basin={h_all:.4f}, Best naive={best_naive_all:.4f}")
            logger.info(f"  Hard samples: H_basin={h_hard:.4f}, Best naive={best_naive_hard:.4f}")
            logger.info(f"  H_basin change: {h_hard - h_all:+.4f}")
            logger.info(f"  Best naive change: {best_naive_hard - best_naive_all:+.4f}")
            
            if h_hard > best_naive_hard:
                logger.info(f"  ✓ H_basin WINS on hard samples!")
        logger.info("=" * 60)
    
    return results


# =============================================================================
# EXPERIMENT 2: COMPRESSION SPLIT COMPARISON
# =============================================================================

def prune_model(model: nn.Module, ratio: float, device: str) -> nn.Module:
    import copy
    pruned = copy.deepcopy(model)
    for _, m in pruned.named_modules():
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            w = m.weight.data
            thr = torch.quantile(torch.abs(w), ratio)
            m.weight.data = w * (torch.abs(w) > thr).float()
    return pruned.to(device)


def run_compression_split_comparison(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 1000, n_perturbations: int = 64, epsilon: float = 0.1,
    train_epochs: int = 100, pruning_ratios: List[float] = None,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """Compare H_basin vs naive metrics for predicting compression fragility."""
    if pruning_ratios is None: pruning_ratios = [0.3, 0.5, 0.7]
    if logger:
        logger.info("=" * 60)
        logger.info("EXPERIMENT 2: Compression Split Comparison")
        logger.info("=" * 60)
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model, train_loader, train_epochs, device, logger=None)
    model.eval()
    
    if logger: logger.info("Computing metrics...")
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    sample_data = []
    for idx in test_idx:
        x, y = test_ds[idx]
        with torch.no_grad():
            if model(x.unsqueeze(0).to(device)).argmax(1).item() != y: continue
        m = compute_naive_perturbation_metrics(model, x, y, epsilon, n_perturbations, n_classes, device)
        sample_data.append((idx, x, y, m))
    if logger: logger.info(f"  {len(sample_data)} samples")
    
    metric_names = ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop']
    results = {'pruning_ratios': pruning_ratios, 'metrics': {}}
    
    for mn in metric_names:
        vals = np.array([getattr(s[3], mn) for s in sample_data])
        thr = np.percentile(vals, 50)
        low_idx = [i for i,s in enumerate(sample_data) if getattr(s[3], mn) <= thr]
        high_idx = [i for i,s in enumerate(sample_data) if getattr(s[3], mn) > thr]
        results['metrics'][mn] = {'gaps': [], 'low_accs': [], 'high_accs': []}
        
        for pr in pruning_ratios:
            pm = prune_model(model, pr, device)
            low_c = sum(1 for i in low_idx if pm(sample_data[i][1].unsqueeze(0).to(device)).argmax(1).item()==sample_data[i][2])
            high_c = sum(1 for i in high_idx if pm(sample_data[i][1].unsqueeze(0).to(device)).argmax(1).item()==sample_data[i][2])
            low_acc, high_acc = low_c/len(low_idx) if low_idx else 0, high_c/len(high_idx) if high_idx else 0
            results['metrics'][mn]['gaps'].append(low_acc - high_acc)
            results['metrics'][mn]['low_accs'].append(low_acc)
            results['metrics'][mn]['high_accs'].append(high_acc)
        
        if logger: logger.info(f"  {mn}: mean gap = {np.mean(results['metrics'][mn]['gaps']):.4f}")
    
    mean_gaps = {m: np.mean(results['metrics'][m]['gaps']) for m in metric_names}
    ranking = sorted(mean_gaps.items(), key=lambda x: x[1], reverse=True)
    results['ranking'] = ranking
    results['h_basin_rank'] = [i for i,(n,_) in enumerate(ranking) if n=='h_basin'][0]+1
    
    if logger:
        logger.info(f"  === COMPRESSION RANKING ===")
        for i,(n,g) in enumerate(ranking):
            logger.info(f"    {i+1}. {n}: {g:.4f}{' <-- H_basin' if n=='h_basin' else ''}")
    return results


# =============================================================================
# EXPERIMENT 4: GAMES NULL TEST (Fixed + Matching Pennies)
# =============================================================================

def run_games_null_test(n_perturbations: int = 50, epsilon: float = 0.1,
                        n_base_points: int = 25, n_seeds: int = 5,
                        logger=None) -> Dict:
    """
    Negative controls computed with the REAL dynamics and the dynamical-regime
    classifier (the v30 version hardcoded the PD outcome without running any
    dynamics, and binned Matching Pennies finals into quadrant "equilibrium
    regions" although replicator dynamics on MP cycles rather than converges).

    1. Prisoner's Dilemma + replicator: a single attracting fixed point
       (defect-defect). Local basin entropy should be ~0 at every base point,
       and this is now DEMONSTRATED by the dynamics: the classifier has a
       nonconvergent phase available, so H=0 is an empirical outcome, not a
       structural artifact of a one-phase classifier.
    2. Matching Pennies + replicator: no attracting fixed point; discrete
       replicator orbits the interior equilibrium. Every trajectory should
       land in the NONCONVERGENT phase, so all clouds are single-phase and
       local H should be ~0 while raw outcome variability is high - the
       naive-metric contrast.
    """
    from .config import OptionCConfig
    from .games import GameAnalyzer
    if logger:
        logger.info("=" * 60)
        logger.info("EXPERIMENT 4: Games Null Test (real dynamics)")
        logger.info("=" * 60)

    out = {}
    for game_type, expect in (("prisoners_dilemma", "single attractor (DD)"),
                              ("matching_pennies", "cycling, no attractor")):
        h_means, h_maxes, nonconv = [], [], []
        for seed in range(n_seeds):
            np.random.seed(seed)
            cfg = OptionCConfig(game_type=game_type,
                                n_perturbations=n_perturbations,
                                n_probe_points=4 * n_base_points,
                                epsilon=epsilon)
            ga = GameAnalyzer(cfg)
            h, _ = ga.compute_h_basin_current()
            ls = ga.last_local_stats
            h_means.append(h)
            h_maxes.append(ls["h_max"])
            if ls.get("nonconvergent_fraction") is not None:
                nonconv.append(ls["nonconvergent_fraction"])
        out[game_type] = {
            "expectation": expect,
            "h_mean": {"mean": float(np.mean(h_means)),
                       "std": float(np.std(h_means, ddof=1)) if len(h_means) > 1 else 0.0},
            "h_max": {"mean": float(np.mean(h_maxes)),
                      "std": float(np.std(h_maxes, ddof=1)) if len(h_maxes) > 1 else 0.0},
            "nonconvergent_fraction": float(np.mean(nonconv)) if nonconv else None,
        }
        if logger:
            logger.info(f"  {game_type}: H_mean={out[game_type]['h_mean']['mean']:.4f} "
                        f"(expect ~0), H_max={out[game_type]['h_max']['mean']:.4f}, "
                        f"nonconvergent={out[game_type]['nonconvergent_fraction']}")
    out["null_passed"] = bool(out["prisoners_dilemma"]["h_mean"]["mean"] < 0.05
                              and out["matching_pennies"]["h_mean"]["mean"] < 0.05)
    return out


def _score_training_set(model, train_ds, score_indices, epsilon, n_perturbations,
                        n_classes, device, logger=None, batch_size=128):
    """
    Score training samples with the PHASE cloud metrics, BATCHED.
    Returns dict metric_name -> np.ndarray aligned with score_indices.
    Misclassified samples get np.nan in every metric (the nan pattern is
    identical across metrics); the caller restricts all arms to the shared
    valid set so every arm removes exactly the same number of samples.
    margdrop holds the REFERENCE CLASS fixed: perturbed margin is
    p(clean_pred) - max_{j != clean_pred} p_j, so a label flip changes the
    value rather than silently changing which margin is measured.
    """
    model.eval()
    names = ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop']
    scores = {n: np.full(len(score_indices), np.nan) for n in names}
    n_scored = 0
    for start in range(0, len(score_indices), batch_size):
        chunk = score_indices[start:start + batch_size]
        xs, ys = zip(*[train_ds[int(i)] for i in chunk])
        xb = torch.stack(xs).to(device)
        yb = torch.tensor(ys).to(device)
        with torch.no_grad():
            clean_logits = model(xb)
            clean_pred = clean_logits.argmax(1)
            correct_mask = (clean_pred == yb).cpu().numpy()
            clean_probs = F.softmax(clean_logits, dim=1)
        B = xb.size(0)
        counts = np.zeros((B, n_classes), dtype=np.int64)
        pred_class_probs = np.zeros((B, n_perturbations))
        soft_ents = np.zeros((B, n_perturbations))
        pert_margins = np.zeros((B, n_perturbations))
        one_hot_clean = F.one_hot(clean_pred, n_classes).bool()
        with torch.no_grad():
            for p_i in range(n_perturbations):
                delta = torch.empty_like(xb).uniform_(-epsilon, epsilon)
                logits_p = model(torch.clamp(xb + delta, 0, 1))
                probs_p = F.softmax(logits_p, dim=1)
                pred_p = logits_p.argmax(1)
                pp = pred_p.cpu().numpy()
                for b in range(B):
                    counts[b, pp[b]] += 1
                p_ref = probs_p.gather(1, clean_pred.view(-1, 1)).squeeze(1)
                pred_class_probs[:, p_i] = p_ref.cpu().numpy()
                soft_ents[:, p_i] = (-probs_p * torch.log(probs_p + 1e-10)
                                     ).sum(1).cpu().numpy()
                # fixed-reference margin: p(clean_pred) - max over other classes
                other_max = probs_p.masked_fill(one_hot_clean, -1.0).max(1)[0]
                pert_margins[:, p_i] = (p_ref - other_max).cpu().numpy()
        # clean margin with the same fixed reference
        oc = clean_probs.masked_fill(one_hot_clean, -1.0).max(1)[0]
        clean_margin = (clean_probs.gather(1, clean_pred.view(-1, 1)).squeeze(1)
                        - oc).cpu().numpy()
        clean_np = clean_pred.cpu().numpy()
        for b in range(B):
            if not correct_mask[b]:
                continue
            j = start + b
            scores['h_basin'][j] = compute_basin_entropy(counts[b])
            scores['lfr'][j] = 1.0 - counts[b, clean_np[b]] / max(counts[b].sum(), 1)
            scores['logvar'][j] = float(np.var(pred_class_probs[b]))
            scores['mcent'][j] = float(np.mean(soft_ents[b]))
            scores['margdrop'][j] = clean_margin[b] - float(np.mean(pert_margins[b]))
            n_scored += 1
        if logger and (start // batch_size) % 20 == 19:
            logger.info(f"      scored {start + B}/{len(score_indices)} "
                        f"({n_scored} correct)")
    return scores


def run_causal_intervention(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 500, n_perturbations: int = 64, epsilon: float = 0.1,
    train_epochs: int = 50, removal_percentile: float = 80, n_seeds: int = 3,
    score_fraction: float = 1.0, train_mode: str = 'standard',
    arm_subset: str = 'full',
    seed_list=None,
    attack_epsilon: float = None, attack_steps: int = 20,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    Causal intervention, corrected protocol (headline claim; arms must be
    airtight):

    - Scores score_fraction of the FULL training set (default 1.0) on the
      CANONICAL (non-augmented) images.
    - Arms per metric m in {h_basin, lfr, logvar, mcent, margdrop}:
      remove-high-m and remove-low-m (control), plus a size-matched random
      arm; every arm removes exactly the same number of samples from the same
      correctly-classified pool. n_removed >= 1 is enforced (a zero count
      would silently remove the whole pool via the order[-0:] slice).
    - PRIMARY OUTCOME: robust accuracy over the SAME fixed per-seed test
      index set for every arm. Conditioning each arm's ASR on its OWN
      clean-correct samples (v30/v31.0) lets an arm that damages clean
      accuracy on vulnerable samples look better because those samples leave
      the denominator; robust accuracy has an arm-invariant denominator.
      SECONDARY: ASR on the BASELINE model's clean-correct population, held
      fixed across arms; legacy own-correct ASR is recorded but not ranked.
    - Attack parameters come from DATASET_DEFAULTS for the dataset (v30
      hardcoded CIFAR's 8/255 even for MNIST) and attack randomness is
      seeded identically across arms within a seed.
    - Significance: PAIRED sign-flip permutation test on per-seed differences
      (the arms share their seed's baseline, so the design is paired; the
      previous unpaired shuffle test ignored this). Note the exact minimal
      attainable p is 2^-n_seeds: with the default 3 seeds no p < 0.125 is
      possible - use >= 10 seeds for a confirmatory claim.
    """
    if logger:
        logger.info("=" * 60)
        logger.info("EXPERIMENT 5: Causal Intervention (corrected protocol)")
        logger.info("=" * 60)

    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    score_ds, _, _ = load_dataset(dataset, data_dir, train=True, augment=False)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)

    # REGIME REQUIREMENT (learned from the first cifar10 run): the primary
    # outcome needs HEADROOM. Standard-trained CIFAR at eps=8/255 sits at
    # robust accuracy ~0% for every arm - baseline 0.0-0.4%, all arms
    # 0.0-0.8% - so no intervention effect is measurable and the experiment
    # is an honest null about the saturated regime, not about H. Two
    # non-saturated designs:
    #   (a) train_mode='pgd' (or 'trades'): arms are adversarially trained;
    #       robust accuracy ~40-60% at eps=8/255. STRONG version, ~8x cost.
    #   (b) attack_epsilon=2/255 with train_mode='standard': standard models
    #       keep partial robustness to the weaker attack. CHEAP version.
    # The eval attack epsilon is recorded in results['config'].
    if train_mode not in ('standard', 'pgd', 'trades'):
        raise ValueError(f"Unknown train_mode '{train_mode}'")
    atk = DATASET_DEFAULTS.get(dataset, {})
    train_eps = atk.get('attack_epsilon', 8 / 255)   # AT training budget
    train_alpha = atk.get('attack_alpha', 2 / 255)
    eval_eps = attack_epsilon if attack_epsilon is not None else train_eps
    attack_kw = dict(attack_epsilon=eval_eps,
                     attack_alpha=max(eval_eps / 4, 1 / 255),
                     attack_steps=attack_steps, attack_restarts=1)

    # arm_subset='controls' is the reviewer battery: baseline, high-LFR,
    # high-H, high-LOSS (conventional hardness score), size-matched random,
    # and CLASS-MATCHED random (matches the class histogram of the high-LFR
    # removal set). 6 trainings/seed instead of 12.
    if arm_subset == 'controls':
        metric_names = ['h_basin', 'lfr', 'loss']
        low_arms_enabled = False
    elif arm_subset == 'valuation':
        # standard data-valuation baselines battery: EL2N and GraNd at
        # epoch 10 (Paul et al. 2021) and forgetting counts over training
        # (Toneva et al. 2019), alongside H, LFR, and loss.
        metric_names = ['h_basin', 'lfr', 'loss', 'el2n', 'grand', 'forget']
        low_arms_enabled = False
    elif arm_subset == 'minimal':
        # radius-robustness battery: fewest arms that answer the question
        metric_names = ['lfr']
        low_arms_enabled = False
    else:
        metric_names = ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop', 'loss']
        low_arms_enabled = True
    arms = (['baseline'] + [f'remove_high_{m}' for m in metric_names]
            + ([f'remove_low_{m}' for m in metric_names] if low_arms_enabled else [])
            + ['remove_random', 'remove_class_random'])
    fields = ['robust_acc', 'clean_acc', 'asr_population', 'asr_own_correct']
    results = {
        'config': {'dataset': dataset, 'model_name': model_name,
                   'removal_percentile': removal_percentile,
                   'score_fraction': score_fraction,
                   'n_perturbations': n_perturbations, 'epsilon': epsilon,
                   'train_epochs': train_epochs, 'n_seeds': n_seeds,
                   'train_mode': train_mode, 'attack': attack_kw,
                   'primary_outcome': 'robust_acc (fixed denominator)'},
        **{f: {a: [] for a in arms} for f in fields},
        'n_removed': None,
    }

    _val_capture = {}

    def _valuation_callback(epoch, m):
        # eval-mode, shuffle=False, no_grad: consumes no RNG, so the
        # training trajectory is identical with or without instrumentation.
        if epoch == 9:
            _val_capture['ckpt10'] = {k: v.detach().clone()
                                      for k, v in m.state_dict().items()}
        m.eval()
        preds = np.empty(len(score_ds), dtype=np.int64)
        vloader = DataLoader(score_ds, batch_size=512, shuffle=False,
                             num_workers=2)
        with torch.no_grad():
            i0 = 0
            for x, y in vloader:
                p = m(x.to(device)).argmax(1).cpu().numpy()
                preds[i0:i0 + len(p)] = p
                i0 += len(p)
        _val_capture.setdefault('epoch_preds', []).append(preds)
        m.train()

    def _retrain(keep_indices, seed, instrument=False):
        torch.manual_seed(seed)
        m = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
        loader = DataLoader(Subset(train_ds, keep_indices), batch_size=128,
                            shuffle=True, num_workers=2, pin_memory=True)
        if instrument and train_mode == 'standard':
            _val_capture.clear()
            train_standard(m, loader, train_epochs, device, logger=None,
                           epoch_callback=_valuation_callback)
            return m
        if train_mode == 'pgd':
            train_pgd(m, loader, train_epochs, train_eps, train_alpha, 7,
                      device, logger=None)
        elif train_mode == 'trades':
            train_trades(m, loader, train_epochs, train_eps, train_alpha, 7,
                         6.0, device, logger=None)
        else:
            train_standard(m, loader, train_epochs, device, logger=None)
        return m

    def _record(arm, ev):
        for f in fields:
            results[f][arm].append(ev.get(f, np.nan))

    seeds = list(seed_list) if seed_list else list(range(n_seeds))
    for seed in seeds:
        if logger:
            logger.info(f"  Seed {seed+1} ({len(seeds)} seed(s) this run)")
        rng = np.random.default_rng(seed)
        torch.manual_seed(seed)
        np.random.seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
        eval_idx = rng.choice(len(test_ds), min(n_test_samples, len(test_ds)),
                              replace=False)
        attack_seed = 100_000 + seed  # identical attack RNG stream per arm

        # Baseline model + its clean-correct population (fixed for all arms).
        model = _retrain(list(range(len(train_ds))), seed,
                         instrument=(arm_subset == 'valuation'))
        model.eval()
        base_correct = np.zeros(len(eval_idx), dtype=bool)
        for start in range(0, len(eval_idx), 256):
            chunk = eval_idx[start:start + 256]
            xs, ys = zip(*[test_ds[int(i)] for i in chunk])
            xb = torch.stack(xs).to(device)
            yb = torch.tensor(ys).to(device)
            with torch.no_grad():
                base_correct[start:start + len(chunk)] = \
                    (model(xb).argmax(1) == yb).cpu().numpy()
        ev = evaluate_robustness(model, test_ds, eval_idx, device,
                                 population_mask=base_correct,
                                 attack_seed=attack_seed, **attack_kw)
        _record('baseline', ev)
        if logger:
            logger.info(f"    baseline: clean={ev['clean_acc']:.1%} "
                        f"robust={ev['robust_acc']:.1%} "
                        f"ASR_pop={ev['asr_population']:.1%}")

        # Score the training set (canonical images).
        n_score = int(len(train_ds) * score_fraction)
        score_indices = rng.choice(len(train_ds), n_score, replace=False)
        if logger:
            logger.info(f"    Scoring {n_score}/{len(train_ds)} training samples...")
        scores = _score_training_set(model, score_ds, score_indices, epsilon,
                                     n_perturbations, n_classes, device, logger)
        # Conventional hardness score: per-sample cross-entropy loss of the
        # scoring model on the canonical view (the 'you rediscovered
        # hard-example pruning' control). NaN-masked to the same valid pool.
        loss_arr = np.full(len(score_indices), np.nan)
        model.eval()
        for start in range(0, len(score_indices), 256):
            chunk = score_indices[start:start + 256]
            xs, ys = zip(*[score_ds[int(i)] for i in chunk])
            xb = torch.stack(xs).to(device)
            yb = torch.tensor(ys).to(device)
            with torch.no_grad():
                ce = F.cross_entropy(model(xb), yb, reduction='none')
            loss_arr[start:start + len(chunk)] = ce.cpu().numpy()
        loss_arr[np.isnan(scores['h_basin'])] = np.nan
        scores['loss'] = loss_arr
        if arm_subset == 'valuation':
            # EL2N/GraNd at the epoch-10 checkpoint; GraNd via the standard
            # ||p-onehot||*||logits|| surrogate. Forgetting = count of
            # correct->incorrect transitions over epochs, from the
            # instrumented baseline.
            m10 = get_model(model_name, n_classes, in_ch,
                            dataset=dataset).to(device)
            m10.load_state_dict(_val_capture['ckpt10']); m10.eval()
            el2n = np.full(len(score_indices), np.nan)
            grand = np.full(len(score_indices), np.nan)
            for start in range(0, len(score_indices), 256):
                chunk = score_indices[start:start + 256]
                xs, ys = zip(*[score_ds[int(i)] for i in chunk])
                xb = torch.stack(xs).to(device)
                yb = torch.tensor(ys).to(device)
                with torch.no_grad():
                    logits = m10(xb)
                    p = F.softmax(logits, dim=1)
                    e = p - F.one_hot(yb, n_classes).float()
                    el2n[start:start + len(chunk)] = e.norm(dim=1).cpu().numpy()
                    grand[start:start + len(chunk)] = (
                        e.norm(dim=1) * logits.norm(dim=1)).cpu().numpy()
            ep = np.stack(_val_capture['epoch_preds'])
            labels_all = np.array([int(score_ds[int(i)][1])
                                   for i in range(len(score_ds))])
            corr = (ep == labels_all[None, :])
            forget_full = np.maximum(corr[:-1].astype(int)
                                     - corr[1:].astype(int), 0).sum(0)
            valid_mask = ~np.isnan(scores['h_basin'])
            for nm, arr in (('el2n', el2n), ('grand', grand),
                            ('forget',
                             forget_full[score_indices].astype(float))):
                a = np.asarray(arr, dtype=float).copy()
                a[~valid_mask] = np.nan
                scores[nm] = a
        # Persist per-sample scores for offline analysis (escape entropy
        # H_escape = (H - h2(LFR)) / LFR is derivable from these exactly).
        try:
            import os as _os
            _os.makedirs('wsb_results', exist_ok=True)
            np.savez_compressed(
                f'wsb_results/causal_scores_{dataset}_seed{seed}.npz',
                indices=score_indices,
                **{k: v for k, v in scores.items()})
            if logger:
                logger.info(f"    per-sample scores saved: "
                            f"causal_scores_{dataset}_seed{seed}.npz")
        except Exception as e:
            if logger:
                logger.warning(f"    score dump failed: {e}")

        removal_frac = (100 - removal_percentile) / 100.0
        valid = ~np.isnan(scores[metric_names[0]])
        valid_idx = score_indices[valid]
        n_rm = min(int(round(n_score * removal_frac)), len(valid_idx))
        if n_rm < 1:
            raise ValueError(
                f"Removal count is {n_rm} (n_score={n_score}, "
                f"removal_percentile={removal_percentile}, valid pool="
                f"{len(valid_idx)}). Refusing: order[-0:] would remove the "
                f"entire valid pool.")
        results['n_removed'] = n_rm
        all_indices = set(range(len(train_ds)))
        if logger:
            logger.info(f"    {valid.sum()}/{n_score} scored samples valid; "
                        f"every arm removes {n_rm}.")

        for mn in metric_names:
            order = np.argsort(scores[mn][valid])
            arm_pairs = [(f'remove_high_{mn}', valid_idx[order[-n_rm:]])]
            if low_arms_enabled:
                arm_pairs.append((f'remove_low_{mn}', valid_idx[order[:n_rm]]))
            for arm_tag, rm_local in arm_pairs:
                keep = sorted(all_indices - set(int(i) for i in rm_local))
                m2 = _retrain(keep, seed)
                ev = evaluate_robustness(m2, test_ds, eval_idx, device,
                                         population_mask=base_correct,
                                         attack_seed=attack_seed, **attack_kw)
                _record(arm_tag, ev)
                if logger:
                    logger.info(f"    {arm_tag}: clean={ev['clean_acc']:.1%} "
                                f"robust={ev['robust_acc']:.1%} "
                                f"ASR_pop={ev['asr_population']:.1%}")

        rm_rand = rng.choice(valid_idx, n_rm, replace=False)
        keep = sorted(all_indices - set(int(i) for i in rm_rand))
        m3 = _retrain(keep, seed)
        ev = evaluate_robustness(m3, test_ds, eval_idx, device,
                                 population_mask=base_correct,
                                 attack_seed=attack_seed, **attack_kw)
        _record('remove_random', ev)
        if logger:
            logger.info(f"    remove_random: clean={ev['clean_acc']:.1%} "
                        f"robust={ev['robust_acc']:.1%} "
                        f"ASR_pop={ev['asr_population']:.1%}")

        # CLASS-MATCHED random arm: matches the class histogram of the
        # high-LFR removal set, defeating the class-composition alternative
        # explanation for the LFR effect.
        order_lfr = np.argsort(scores['lfr'][valid])
        lfr_high = valid_idx[order_lfr[-n_rm:]]
        labels_valid = np.array([int(score_ds[int(i)][1]) for i in valid_idx])
        labels_lfr = np.array([int(score_ds[int(i)][1]) for i in lfr_high])
        rm_cm = []
        for c in np.unique(labels_lfr):
            need = int((labels_lfr == c).sum())
            pool_c = valid_idx[labels_valid == c]
            rm_cm.append(rng.choice(pool_c, min(need, len(pool_c)),
                                    replace=False))
        rm_cm = np.concatenate(rm_cm)
        keep = sorted(all_indices - set(int(i) for i in rm_cm))
        m4 = _retrain(keep, seed)
        ev = evaluate_robustness(m4, test_ds, eval_idx, device,
                                 population_mask=base_correct,
                                 attack_seed=attack_seed, **attack_kw)
        _record('remove_class_random', ev)
        if logger:
            logger.info(f"    remove_class_random: clean={ev['clean_acc']:.1%} "
                        f"robust={ev['robust_acc']:.1%} "
                        f"ASR_pop={ev['asr_population']:.1%} "
                        f"(matched to high-LFR class histogram, n={len(rm_cm)})")

    # Aggregate. Primary: robust-accuracy GAIN over the seed's baseline.
    def _sd(v):
        return float(np.std(v, ddof=1)) if len(v) > 1 else 0.0

    base_rob = np.array(results['robust_acc']['baseline'])
    base_clean = np.array(results['clean_acc']['baseline'])
    CLEAN_DROP_LIMIT = 0.10   # arm interpretability guard (see below)
    agg = {}
    for a in arms:
        if not results['robust_acc'][a]:
            continue
        rob = np.array(results['robust_acc'][a])
        clean = np.array(results['clean_acc'][a])
        agg[a] = {'robust_acc_mean': float(rob.mean()), 'robust_acc_sd': _sd(rob),
                  'clean_acc_mean': float(clean.mean()),
                  'clean_drop_vs_baseline': float((base_clean - clean).mean())
                      if a != 'baseline' else 0.0,
                  'asr_population_mean': float(np.mean(results['asr_population'][a])),
                  'asr_own_correct_mean': float(np.mean(results['asr_own_correct'][a])),
                  'robust_gain_mean': float((rob - base_rob).mean()) if a != 'baseline' else 0.0,
                  'robust_gain_sd': _sd(rob - base_rob) if a != 'baseline' else 0.0,
                  # DEGENERATE-ARM GUARD: an intervention arm is only
                  # interpretable if it roughly preserves clean accuracy. A
                  # collapsed near-constant model has ~zero gradients, PGD
                  # cannot flip its few correct samples, and it "wins" on
                  # robust accuracy trivially (observed in a smoke run:
                  # a diverged remove_random arm at 7.5% clean ranked first).
                  # Per-seed collapse also flags the arm.
                  'degenerate': bool(a != 'baseline' and (
                      (base_clean - clean).mean() > CLEAN_DROP_LIMIT
                      or np.any(base_clean - clean > 2 * CLEAN_DROP_LIMIT)))}
    results['aggregate'] = agg

    high_arms = [f'remove_high_{m}' for m in metric_names] + ['remove_random']
    excluded = [a for a in high_arms if a in agg and agg[a]['degenerate']]
    if excluded:
        results['degenerate_arms_excluded_from_ranking'] = excluded
        if logger:
            for a in excluded:
                logger.warning(
                    f"  ARM DEGENERATE (excluded from ranking): {a} - clean "
                    f"accuracy dropped {agg[a]['clean_drop_vs_baseline']:+.1%} "
                    f"vs baseline; its robust accuracy is not interpretable "
                    f"as an intervention effect. Inspect per-seed clean_acc; "
                    f"a diverged training run should be rerun or reported.")
    ranking = sorted(((a, agg[a]['robust_gain_mean']) for a in high_arms
                      if a in agg and not agg[a]['degenerate']),
                     key=lambda t: -t[1])
    results['ranking_by_robust_gain'] = ranking
    results['h_basin_rank'] = ([i for i, (a, _) in enumerate(ranking)
                                if a == 'remove_high_h_basin'][0] + 1
                               if any(a == 'remove_high_h_basin' for a, _ in ranking)
                               else None)
    # PAIRED tests: per-seed robust gains of EVERY high-metric arm vs the
    # random arm (all arms share their seed's baseline, so the design is
    # paired). Testing only H (v36) left the actual ranking winner without a
    # significance statement. Degenerate arms are skipped.
    if (len(results['robust_acc']['remove_random']) >= 2
            and not agg.get('remove_random', {}).get('degenerate')):
        gain_r = np.array(results['robust_acc']['remove_random']) - base_rob
        results['paired_vs_random'] = {}
        for mn in metric_names:
            arm = f'remove_high_{mn}'
            if (len(results['robust_acc'][arm]) >= 2
                    and not agg.get(arm, {}).get('degenerate')):
                gain_m = np.array(results['robust_acc'][arm]) - base_rob
                results['paired_vs_random'][mn] = \
                    StatisticalTests.paired_permutation_test(
                        gain_m, gain_r, alternative='greater')
        if 'h_basin' in results['paired_vs_random']:
            results['high_h_vs_random_paired'] = \
                results['paired_vs_random']['h_basin']  # back-compat key
        # The two decisive control comparisons, both paired one-sided:
        # LFR vs class-matched random (class-composition explanation) and
        # LFR vs loss (hard-example-pruning-rediscovery explanation).
        extra = {}
        g_lfr = (np.array(results['robust_acc']['remove_high_lfr']) - base_rob
                 if len(results['robust_acc'].get('remove_high_lfr', [])) >= 2
                 else None)
        for tag, arm in (('lfr_vs_class_random', 'remove_class_random'),
                         ('lfr_vs_loss', 'remove_high_loss')):
            vals = results['robust_acc'].get(arm, [])
            if (g_lfr is not None and len(vals) >= 2
                    and not agg.get(arm, {}).get('degenerate')):
                g_o = np.array(vals) - base_rob
                extra[tag] = StatisticalTests.paired_permutation_test(
                    g_lfr, g_o, alternative='greater')
        vals = results['robust_acc'].get('remove_high_loss', [])
        if (len(vals) >= 2 and not agg.get('remove_high_loss', {}).get('degenerate')
                and len(results['robust_acc']['remove_random']) >= 2):
            extra['loss_vs_random'] = StatisticalTests.paired_permutation_test(
                np.array(vals) - base_rob, gain_r, alternative='greater')
        results['paired_controls'] = extra

    if logger:
        logger.info("  === CAUSAL RESULTS (primary: robust acc, fixed denominator) ===")
        for a in arms:
            if a in agg:
                logger.info(f"    {a:24s} robust={agg[a]['robust_acc_mean']:.1%} "
                            f"(gain {agg[a]['robust_gain_mean']:+.1%}) "
                            f"clean={agg[a]['clean_acc_mean']:.1%} "
                            f"ASR_pop={agg[a]['asr_population_mean']:.1%}")
        logger.info(f"  Ranking by robust gain: "
                    f"{[(a, f'{r:+.1%}') for a, r in ranking]}")
        for mn, pt in results.get('paired_vs_random', {}).items():
            logger.info(f"  High-{mn} vs random (paired sign-flip): "
                        f"mean diff={pt['observed_mean_diff']:+.3f}, "
                        f"p={pt['p_value']:.4f} "
                        f"(min attainable {pt['min_attainable_p']:.4f}, "
                        f"n={pt['n_pairs']})")
    return results


def evaluate_robustness(model: nn.Module, test_ds, eval_idx, device: str,
                        attack_epsilon: float = 8 / 255,
                        attack_alpha: float = 2 / 255,
                        attack_steps: int = 20, attack_restarts: int = 1,
                        population_mask=None, attack_seed: int = None,
                        batch_size: int = 128) -> Dict:
    """
    Robustness evaluation over a FIXED index array eval_idx.

    Returns (all over the SAME eval_idx population, so numbers are comparable
    across models/arms):
      clean_acc     : fraction of eval_idx classified correctly.
      robust_acc    : fraction of eval_idx that is correct AND survives the
                      attack. PRIMARY causal outcome: the denominator never
                      changes between arms.
      asr_own_correct : attack success among THIS model's clean-correct
                      samples (legacy quantity; denominator varies by model,
                      so an arm that loses clean accuracy on vulnerable
                      samples can look better - do not use as the causal
                      headline).
      asr_population : attack success among the samples selected by
                      population_mask (boolean over eval_idx; e.g. the
                      BASELINE model's clean-correct set), fixed across arms.
                      Attacks on samples this model already misclassifies
                      count as successes (the model fails them either way).

    attack_seed synchronizes attack randomness (random starts) across arms so
    treatment differences are not confounded with attack noise.
    """
    model.eval()
    pgd = PGDAttack(model, attack_epsilon, attack_alpha, steps=attack_steps,
                    device=device, restarts=attack_restarts)
    eval_idx = np.asarray(eval_idx)
    n = len(eval_idx)
    correct = np.zeros(n, dtype=bool)
    attacked_success = np.zeros(n, dtype=bool)

    if attack_seed is not None:
        torch.manual_seed(attack_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(attack_seed)

    for start in range(0, n, batch_size):
        chunk = eval_idx[start:start + batch_size]
        xs, ys = zip(*[test_ds[int(i)] for i in chunk])
        xb = torch.stack(xs).to(device)
        yb = torch.tensor(ys).to(device)
        with torch.no_grad():
            corr = (model(xb).argmax(1) == yb).cpu().numpy()
        correct[start:start + len(chunk)] = corr
        # Attack the entire chunk (population ASR needs results on samples
        # this model gets wrong too; those count as successes below).
        _, s = pgd.attack(xb, yb)
        attacked_success[start:start + len(chunk)] = s.cpu().numpy()

    clean_acc = float(correct.mean())
    # A sample survives iff clean-correct AND the attack failed to flip it.
    survives = correct & ~attacked_success
    robust_acc = float(survives.mean())
    own = correct
    asr_own = float(attacked_success[own].mean()) if own.any() else 0.0
    result = {"clean_acc": clean_acc, "robust_acc": robust_acc,
              "asr_own_correct": asr_own, "n_eval": int(n)}
    if population_mask is not None:
        pm = np.asarray(population_mask, dtype=bool)
        # On the fixed population: failure = misclassified clean OR attacked
        # successfully; equivalently 1 - survives.
        result["asr_population"] = float(1.0 - survives[pm].mean()) if pm.any() else 0.0
        result["population_size"] = int(pm.sum())
    return result


def compute_test_asr(model: nn.Module, test_ds, eval_idx, device: str,
                     batch_size: int = 128, return_acc: bool = False):
    """Back-compat wrapper (own-correct ASR). Prefer evaluate_robustness."""
    r = evaluate_robustness(model, test_ds, eval_idx, device,
                            batch_size=batch_size)
    if return_acc:
        return r["asr_own_correct"], r["clean_acc"]
    return r["asr_own_correct"]


# =============================================================================
# V28: ABLATION EXPERIMENTS - When does H_basin win?
# =============================================================================

def run_attack_strength_ablation(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 1000, n_perturbations: int = 64, epsilon: float = 0.1,
    train_epochs: int = 100, attack_steps_list: List[int] = None,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    ABLATION 1: Attack strength.
    Hypothesis: H_basin improves relative ranking with stronger attacks.
    """
    if attack_steps_list is None:
        attack_steps_list = [7, 20, 50, 100]
    
    if logger:
        logger.info("=" * 60)
        logger.info("ABLATION: Attack Strength")
        logger.info("=" * 60)
    
    from sklearn.metrics import roc_auc_score
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    # Train model once
    torch.manual_seed(42); np.random.seed(42)
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model, train_loader, train_epochs, device, logger=None)
    model.eval()
    
    # Compute all metrics once
    if logger: logger.info("Computing metrics for all samples...")
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    sample_data = []
    
    for idx in test_idx:
        x, y = test_ds[idx]
        x_b = x.unsqueeze(0).to(device)
        with torch.no_grad():
            logits = model(x_b)
            pred = logits.argmax(1).item()
            probs = F.softmax(logits, dim=1)
            conf = probs.max().item()
        if pred != y: continue
        
        metrics = compute_naive_perturbation_metrics(model, x, y, epsilon, n_perturbations, n_classes, device)
        baseline = compute_all_baselines(model, x, y, epsilon, n_perturbations, n_classes, device)
        sample_data.append({'x': x, 'y': y, 'metrics': metrics, 'baseline': baseline, 'conf': conf})
    
    if logger: logger.info(f"  {len(sample_data)} samples")
    
    # Test different attack strengths
    results = {'attack_steps': attack_steps_list, 'rankings': {}}
    attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
    attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
    
    metric_names = ['h_basin', 'gradient_norm', 'softmax_entropy', 'confidence', 'margin', 'local_lipschitz']
    
    for steps in attack_steps_list:
        if logger: logger.info(f"\n  PGD-{steps}:")
        pgd = PGDAttack(model, attack_eps, attack_alpha, steps=steps, device=device)
        
        attack_results = []
        for s in sample_data:
            x_b = s['x'].unsqueeze(0).to(device)
            y_b = torch.tensor([s['y']]).to(device)
            _, success = pgd.attack(x_b, y_b)
            attack_results.append(success.item())
        
        y_true = np.array(attack_results).astype(int)
        asr = y_true.mean()
        
        aucs = {}
        for mn in metric_names:
            if mn == 'h_basin':
                vals = np.array([s['metrics'].h_basin for s in sample_data])
            else:
                vals = np.array([getattr(s['baseline'], mn) for s in sample_data])
                if mn in ['margin', 'confidence']:
                    vals = -vals  # Higher margin/conf = less vulnerable
            
            if len(np.unique(y_true)) >= 2 and np.std(vals) > 1e-10:
                try:
                    aucs[mn] = roc_auc_score(y_true, vals)
                except Exception:
                    aucs[mn] = 0.5
            else:
                aucs[mn] = 0.5
        
        ranking = sorted(aucs.items(), key=lambda x: x[1], reverse=True)
        h_rank = [i for i, (n, _) in enumerate(ranking) if n == 'h_basin'][0] + 1
        
        results['rankings'][steps] = {
            'asr': float(asr),
            'aucs': {k: float(v) for k, v in aucs.items()},
            'ranking': ranking,
            'h_basin_rank': h_rank
        }
        
        if logger:
            logger.info(f"    ASR: {asr:.1%}")
            for i, (n, a) in enumerate(ranking):
                marker = " <-- H_basin" if n == 'h_basin' else ""
                logger.info(f"    {i+1}. {n}: {a:.4f}{marker}")
    
    return results


def run_phase_epsilon_ablation(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 1000, n_perturbations: int = 64,
    epsilon_list: List[float] = None, train_epochs: int = 100,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    ABLATION 2: PHASE epsilon.
    Hypothesis: There's an optimal epsilon where H_basin performs best.
    """
    if epsilon_list is None:
        epsilon_list = [0.05, 0.1, 0.15, 0.2]
    
    if logger:
        logger.info("=" * 60)
        logger.info("ABLATION: PHASE Epsilon")
        logger.info("=" * 60)
    
    from sklearn.metrics import roc_auc_score
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    # Train model once
    torch.manual_seed(42); np.random.seed(42)
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model, train_loader, train_epochs, device, logger=None)
    model.eval()
    
    # Get test samples and attack results once
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
    attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
    pgd = PGDAttack(model, attack_eps, attack_alpha, steps=20, device=device)
    
    sample_data = []
    for idx in test_idx:
        x, y = test_ds[idx]
        x_b = x.unsqueeze(0).to(device)
        y_b = torch.tensor([y]).to(device)
        with torch.no_grad():
            if model(x_b).argmax(1).item() != y: continue
        _, success = pgd.attack(x_b, y_b)
        sample_data.append({'x': x, 'y': y, 'attack_success': success.item()})
    
    if logger: logger.info(f"  {len(sample_data)} samples, ASR={np.mean([s['attack_success'] for s in sample_data]):.1%}")
    
    y_true = np.array([s['attack_success'] for s in sample_data]).astype(int)
    
    # Test different PHASE epsilons
    results = {'epsilon_list': epsilon_list, 'h_basin_aucs': {}}
    
    for eps in epsilon_list:
        if logger: logger.info(f"\n  PHASE epsilon={eps}:")
        
        h_basins = []
        for s in sample_data:
            metrics = compute_naive_perturbation_metrics(model, s['x'], s['y'], eps, n_perturbations, n_classes, device)
            h_basins.append(metrics.h_basin)
        
        h_vals = np.array(h_basins)
        if len(np.unique(y_true)) >= 2 and np.std(h_vals) > 1e-10:
            try:
                auc = roc_auc_score(y_true, h_vals)
            except Exception:
                auc = 0.5
        else:
            auc = 0.5
        
        results['h_basin_aucs'][eps] = float(auc)
        if logger: logger.info(f"    H_basin AUC: {auc:.4f}")
    
    # Find best epsilon
    best_eps = max(results['h_basin_aucs'].items(), key=lambda x: x[1])
    results['best_epsilon'] = best_eps[0]
    results['best_auc'] = best_eps[1]
    
    if logger:
        logger.info(f"\n  Best epsilon: {best_eps[0]} (AUC={best_eps[1]:.4f})")
    
    return results


def run_sample_difficulty_ablation(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 2000, n_perturbations: int = 64, epsilon: float = 0.1,
    train_epochs: int = 100, data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    ABLATION 3: Sample difficulty split.
    Hypothesis: H_basin excels on hard samples (low confidence) where boundary structure matters.
    """
    if logger:
        logger.info("=" * 60)
        logger.info("ABLATION: Sample Difficulty Split")
        logger.info("=" * 60)
    
    from sklearn.metrics import roc_auc_score
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    # Train model
    torch.manual_seed(42); np.random.seed(42)
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model, train_loader, train_epochs, device, logger=None)
    model.eval()
    
    # Collect samples with metrics
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
    attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
    pgd = PGDAttack(model, attack_eps, attack_alpha, steps=20, device=device)
    
    sample_data = []
    if logger: logger.info("Collecting samples...")
    
    for idx in test_idx:
        x, y = test_ds[idx]
        x_b = x.unsqueeze(0).to(device)
        y_b = torch.tensor([y]).to(device)
        
        with torch.no_grad():
            logits = model(x_b)
            pred = logits.argmax(1).item()
            probs = F.softmax(logits, dim=1)
            conf = probs.max().item()
            sorted_logits = torch.sort(logits, dim=1, descending=True)[0]
            margin = (sorted_logits[0, 0] - sorted_logits[0, 1]).item()
        
        if pred != y: continue
        
        metrics = compute_naive_perturbation_metrics(model, x, y, epsilon, n_perturbations, n_classes, device)
        baseline = compute_all_baselines(model, x, y, epsilon, n_perturbations, n_classes, device)
        _, success = pgd.attack(x_b, y_b)
        
        sample_data.append({
            'conf': conf, 'margin': margin,
            'h_basin': metrics.h_basin, 'baseline': baseline,
            'attack_success': success.item()
        })
    
    if logger: logger.info(f"  {len(sample_data)} samples")
    
    # Split by confidence
    confs = np.array([s['conf'] for s in sample_data])
    conf_median = np.percentile(confs, 50)
    easy_idx = [i for i, s in enumerate(sample_data) if s['conf'] >= conf_median]
    hard_idx = [i for i, s in enumerate(sample_data) if s['conf'] < conf_median]
    
    # Split by margin
    margins = np.array([s['margin'] for s in sample_data])
    margin_median = np.percentile(margins, 50)
    high_margin_idx = [i for i, s in enumerate(sample_data) if s['margin'] >= margin_median]
    low_margin_idx = [i for i, s in enumerate(sample_data) if s['margin'] < margin_median]
    
    results = {'splits': {}}
    metric_names = ['h_basin', 'gradient_norm', 'softmax_entropy', 'confidence', 'margin']
    
    splits = [
        ('all', list(range(len(sample_data)))),
        ('easy (high conf)', easy_idx),
        ('hard (low conf)', hard_idx),
        ('high margin', high_margin_idx),
        ('low margin', low_margin_idx)
    ]
    
    for split_name, indices in splits:
        if len(indices) < 50:
            continue
        
        y_true = np.array([sample_data[i]['attack_success'] for i in indices]).astype(int)
        asr = y_true.mean()
        
        if len(np.unique(y_true)) < 2:
            continue
        
        aucs = {}
        for mn in metric_names:
            if mn == 'h_basin':
                vals = np.array([sample_data[i]['h_basin'] for i in indices])
            else:
                vals = np.array([getattr(sample_data[i]['baseline'], mn) for i in indices])
                if mn in ['margin', 'confidence']:
                    vals = -vals
            
            if np.std(vals) > 1e-10:
                try:
                    aucs[mn] = roc_auc_score(y_true, vals)
                except Exception:
                    aucs[mn] = 0.5
            else:
                aucs[mn] = 0.5
        
        ranking = sorted(aucs.items(), key=lambda x: x[1], reverse=True)
        h_rank = [i for i, (n, _) in enumerate(ranking) if n == 'h_basin'][0] + 1
        
        results['splits'][split_name] = {
            'n_samples': len(indices),
            'asr': float(asr),
            'aucs': {k: float(v) for k, v in aucs.items()},
            'ranking': ranking,
            'h_basin_rank': h_rank
        }
        
        if logger:
            logger.info(f"\n  {split_name} (n={len(indices)}, ASR={asr:.1%}):")
            for i, (n, a) in enumerate(ranking):
                marker = " <-- H_basin" if n == 'h_basin' else ""
                logger.info(f"    {i+1}. {n}: {a:.4f}{marker}")
    
    # Summary
    if logger:
        logger.info(f"\n  === H_basin RANK BY SPLIT ===")
        for split_name, data in results['splits'].items():
            logger.info(f"    {split_name}: rank {data['h_basin_rank']}")
    
    return results


def run_hbasin_wins_ablation(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 1000, train_epochs: int = 100,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    Run ALL ablations to find conditions where H_basin wins.
    """
    # EXPLORATORY: this routine scans attacks/epsilons/difficulty splits and
    # selects the best condition post hoc; the selected winner must not be
    # presented as confirmatory evidence on the same data. Confirm on
    # held-out seeds/data or pre-register the condition.
    if logger:
        logger.info("=" * 60)
        logger.info("H_BASIN WINS ABLATION SUITE")
        logger.info("=" * 60)
    
    results = {"exploratory": True}
    
    # 1. Attack strength
    results['attack_strength'] = run_attack_strength_ablation(
        dataset, model_name, n_test_samples, 64, 0.1, train_epochs,
        [7, 20, 50, 100], data_dir, device, logger
    )
    
    # 2. PHASE epsilon
    results['phase_epsilon'] = run_phase_epsilon_ablation(
        dataset, model_name, n_test_samples, 64, [0.05, 0.1, 0.15, 0.2],
        train_epochs, data_dir, device, logger
    )
    
    # 3. Sample difficulty
    results['sample_difficulty'] = run_sample_difficulty_ablation(
        dataset, model_name, n_test_samples * 2, 64, 0.1, train_epochs,
        data_dir, device, logger
    )
    
    # Summary
    if logger:
        logger.info("\n" + "=" * 60)
        logger.info("SUMMARY: When does H_basin rank highest?")
        logger.info("=" * 60)
        
        # Best attack strength
        best_attack = min(results['attack_strength']['rankings'].items(), 
                         key=lambda x: x[1]['h_basin_rank'])
        logger.info(f"  Attack strength: Best at PGD-{best_attack[0]} (rank {best_attack[1]['h_basin_rank']})")
        
        # Best epsilon
        logger.info(f"  PHASE epsilon: Best at {results['phase_epsilon']['best_epsilon']} "
                   f"(AUC={results['phase_epsilon']['best_auc']:.4f})")
        
        # Best split
        best_split = min(results['sample_difficulty']['splits'].items(),
                        key=lambda x: x[1]['h_basin_rank'])
        logger.info(f"  Sample split: Best on '{best_split[0]}' (rank {best_split[1]['h_basin_rank']})")
    
    return results


# =============================================================================
# TABLE 4 & 5 (unchanged from v26)
# =============================================================================

@dataclass
class Table4Row:
    dataset: str; model: str; training: str; h_mean: float; h_mean_std: float
    h_max: float; roc_auc: float; roc_auc_ci: Tuple[float,float]; asr: float; clean_acc: float
    def to_dict(self): return asdict(self)

def run_table4_experiment(dataset: str, model_name: str, training: str='standard', n_seeds: int=5,
    n_test_samples: int=1000, n_perturbations: int=64, epsilon: float=0.1, train_epochs: int=100,
    data_dir: str='./data', device: str='cuda', logger=None) -> Table4Row:
    from sklearn.metrics import roc_auc_score
    from .adversarial import train_pgd, train_trades
    if logger: logger.info(f"Table 4: {dataset}/{model_name}/{training}, {n_seeds} seeds")
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    all_h, all_hmax, all_aucs, all_asr, all_acc = [], [], [], [], []
    for seed in range(n_seeds):
        if logger: logger.info(f"  Seed {seed+1}/{n_seeds}")
        torch.manual_seed(seed); np.random.seed(seed)
        if torch.cuda.is_available(): torch.cuda.manual_seed(seed)
        model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
        train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
        eps = DATASET_DEFAULTS.get(dataset,{}).get('attack_epsilon',8/255)
        alp = DATASET_DEFAULTS.get(dataset,{}).get('attack_alpha',2/255)
        if training=='standard': train_standard(model, train_loader, train_epochs, device)
        elif training=='pgd': train_pgd(model, train_loader, train_epochs, eps, alp, 7, device)
        elif training=='trades': train_trades(model, train_loader, train_epochs, eps, alp, 7, 6.0, device)
        model.eval()
        test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
        h_vals, atk_res = [], []; corr, tot = 0, 0
        pgd = PGDAttack(model, eps, alp, steps=20, device=device)
        for idx in test_idx:
            x, y = test_ds[idx]; x_b, y_b = x.unsqueeze(0).to(device), torch.tensor([y]).to(device)
            with torch.no_grad(): pred = model(x_b).argmax(1).item()
            tot += 1
            if pred==y: corr+=1
            else: continue
            m = compute_naive_perturbation_metrics(model, x, y, epsilon, n_perturbations, n_classes, device)
            h_vals.append(m.h_basin)
            _, s = pgd.attack(x_b, y_b); atk_res.append(s.item())
        if not atk_res: continue
        h_vals, atk_res = np.array(h_vals), np.array(atk_res)
        all_h.append(h_vals.mean()); all_hmax.append(h_vals.max())
        all_asr.append(atk_res.mean()); all_acc.append(corr/tot)
        if len(np.unique(atk_res))>=2 and np.std(h_vals)>1e-10:
            try: all_aucs.append(roc_auc_score(atk_res.astype(int), h_vals))
            except: pass
        if logger: logger.info(f"    H={h_vals.mean():.4f}, AUC={all_aucs[-1] if all_aucs else 0.5:.4f}")
    hm, hs = (float(np.mean(all_h)),
              float(np.std(all_h, ddof=1)) if len(all_h) > 1 else 0.0) if all_h else (0,0)
    am = float(np.mean(all_aucs)) if all_aucs else 0.5
    ci = stats.t.interval(0.95, len(all_aucs)-1, loc=am, scale=np.std(all_aucs, ddof=1)/np.sqrt(len(all_aucs))) if len(all_aucs)>=2 else (am,am)
    return Table4Row(dataset=dataset, model=model_name, training=training, h_mean=hm, h_mean_std=hs,
        h_max=float(np.mean(all_hmax)) if all_hmax else 0, roc_auc=am, roc_auc_ci=(float(ci[0]),float(ci[1])),
        asr=float(np.mean(all_asr)) if all_asr else 0, clean_acc=float(np.mean(all_acc)) if all_acc else 0)


def run_table5_experiment(dataset: str='cifar10', model_name: str='cifar_cnn', n_seeds: int=10,
    n_test_samples: int=1000, n_perturbations: int=64, epsilon: float=0.1, train_epochs: int=100,
    data_dir: str='./data', device: str='cuda', logger=None) -> Dict:
    from sklearn.metrics import roc_auc_score
    if logger: logger.info(f"Table 5: {dataset}/{model_name}, {n_seeds} seeds")
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    mns = ['h_basin','gradient_norm','local_lipschitz','margin','softmax_entropy','confidence']
    all_aucs = {n: [] for n in mns}
    for seed in range(n_seeds):
        if logger: logger.info(f"  Seed {seed+1}/{n_seeds}")
        torch.manual_seed(seed); np.random.seed(seed)
        if torch.cuda.is_available(): torch.cuda.manual_seed(seed)
        model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
        train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
        train_standard(model, train_loader, train_epochs, device)
        model.eval()
        test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
        samples, atks = [], []
        eps = DATASET_DEFAULTS.get(dataset,{}).get('attack_epsilon',8/255)
        alp = DATASET_DEFAULTS.get(dataset,{}).get('attack_alpha',2/255)
        pgd = PGDAttack(model, eps, alp, steps=20, device=device)
        for idx in test_idx:
            x, y = test_ds[idx]; x_b, y_b = x.unsqueeze(0).to(device), torch.tensor([y]).to(device)
            with torch.no_grad():
                if model(x_b).argmax(1).item() != y: continue
            bl = compute_all_baselines(model, x, y, epsilon, n_perturbations, n_classes, device)
            samples.append(bl)
            _, s = pgd.attack(x_b, y_b); atks.append(s.item())
        if not atks: continue
        y_true = np.array(atks).astype(int)
        for n in mns:
            vals = np.array([getattr(b, n) for b in samples])
            if n in ['margin','confidence']: vals = -vals
            if len(np.unique(y_true))>=2 and np.std(vals)>1e-10:
                try: all_aucs[n].append(roc_auc_score(y_true, vals))
                except: pass
    results = {'dataset': dataset, 'model': model_name, 'n_seeds': n_seeds, 'metrics': {}}
    for n in mns:
        v = all_aucs[n]
        m, s = (float(np.mean(v)),
                float(np.std(v, ddof=1)) if len(v) > 1 else 0.0) if v else (0.5, 0)
        ci = stats.t.interval(0.95, len(v)-1, loc=m, scale=s/np.sqrt(len(v))) if len(v)>=2 else (m,m)
        results['metrics'][n] = {'mean': m, 'std': s, 'ci': (float(ci[0]),float(ci[1])), 'gradient_free': n not in ['gradient_norm','local_lipschitz']}
    ranking = sorted(results['metrics'].items(), key=lambda x: x[1]['mean'], reverse=True)
    results['ranking'] = [(n,d['mean']) for n,d in ranking]
    results['h_basin_rank'] = [i for i,(n,_) in enumerate(results['ranking']) if n=='h_basin'][0]+1
    if logger:
        logger.info(f"  === TABLE 5 RANKING ===")
        for i,(n,a) in enumerate(results['ranking']):
            logger.info(f"    {i+1}. {n}: {a:.4f}{' <-- H_basin' if n=='h_basin' else ''}")
    return results


@dataclass
class BaselineMetrics:
    h_basin: float; gradient_norm: float; local_lipschitz: float
    margin: float; softmax_entropy: float; confidence: float

def compute_all_baselines(model, x, y, epsilon, n_pert, n_classes, device):
    model.eval(); x = x.to(device)
    if x.dim()==3: x = x.unsqueeze(0)
    hm = compute_naive_perturbation_metrics(model, x.squeeze(0), y, epsilon, n_pert, n_classes, device)
    xg = x.clone().requires_grad_(True)
    logits = model(xg); loss = F.cross_entropy(logits, torch.tensor([y]).to(device))
    loss.backward(); gn = float(xg.grad.norm().item())
    with torch.no_grad():
        logits = model(x); probs = F.softmax(logits, dim=1)
        conf = float(probs.max().item())
        sent = float((-probs * torch.log(probs + 1e-10)).sum().item())
        sl = torch.sort(logits, dim=1, descending=True)[0]
        marg = float((sl[0,0] - sl[0,1]).item())
    from .adversarial import local_lipschitz_batch
    lip = float(local_lipschitz_batch(model, x, n_samples=10)[0])
    return BaselineMetrics(h_basin=hm.h_basin, gradient_norm=gn, local_lipschitz=lip, margin=marg, softmax_entropy=sent, confidence=conf)


# =============================================================================
# SUITE RUNNERS
# =============================================================================

def run_naive_baselines_suite(datasets=['cifar10','cifar100'], models=['cifar_cnn','resnet18'], n_seeds=5,
    n_test_samples=1000, train_epochs=100, data_dir='./data', device='cuda', logger=None) -> Dict:
    if logger: logger.info("="*60 + "\nNAIVE BASELINES SUITE\n" + "="*60)
    results = {'experiments': [], 'summary': []}
    for ds in datasets:
        for m in models:
            if ds=='mnist' and m!='simple_cnn': continue
            if ds in ['cifar10','cifar100','svhn'] and m=='simple_cnn': continue
            try:
                r = run_naive_baselines_experiment(ds, m, n_seeds, n_test_samples, 64, 0.1, train_epochs, data_dir, device, logger)
                results['experiments'].append(r.to_dict())
                results['summary'].append({'dataset':ds,'model':m,'h_basin':r.h_basin_auc[0],'rank':r.h_basin_rank})
            except Exception as e:
                if logger: logger.error(f"Failed {ds}/{m}: {e}")
    return results


def run_table4_suite(experiments=None, n_seeds=5, n_test_samples=1000, train_epochs=100,
    data_dir='./data', device='cuda', logger=None) -> Dict:
    if experiments is None:
        experiments = [('cifar10','cifar_cnn','standard'),('cifar10','resnet18','standard'),
                       ('cifar100','cifar_cnn','standard'),('cifar100','resnet18','standard')]
    if logger: logger.info("="*60 + "\nTABLE 4 SUITE\n" + "="*60)
    results = {'rows': []}
    for ds, m, tr in experiments:
        try:
            r = run_table4_experiment(ds, m, tr, n_seeds, n_test_samples, 64, 0.1, train_epochs, data_dir, device, logger)
            results['rows'].append(r.to_dict())
        except Exception as e:
            if logger: logger.error(f"Failed {ds}/{m}/{tr}: {e}")
    return results


def run_bulletproof_suite(data_dir='./data', device='cuda', logger=None) -> Dict:
    """Run ALL bulletproof experiments."""
    if logger: logger.info("="*60 + "\nBULLETPROOF SUITE\n" + "="*60)
    results = {}
    results['games_null'] = run_games_null_test(logger=logger)
    results['compression'] = run_compression_split_comparison(data_dir=data_dir, device=device, logger=logger)
    results['causal'] = run_causal_intervention(data_dir=data_dir, device=device, logger=logger)
    return results


# Legacy
def run_reviewer_proof_experiments(config: OptionBConfig, logger=None) -> Dict:
    return {'naive_baselines': run_naive_baselines_experiment(config.dataset, config.model_name, config.n_seeds, config.n_test_samples, 64, 0.1, 100, config.data_dir, 'cuda' if torch.cuda.is_available() else 'cpu', logger).to_dict()}

def run_baseline_comparison(*a, **kw): return run_table5_experiment(*a, **kw)

def run_sample_complexity_study(model, dataset, n_samples=100, n_values=None, n_repeats=20, epsilon=0.1, device='cuda', logger=None):
    if n_values is None: n_values = [5,10,20,50,100,200]
    model.eval(); results = {'n_values': n_values, 'mean_h': [], 'std_h': []}
    with torch.no_grad(): K = model(dataset[0][0].unsqueeze(0).to(device)).shape[1]
    idx = np.random.choice(len(dataset), n_samples, replace=False)
    for n in n_values:
        hs = []
        for i in idx:
            x, _ = dataset[i]; x = x.to(device)
            hr = []
            for _ in range(n_repeats):
                c = np.zeros(K)
                for _ in range(n):
                    d = torch.empty_like(x).uniform_(-epsilon, epsilon)
                    with torch.no_grad(): c[model(torch.clamp(x+d,0,1).unsqueeze(0)).argmax(1).item()] += 1
                hr.append(compute_basin_entropy(c))
            hs.append({'mean': np.mean(hr), 'std': np.std(hr)})
        results['mean_h'].append(np.mean([e['mean'] for e in hs]))
        results['std_h'].append(np.mean([e['std'] for e in hs]))
    return results


# =============================================================================
# V30: NAIVE METRICS FAIL EXPERIMENTS
# =============================================================================


class CWAttack:
    """Carlini-Wagner L2 attack (simplified)."""
    def __init__(self, model, c=1.0, steps=50, lr=0.01, device='cuda'):
        self.model = model
        self.c = c
        self.steps = steps
        self.lr = lr
        self.device = device
    
    def attack(self, x, y):
        x_adv = x.clone().detach()
        delta = torch.zeros_like(x, requires_grad=True)
        optimizer = torch.optim.Adam([delta], lr=self.lr)
        
        for _ in range(self.steps):
            x_pert = torch.clamp(x + delta, 0, 1)
            logits = self.model(x_pert)
            
            # CW loss: maximize margin between true class and next best
            one_hot = F.one_hot(y, logits.shape[1]).float()
            real = (one_hot * logits).sum(1)
            other = ((1 - one_hot) * logits - one_hot * 1e9).max(1)[0]
            loss = torch.clamp(real - other + 0.01, min=0).sum()
            loss += self.c * (delta ** 2).sum()
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        
        x_adv = torch.clamp(x + delta.detach(), 0, 1)
        with torch.no_grad():
            pred = self.model(x_adv).argmax(1)
            success = (pred != y)
        return x_adv, success


def run_attack_transfer_experiment(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 1000, n_perturbations: int = 64, epsilon: float = 0.1,
    train_epochs: int = 100, data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    V30 EXPERIMENT 1: Attack Transfer
    
    Train metrics on PGD attack, test on FGSM and CW attacks.
    Naive metrics should overfit to PGD; H_basin should transfer better.
    """
    from sklearn.metrics import roc_auc_score
    
    if logger:
        logger.info("=" * 60)
        logger.info("V30 EXP 1: ATTACK TRANSFER")
        logger.info("=" * 60)
        logger.info("Hypothesis: H_basin transfers across attack types better than naive metrics")
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    # Train model
    torch.manual_seed(42); np.random.seed(42)
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model, train_loader, train_epochs, device, logger=None)
    model.eval()
    
    # Setup attacks
    attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
    attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
    
    attacks = {
        'PGD-20': PGDAttack(model, attack_eps, attack_alpha, steps=20, device=device),
        'PGD-100': PGDAttack(model, attack_eps, attack_alpha, steps=100, device=device),
        'FGSM': FGSMAttack(model, attack_eps, device=device),
        'CW': CWAttack(model, c=1.0, steps=50, device=device),
    }
    
    # Collect samples with metrics
    if logger: logger.info("Computing metrics for samples...")
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    
    sample_data = []
    for idx in test_idx:
        x, y = test_ds[idx]
        x_b = x.unsqueeze(0).to(device)
        y_b = torch.tensor([y]).to(device)
        
        with torch.no_grad():
            if model(x_b).argmax(1).item() != y:
                continue
        
        # Compute all metrics once
        metrics = compute_naive_perturbation_metrics(model, x, y, epsilon, n_perturbations, n_classes, device)
        
        # Run all attacks
        attack_results = {}
        for atk_name, atk in attacks.items():
            _, success = atk.attack(x_b, y_b)
            attack_results[atk_name] = success.item()
        
        sample_data.append({
            'h_basin': metrics.h_basin,
            'lfr': metrics.lfr,
            'logvar': metrics.logvar,
            'mcent': metrics.mcent,
            'margdrop': metrics.margdrop,
            'attacks': attack_results
        })
    
    if logger: logger.info(f"  Collected {len(sample_data)} samples")
    
    # Compute AUC for each metric × attack combination
    metric_names = ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop']
    attack_names = list(attacks.keys())
    
    results = {'n_samples': len(sample_data), 'aucs': {}, 'transfer_gaps': {}}
    
    for mn in metric_names:
        results['aucs'][mn] = {}
        vals = np.array([s[mn] for s in sample_data])
        
        for atk_name in attack_names:
            y_true = np.array([s['attacks'][atk_name] for s in sample_data]).astype(int)
            if len(np.unique(y_true)) >= 2 and np.std(vals) > 1e-10:
                try:
                    auc = roc_auc_score(y_true, vals)
                except Exception:
                    auc = 0.5
            else:
                auc = 0.5
            results['aucs'][mn][atk_name] = float(auc)
    
    # Compute transfer gap (PGD-20 to other attacks)
    for mn in metric_names:
        pgd_auc = results['aucs'][mn]['PGD-20']
        gaps = []
        for atk_name in ['FGSM', 'CW', 'PGD-100']:
            gap = results['aucs'][mn][atk_name] - pgd_auc
            gaps.append(gap)
        results['transfer_gaps'][mn] = {
            'mean_gap': float(np.mean(gaps)),
            'gaps': {atk: results['aucs'][mn][atk] - pgd_auc for atk in ['FGSM', 'CW', 'PGD-100']}
        }
    
    # PRIMARY ranking: performance on the TARGET conditions themselves
    # (worst-case AUC across the transfer attacks, tiebreak by mean). Ranking
    # by AUC-change rewards useless-but-stable metrics: a metric at 0.51
    # everywhere "transfers better" than one dropping 0.90 -> 0.80. Gap is
    # kept as a SECONDARY descriptor, interpretable only given adequate AUC.
    transfer_attacks = ['FGSM', 'CW', 'PGD-100']
    results['target_auc'] = {
        mn: {'worst': float(min(results['aucs'][mn][a] for a in transfer_attacks)),
             'mean': float(np.mean([results['aucs'][mn][a] for a in transfer_attacks]))}
        for mn in metric_names}
    primary = sorted(results['target_auc'].items(),
                     key=lambda x: (-x[1]['worst'], -x[1]['mean']))
    results['transfer_ranking_primary'] = [(n, d['worst']) for n, d in primary]
    results['h_basin_transfer_rank'] = [i for i, (n, _) in
                                        enumerate(results['transfer_ranking_primary'])
                                        if n == 'h_basin'][0] + 1
    # secondary (descriptive only)
    transfer_ranking = sorted(results['transfer_gaps'].items(),
                              key=lambda x: x[1]['mean_gap'], reverse=True)
    results['transfer_gap_ranking_secondary'] = [(n, d['mean_gap'])
                                                 for n, d in transfer_ranking]
    
    if logger:
        logger.info("\n  AUC by Attack Type:")
        logger.info(f"  {'Metric':<12} {'PGD-20':<10} {'PGD-100':<10} {'FGSM':<10} {'CW':<10} {'Transfer':<10}")
        logger.info("  " + "-" * 62)
        for mn in metric_names:
            aucs = results['aucs'][mn]
            tg = results['transfer_gaps'][mn]['mean_gap']
            marker = " <--" if mn == 'h_basin' else ""
            logger.info(f"  {mn:<12} {aucs['PGD-20']:<10.4f} {aucs['PGD-100']:<10.4f} "
                       f"{aucs['FGSM']:<10.4f} {aucs['CW']:<10.4f} {tg:+.4f}{marker}")
        
        logger.info(f"\n  PRIMARY ranking (worst-case target AUC):")
        for i, (n, w) in enumerate(results['transfer_ranking_primary']):
            marker = " <-- H_basin" if n == 'h_basin' else ""
            logger.info(f"    {i+1}. {n}: worst AUC={w:.4f}{marker}")
    
    return results


def run_epsilon_stability_experiment(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 500, n_perturbations: int = 64,
    epsilon_values: List[float] = None, train_epochs: int = 100,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    V30 EXPERIMENT 2: Epsilon Stability
    
    Compute metrics at different perturbation budgets.
    Naive metrics should vary wildly; H_basin should be more stable.
    """
    from sklearn.metrics import roc_auc_score
    
    if epsilon_values is None:
        epsilon_values = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3]
    
    if logger:
        logger.info("=" * 60)
        logger.info("V30 EXP 2: EPSILON STABILITY")
        logger.info("=" * 60)
        logger.info("Hypothesis: H_basin is more stable across perturbation budgets")
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    # Train model
    torch.manual_seed(42); np.random.seed(42)
    model = get_model(model_name, n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model, train_loader, train_epochs, device, logger=None)
    model.eval()
    
    # Get attack results once (fixed)
    attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
    attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
    pgd = PGDAttack(model, attack_eps, attack_alpha, steps=20, device=device)
    
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    
    # Collect samples
    samples = []
    for idx in test_idx:
        x, y = test_ds[idx]
        x_b = x.unsqueeze(0).to(device)
        y_b = torch.tensor([y]).to(device)
        with torch.no_grad():
            if model(x_b).argmax(1).item() != y:
                continue
        _, success = pgd.attack(x_b, y_b)
        samples.append({'x': x, 'y': y, 'attack_success': success.item()})
    
    if logger: logger.info(f"  {len(samples)} samples, computing metrics at {len(epsilon_values)} epsilon values...")
    
    y_true = np.array([s['attack_success'] for s in samples]).astype(int)
    
    # Compute metrics at each epsilon
    metric_names = ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop']
    results = {'epsilon_values': epsilon_values, 'aucs': {mn: [] for mn in metric_names}}
    
    for eps in epsilon_values:
        if logger: logger.info(f"    epsilon={eps}...")
        
        all_metrics = {mn: [] for mn in metric_names}
        for s in samples:
            m = compute_naive_perturbation_metrics(model, s['x'], s['y'], eps, n_perturbations, n_classes, device)
            all_metrics['h_basin'].append(m.h_basin)
            all_metrics['lfr'].append(m.lfr)
            all_metrics['logvar'].append(m.logvar)
            all_metrics['mcent'].append(m.mcent)
            all_metrics['margdrop'].append(m.margdrop)
        
        for mn in metric_names:
            vals = np.array(all_metrics[mn])
            if len(np.unique(y_true)) >= 2 and np.std(vals) > 1e-10:
                try:
                    auc = roc_auc_score(y_true, vals)
                except Exception:
                    auc = 0.5
            else:
                auc = 0.5
            results['aucs'][mn].append(float(auc))
    
    # Compute stability (std of AUC across epsilons)
    results['stability'] = {}
    for mn in metric_names:
        aucs = results['aucs'][mn]
        results['stability'][mn] = {
            'mean_auc': float(np.mean(aucs)),
            'std_auc': float(np.std(aucs)),
            'range': float(max(aucs) - min(aucs))
        }
    
    # PRIMARY ranking: worst-case AUC across epsilon values (a constant-0.51
    # metric is maximally "stable" and useless). Stability std is SECONDARY,
    # interpretable only given adequate worst-case performance.
    results['target_auc'] = {mn: {'worst': float(min(results['aucs'][mn])),
                                  'mean': float(np.mean(results['aucs'][mn]))}
                             for mn in metric_names}
    primary = sorted(results['target_auc'].items(),
                     key=lambda x: (-x[1]['worst'], -x[1]['mean']))
    results['epsilon_ranking_primary'] = [(n, d['worst']) for n, d in primary]
    results['h_basin_epsilon_rank'] = [i for i, (n, _) in
                                       enumerate(results['epsilon_ranking_primary'])
                                       if n == 'h_basin'][0] + 1
    stability_ranking = sorted(results['stability'].items(), key=lambda x: x[1]['std_auc'])
    results['stability_ranking_secondary'] = [(n, d['std_auc']) for n, d in stability_ranking]
    
    if logger:
        logger.info("\n  AUC by Epsilon:")
        header = f"  {'Metric':<12}" + "".join(f"{e:<10}" for e in epsilon_values) + f"{'Std':<10}"
        logger.info(header)
        logger.info("  " + "-" * (12 + 10 * len(epsilon_values) + 10))
        for mn in metric_names:
            aucs = results['aucs'][mn]
            std = results['stability'][mn]['std_auc']
            row = f"  {mn:<12}" + "".join(f"{a:<10.4f}" for a in aucs) + f"{std:<10.4f}"
            if mn == 'h_basin':
                row += " <--"
            logger.info(row)
        
        logger.info(f"\n  PRIMARY ranking (worst-case AUC across epsilons):")
        for i, (n, w) in enumerate(results['epsilon_ranking_primary']):
            marker = " <-- H_basin" if n == 'h_basin' else ""
            logger.info(f"    {i+1}. {n}: worst AUC={w:.4f}{marker}")
    
    return results


def run_model_transfer_experiment(
    dataset: str = 'cifar10', n_test_samples: int = 500, n_perturbations: int = 64,
    epsilon: float = 0.1, train_epochs: int = 100,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    V30 EXPERIMENT 3: Model Transfer
    
    Compute metrics on Model A (CNN), predict attack success on Model B (ResNet-18).
    Naive metrics are model-specific; H_basin should capture transferable geometry.
    """
    from sklearn.metrics import roc_auc_score
    
    if logger:
        logger.info("=" * 60)
        logger.info("V30 EXP 3: MODEL TRANSFER")
        logger.info("=" * 60)
        logger.info("Hypothesis: H_basin transfers across models better than naive metrics")
    
    train_ds, n_classes, in_ch = load_dataset(dataset, data_dir, train=True)
    test_ds, _, _ = load_dataset(dataset, data_dir, train=False)
    
    # Train Model A (CNN)
    if logger: logger.info("  Training Model A (cifar_cnn)...")
    torch.manual_seed(42); np.random.seed(42)
    model_a = get_model('cifar_cnn', n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model_a, train_loader, train_epochs, device, logger=None)
    model_a.eval()
    
    # Train Model B (ResNet-18)
    if logger: logger.info("  Training Model B (resnet18)...")
    torch.manual_seed(43); np.random.seed(43)
    model_b = get_model('resnet18', n_classes, in_ch, dataset=dataset).to(device)
    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2, pin_memory=True)
    train_standard(model_b, train_loader, train_epochs, device, logger=None)
    model_b.eval()
    
    # Setup attacks
    attack_eps = DATASET_DEFAULTS.get(dataset, {}).get('attack_epsilon', 8/255)
    attack_alpha = DATASET_DEFAULTS.get(dataset, {}).get('attack_alpha', 2/255)
    pgd_a = PGDAttack(model_a, attack_eps, attack_alpha, steps=20, device=device)
    pgd_b = PGDAttack(model_b, attack_eps, attack_alpha, steps=20, device=device)
    
    # Collect samples
    if logger: logger.info("  Computing metrics and attacks...")
    test_idx = np.random.choice(len(test_ds), min(n_test_samples, len(test_ds)), replace=False)
    
    sample_data = []
    for idx in test_idx:
        x, y = test_ds[idx]
        x_b = x.unsqueeze(0).to(device)
        y_b = torch.tensor([y]).to(device)
        
        # Both models must classify correctly
        with torch.no_grad():
            if model_a(x_b).argmax(1).item() != y:
                continue
            if model_b(x_b).argmax(1).item() != y:
                continue
        
        # Metrics from Model A
        metrics_a = compute_naive_perturbation_metrics(model_a, x, y, epsilon, n_perturbations, n_classes, device)
        
        # Attack results on both models
        _, success_a = pgd_a.attack(x_b, y_b)
        _, success_b = pgd_b.attack(x_b, y_b)
        
        sample_data.append({
            'h_basin': metrics_a.h_basin,
            'lfr': metrics_a.lfr,
            'logvar': metrics_a.logvar,
            'mcent': metrics_a.mcent,
            'margdrop': metrics_a.margdrop,
            'attack_a': success_a.item(),
            'attack_b': success_b.item()
        })
    
    if logger: logger.info(f"  Collected {len(sample_data)} samples (both models correct)")
    
    # Compute AUC: metrics from A predicting attacks on A and B
    metric_names = ['h_basin', 'lfr', 'logvar', 'mcent', 'margdrop']
    results = {'n_samples': len(sample_data), 'aucs': {}, 'transfer_gaps': {}}
    
    y_true_a = np.array([s['attack_a'] for s in sample_data]).astype(int)
    y_true_b = np.array([s['attack_b'] for s in sample_data]).astype(int)
    
    for mn in metric_names:
        vals = np.array([s[mn] for s in sample_data])
        
        # AUC on Model A (same model)
        if len(np.unique(y_true_a)) >= 2 and np.std(vals) > 1e-10:
            try:
                auc_a = roc_auc_score(y_true_a, vals)
            except Exception:
                auc_a = 0.5
        else:
            auc_a = 0.5
        
        # AUC on Model B (transfer)
        if len(np.unique(y_true_b)) >= 2 and np.std(vals) > 1e-10:
            try:
                auc_b = roc_auc_score(y_true_b, vals)
            except Exception:
                auc_b = 0.5
        else:
            auc_b = 0.5
        
        results['aucs'][mn] = {'model_a': float(auc_a), 'model_b': float(auc_b)}
        results['transfer_gaps'][mn] = float(auc_b - auc_a)
    
    # Rank by transfer gap (higher = better transfer)
    transfer_ranking = sorted(results['transfer_gaps'].items(), key=lambda x: x[1], reverse=True)
    results['transfer_ranking'] = transfer_ranking
    results['h_basin_transfer_rank'] = [i for i, (n, _) in enumerate(transfer_ranking) if n == 'h_basin'][0] + 1
    
    if logger:
        logger.info("\n  AUC: Metrics from Model A predicting attacks on A and B")
        logger.info(f"  {'Metric':<12} {'Model A':<12} {'Model B':<12} {'Transfer Gap':<12}")
        logger.info("  " + "-" * 48)
        for mn in metric_names:
            aucs = results['aucs'][mn]
            gap = results['transfer_gaps'][mn]
            marker = " <--" if mn == 'h_basin' else ""
            logger.info(f"  {mn:<12} {aucs['model_a']:<12.4f} {aucs['model_b']:<12.4f} {gap:+.4f}{marker}")
        
        logger.info(f"\n  Transfer Ranking (higher gap = better transfer):")
        for i, (n, gap) in enumerate(transfer_ranking):
            marker = " <-- H_basin" if n == 'h_basin' else ""
            logger.info(f"    {i+1}. {n}: {gap:+.4f}{marker}")
    
    return results


def run_toy_validation_experiment(
    n_samples: int = 1000, n_perturbations: int = 100, epsilon: float = 0.1,
    logger=None
) -> Dict:
    """
    V30 EXPERIMENT 4: Toy System Validation
    
    Double-well potential where we KNOW true phase boundaries.
    H_basin should correlate with true boundary distance; naive metrics won't.
    """
    if logger:
        logger.info("=" * 60)
        logger.info("V30 EXP 4: TOY SYSTEM VALIDATION")
        logger.info("=" * 60)
        logger.info("Hypothesis: H_basin correlates with true phase boundary distance")
    
    # Double-well potential: V(x) = (x^2 - 1)^2
    # Phase boundary at x = 0
    # Left basin: x < 0, Right basin: x > 0
    
    def classify_point(x):
        """Classify based on which basin the point converges to."""
        return 0 if x < 0 else 1
    
    def compute_metrics_1d(x, epsilon, n_pert):
        """Compute H_basin and naive metrics for 1D point."""
        clean_class = classify_point(x)
        
        basin_counts = np.array([0, 0])
        flips = 0
        
        for _ in range(n_pert):
            x_pert = x + np.random.uniform(-epsilon, epsilon)
            pert_class = classify_point(x_pert)
            basin_counts[pert_class] += 1
            if pert_class != clean_class:
                flips += 1
        
        h_basin = compute_basin_entropy(basin_counts)
        lfr = flips / n_pert
        
        return {'h_basin': h_basin, 'lfr': lfr, 'boundary_distance': abs(x)}
    
    # Sample points
    np.random.seed(42)
    x_values = np.random.uniform(-2, 2, n_samples)
    
    results_data = []
    for x in x_values:
        m = compute_metrics_1d(x, epsilon, n_perturbations)
        results_data.append(m)
    
    # Compute correlations with boundary distance
    boundary_dist = np.array([d['boundary_distance'] for d in results_data])
    h_basins = np.array([d['h_basin'] for d in results_data])
    lfrs = np.array([d['lfr'] for d in results_data])
    
    # Correlation: metrics should be HIGH near boundary (low distance)
    # So we expect NEGATIVE correlation with boundary distance
    from scipy.stats import pearsonr, spearmanr
    
    results = {
        'h_basin': {
            'pearson': float(pearsonr(h_basins, -boundary_dist)[0]),  # negative because high H = near boundary
            'spearman': float(spearmanr(h_basins, -boundary_dist)[0])
        },
        'lfr': {
            'pearson': float(pearsonr(lfrs, -boundary_dist)[0]),
            'spearman': float(spearmanr(lfrs, -boundary_dist)[0])
        }
    }
    
    # Both should correlate, but let's check who's better
    results['h_basin_wins'] = abs(results['h_basin']['spearman']) > abs(results['lfr']['spearman'])
    
    if logger:
        logger.info(f"\n  Correlation with proximity to phase boundary:")
        logger.info(f"  {'Metric':<12} {'Pearson':<12} {'Spearman':<12}")
        logger.info("  " + "-" * 36)
        logger.info(f"  {'H_basin':<12} {results['h_basin']['pearson']:<12.4f} {results['h_basin']['spearman']:<12.4f}")
        logger.info(f"  {'LFR':<12} {results['lfr']['pearson']:<12.4f} {results['lfr']['spearman']:<12.4f}")
        
        if results['h_basin_wins']:
            logger.info(f"\n  ✓ H_basin has stronger correlation with true boundary")
        else:
            logger.info(f"\n  Note: LFR has stronger correlation (expected for 1D case)")
    
    return results


def run_naive_fails_suite(
    dataset: str = 'cifar10', model_name: str = 'cifar_cnn',
    n_test_samples: int = 500, train_epochs: int = 100,
    data_dir: str = './data', device: str = 'cuda', logger=None
) -> Dict:
    """
    V30: Run ALL "naive metrics fail" experiments.
    """
    if logger:
        logger.info("=" * 60)
        logger.info("V30: NAIVE METRICS FAIL - FULL SUITE")
        logger.info("=" * 60)
    
    results = {}
    
    # Experiment 1: Attack Transfer
    results['attack_transfer'] = run_attack_transfer_experiment(
        dataset, model_name, n_test_samples, 64, 0.1, train_epochs, data_dir, device, logger
    )
    
    # Experiment 2: Epsilon Stability
    results['epsilon_stability'] = run_epsilon_stability_experiment(
        dataset, model_name, n_test_samples, 64, None, train_epochs, data_dir, device, logger
    )
    
    # Experiment 3: Model Transfer
    results['model_transfer'] = run_model_transfer_experiment(
        dataset, n_test_samples, 64, 0.1, train_epochs, data_dir, device, logger
    )
    
    # Experiment 4: Toy Validation
    results['toy_validation'] = run_toy_validation_experiment(1000, 100, 0.1, logger)
    
    # Summary
    if logger:
        logger.info("\n" + "=" * 60)
        logger.info("SUMMARY: Where H_basin Wins")
        logger.info("=" * 60)
        
        wins = []
        
        # Attack transfer
        at_rank = results['attack_transfer']['h_basin_transfer_rank']
        if at_rank <= 2:
            wins.append(f"Attack Transfer: Rank {at_rank}")
        logger.info(f"  Attack Transfer: H_basin rank {at_rank}/5")
        
        # Epsilon stability
        es_rank = results['epsilon_stability']['h_basin_stability_rank']
        if es_rank <= 2:
            wins.append(f"Epsilon Stability: Rank {es_rank}")
        logger.info(f"  Epsilon Stability: H_basin rank {es_rank}/5")
        
        # Model transfer
        mt_rank = results['model_transfer']['h_basin_transfer_rank']
        if mt_rank <= 2:
            wins.append(f"Model Transfer: Rank {mt_rank}")
        logger.info(f"  Model Transfer: H_basin rank {mt_rank}/5")
        
        # Toy validation
        toy_wins = results['toy_validation']['h_basin_wins']
        if toy_wins:
            wins.append("Toy Validation: Best correlation")
        logger.info(f"  Toy Validation: H_basin wins = {toy_wins}")
        
        logger.info(f"\n  H_basin advantages: {len(wins)}/4")
        for w in wins:
            logger.info(f"    ✓ {w}")
    
    return results
