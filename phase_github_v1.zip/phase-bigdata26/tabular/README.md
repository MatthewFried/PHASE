# tabular: PHASE on tabular data

| File | Purpose |
|---|---|
| `phase_tabular.py` | Core: perturbation clouds, H and LFR, Proposition 1 diagnostics, gates. Model-agnostic via `predict_fn(X) -> labels`. |
| `tabular_hunt.py` | Calibration ladder on digits, letter, adult, covertype under early-stopped, overfit, and overfit with 20% train-label noise. Each cell scores the cloud/softmax mixture against the raw softmax, temperature scaling, isotonic (binary) or vector scaling (multiclass), and the best flexible softmax-only map from `flex_calib.py`, with bootstrap CIs. `--perturb all` is the paper's rule; `--perturb continuous` holds binary and one-hot columns fixed. |
| `flex_calib.py` | Softmax-only recalibrators (temperature, vector or isotonic, Dirichlet with ODIR regularization, gradient-boosted trees on the log-softmax), cross-fitted on the validation split; the comparator is the family member with the lowest out-of-fold NLL. The test split is never used for selection. |
| `escape_test.py` | Exploratory: does escape entropy track disagreement among independently trained models, controlling for LFR, margin and predicted class? Not reported in the paper. |
| `cardia_adapter.py`, `cardia_campaign.py`, `cardia_forecast.py`, `run_cardia_phase.py`, `check_metsyn_thresholds.py` | CARDIA pipeline. These need the restricted CARDIA extract and the project's `cardia_loader.py`, neither of which is distributed. |
| `smoke_synthetic.py` | Fast synthetic check of the core. |
| `run_tests.py` | Regression tests (column freezing, binary detection, class control, calibrator selection). |

Run from this directory:
```
python run_tests.py
python smoke_synthetic.py
python tabular_hunt.py --datasets digits,letter,adult,covtype --seed 0 --perturb all --out tabular_hunt_all_s0.json
```
OpenML datasets are cached on first download; pass `--cache DIR` to choose
where.
